(this.webpackJsonplauncher = this.webpackJsonplauncher || []).push([
    [0], {
        17: function(e, t, n) {},
        18: function(e, t, n) {},
        19: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(0),
                o = n(2),
                a = n.n(o),
                s = n(8),
                l = n.n(s),
                r = (n(17), n(1)),
                c = n(9),
                d = n(5),
                u = n(6),
                g = n(11),
                h = n(10),
                w = (n(18), n(3)),
                b = n.n(w);
            var p = n(7),
                v = n.n(p),
                m = function(e) {
                    v.a.init(e), v.a.pageView()
                },
                f = function(e) {
                    Object(g.a)(n, e);
                    var t = Object(h.a)(n);

                    function n(e) {
                        var i;
                        Object(d.a)(this, n), (i = t.call(this, e)).getPosition = function(e, t) {
                            var n = (new b.a).getDevice().type;
                            if ("desktop" === (n = n || "desktop")) {
                                if ("bottom-right" === e) return "right";
                                if ("bottom-left" === e) return "left";
                                if ("center-right" === e) return "center"
                            } else {
                                if ("bottom-right" === t) return "right";
                                if ("bottom-left" === t) return "left";
                                if ("center-right" === t) return "center"
                            }
                        }, i.checkIsInstallationVerification = function() {
                            var e = new URLSearchParams(window.location.search);
                            if (e.has("bpVerifyInstall")) {
                                var t = decodeURIComponent(e.get("bpVerifyInstall") || "").split(","),
                                    n = Object(c.a)(t, 2),
                                    i = n[0],
                                    o = n[1];
                                setTimeout((function() {
                                    o !== localStorage.getItem("__BotPenguinUser") || i !== localStorage.getItem("__BotPenguin") ? window.parent.postMessage({
                                        type: "bpVerifyInstall",
                                        status: "other-script"
                                    }, "*") : o !== localStorage.getItem("__BotPenguinUser") && i !== localStorage.getItem("__BotPenguin") || window.parent.postMessage({
                                        type: "bpVerifyInstall",
                                        status: "verified"
                                    }, "*"), window.close()
                                }), 3e3)
                            }
                        }, i.state = {
                            text: "...",
                            image: "",
                            theme: "",
                            position: "",
                            render: !0,
                            callToAction: {
                                autohide: !1,
                                duration: 0,
                                hide: !1,
                                hidden: !1,
                                bgColor: "#ffffff",
                                isEnabled: !0,
                                textColor: "#000000",
                                texts: []
                            },
                            avatarBgOffLauncher: !1,
                            avatarOutlineOffLauncher: !1
                        }, i.botpenguinWindow = null;
                        var o = function() {
                            function e() {
                                Object(d.a)(this, e)
                            }
                            return Object(u.a)(e, [{
                                key: "closeWindow",
                                value: function() {
                                    var e = document.getElementById("BotPenguin-messenger");
                                    e && (e.classList.remove("scale-in-br"), e.classList.add("scale-out-br"), setTimeout((function() {
                                        e.style.display = "none", document.getElementById("botpenguin-launcher-12").style.display = "block"
                                    }), 300))
                                }
                            }, {
                                key: "openWindow",
                                value: function() {
                                    document.getElementById("botpenguin-launcher-12").style.display = "none";
                                    var e = document.getElementById("BotPenguin-messenger");
                                    e.classList.remove("scale-out-br"), e.classList.add("scale-in-br"), e.style.display = "block", window.document.getElementById("BotPenguin-messenger").contentWindow.postMessage({
                                        origin: "BotPenguin",
                                        action: "start"
                                    }, "*")
                                }
                            }, {
                                key: "isWindowOpen",
                                value: function() {
                                    return "block" === document.getElementById("BotPenguin-messenger").style.display
                                }
                            }, {
                                key: "isWindowClose",
                                value: function() {
                                    return "block" !== document.getElementById("BotPenguin-messenger").style.display
                                }
                            }]), e
                        }();
                        return window.BotPenguin = o, window.BotPenguinWindow = function(e, t) {
                            if ("BotPenguin" !== t) return console.log("Unauthorized Access to function."), "Unauthorized Access to function.";
                            var n = new o;
                            switch (e) {
                                case "open":
                                    n.openWindow(), n = null;
                                    break;
                                case "close":
                                    n.closeWindow(), n = null;
                                    break;
                                default:
                                    return n = null, "Unknown Case"
                            }
                        }, window.addEventListener("message", (function(e) {
                            var t = (new b.a).getDevice().type;
                            t = t || "desktop";
                            var n = new window.BotPenguin;

                            function i() {
                                n.openWindow()
                            }
                            var o = e.data,
                                a = !0;
                            if ("BotPenguin" === o.origin)
                                if ("rendered" === o.action) {
                                    var s = document.getElementById("botpenguin-launcher-12");
                                    if (s.style.visibility = "visible", s.style.opacity = "1", a = "desktop" === t ? !window.BotPenguinData.configuration.triggerSettings.disableAutoTriggerOnDesktop : !window.BotPenguinData.configuration.triggerSettings.disableAutoTriggerOnMobile, localStorage.getItem("bp-user-close")) switch (window.BotPenguinData.configuration.triggerSettings.openWhenUserClose) {
                                        case "never":
                                            break;
                                        case "always":
                                            setTimeout((function() {
                                                i()
                                            }), 1e3 * window.BotPenguinData.configuration.triggerSettings["desktop" === t ? "autoTriggerOnDesktop" : "autoTriggerOnMobile"]);
                                            break;
                                        case "seconds":
                                            setTimeout((function() {
                                                i()
                                            }), 1e3 * parseInt(String(window.BotPenguinData.configuration.triggerSettings.autoTriggerWhenUserClose), 10));
                                            break;
                                        default:
                                            console.log()
                                    } else a && setTimeout((function() {
                                        i()
                                    }), 1e3 * window.BotPenguinData.configuration.triggerSettings["desktop" === t ? "autoTriggerOnDesktop" : "autoTriggerOnMobile"])
                                } else if ("close" === o.action) n.closeWindow();
                            else if ("ele-expand" === o.action) {
                                var l = document.getElementById("BotPenguin-messenger");
                                if (!l || !l.style) return;
                                l.style.transition = "width 1s ease, height 1s ease", l.style.width = "60vw", l.style.height = "95vh"
                            } else if ("ele-collapse" === o.action) {
                                var r = document.getElementById("BotPenguin-messenger");
                                if (!r || !r.style || !window.BotPenguinData || !window.BotPenguinData.design) return;
                                r.style.transition = "width 1s ease, height 1s ease", r.style.width = window.BotPenguinData.design.width + "px", r.style.height = window.BotPenguinData.design.height + "px"
                            }
                        })), i
                    }
                    return Object(u.a)(n, [{
                        key: "getDynamicFont",
                        value: function(e) {
                            fetch(e).then((function(e) {
                                return e.arrayBuffer()
                            })).then((function(e) {
                                var t = btoa(new Uint8Array(e).reduce((function(e, t) {
                                        return e + String.fromCharCode(t)
                                    }), "")),
                                    n = "data:application/font-woff2;base64,".concat(t),
                                    i = document.createElement("style");
                                i.appendChild(document.createTextNode("\n          @font-face {\n            font-family: 'user-font';\n            src: url(".concat(n, ") format('woff2');\n            font-weight: normal;\n            font-style: normal;\n          }\n        "))), document.head.appendChild(i)
                            })).catch((function(e) {
                                console.error("Font loading error:", e)
                            }))
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            this.openNonAiChatBot()
                        }
                    }, {
                        key: "transFormAgentData",
                        value: function(e) {
                            var t, n, i, o, a, s, l, c, d, u, g, h, w, b, p = e.agentSetting,
                                v = e.agent,
                                m = e.profile,
                                f = e.uuid,
                                y = e._inboxUser,
                                B = e._agency,
                                C = e._customer,
                                S = e.agency,
                                T = e.agentVoiceSetting,
                                A = {
                                    waitingMessage: "Usual reply time: 2 to 3 Minutes",
                                    unavailabilityMessage: "Live chat is Unavailable!!",
                                    waitingMessageTitle: "Initiating Live Chat...",
                                    refreshChatText: "Start New Session",
                                    ratingTitle: "How was your experience?",
                                    ratingSubTitle: "Please share your feedback",
                                    ratingCloseButton: "Close",
                                    ratingRestartButton: "Restart Chat",
                                    placeholderReplyBox: "Type your message here...",
                                    callButtonTitle: "Call Agent",
                                    aiDisclaimerMessage: "AI can make mistakes. Check important info."
                                },
                                I = {
                                    waitingMessage: "waitingMessage",
                                    unavailabilityMessage: "unavailabilityTitle",
                                    waitingMessageTitle: "waitingMessageTitle",
                                    refreshChatText: "labelRestartChat",
                                    ratingTitle: "ratingTitle",
                                    ratingSubTitle: "ratingSubTitle",
                                    ratingCloseButton: "labelCloseRating",
                                    ratingRestartButton: "labelRestartRating",
                                    placeholderReplyBox: "placeholderReplyBox",
                                    callButtonTitle: "callButtonTitle",
                                    aiDisclaimerMessage: "aiDisclaimerMessage"
                                },
                                k = function(e) {
                                    var t = p.website.defaultLanguage || "hi",
                                        n = p.website.agentTexts.find((function(e) {
                                            return e.language === t
                                        })) || {},
                                        i = I[e];
                                    return i && (n[i] || A[e]) || ""
                                },
                                O = p.website.advanced.autoOpenAfterClose.mode.toLowerCase();
                            return Object(r.a)(Object(r.a)({
                                _id: v._id,
                                whitelabel: {
                                    active: null !== (t = p.website.general.isWhiteLabelActive) && void 0 !== t && t,
                                    byAgency: !1
                                },
                                name: v.name,
                                platforms: ["web"]
                            }, T && {
                                voiceSettings: {
                                    enabled: null === T || void 0 === T ? void 0 : T.enabled
                                }
                            }), {}, {
                                design: {
                                    icebreakers: v.iceBreaker,
                                    position: null === (n = p.website.layout.position.desktop) || void 0 === n ? void 0 : n.toLowerCase().replace(/_/g, "-"),
                                    mobilePosition: null === (i = p.website.layout.position.mobile) || void 0 === i ? void 0 : i.toLowerCase().replace(/_/g, "-"),
                                    welcomeMessage: v.welcomeNote,
                                    avatarPlacement: p.website.advanced.avatarPlacement,
                                    enableChatWindowResize: !0,
                                    height: p.website.layout.windowSize.height,
                                    width: p.website.layout.windowSize.width,
                                    avatar: p.website.profileImage,
                                    fontFamilyLink: p.website.theme.font,
                                    design: "design_1",
                                    headerText: v.name,
                                    descriptionText: v.welcomeNote,
                                    backgroundType: "gradient",
                                    background: p.website.theme.color.secondary,
                                    gradientColor: [],
                                    themeColor: p.website.theme.color.primary,
                                    backgroundColor: p.website.theme.color.secondary,
                                    backgroundColorSecondary: "#fff",
                                    textColor: "#ffffff",
                                    landingPageChatBackgroundColor: p.website.theme.color.secondary,
                                    view: "center",
                                    hideInfo: !0,
                                    hideMessengerHeader: p.website.advanced.hideElementsOnLandingPage.header,
                                    singleSelectViewType: "list",
                                    skipCount: 3,
                                    callToAction: {
                                        isEnabled: p.website.advanced.cta.enable,
                                        autoHide: !1,
                                        duration: 10,
                                        texts: p.website.advanced.cta.texts,
                                        position: null === (o = p.website.advanced.cta.position) || void 0 === o ? void 0 : o.toLowerCase()
                                    },
                                    links: [],
                                    render: !0,
                                    customCSS: (null === (a = p.website.advanced.customCss) || void 0 === a ? void 0 : a.chatWindow) || "",
                                    launcherCustomCSS: (null === (s = p.website.advanced.customCss) || void 0 === s ? void 0 : s.launcherIcon) || ""
                                },
                                status: "ACTIVE",
                                description: v.welcomeNote || "",
                                configuration: {
                                    generalSettings: {
                                        notificationSound: {
                                            onBotAppearance: p.website.general.notificationSound.onAgentAppearance,
                                            onChatWindow: p.website.general.notificationSound.onChatWindow,
                                            onMobile: p.website.general.notificationSound.onMobile,
                                            onLauncherIconAppearance: p.website.general.notificationSound.onAgentAppearance
                                        },
                                        status: p.website.general.status || !0,
                                        timezone: {
                                            offset: p.website.general.timezone.offset,
                                            text: p.website.general.timezone.text
                                        },
                                        sendAllResponses: !0,
                                        sendIncompleteResponses: !1,
                                        saveResponses: !0,
                                        language: p.website.defaultLanguage || "en",
                                        brandName: "BotPenguin",
                                        whiteLabel: null !== (l = p.website.general.isWhiteLabelActive) && void 0 !== l && l,
                                        showIpInConversations: !0,
                                        waitingMessage: k("waitingMessage"),
                                        unavailabilityMessage: k("unavailabilityMessage"),
                                        waitingMessageTitle: k("waitingMessageTitle"),
                                        unavailabilityMessageTitle: k("unavailabilityMessageTitle"),
                                        visibility: {
                                            country: !0,
                                            location: !0,
                                            lastSeen: !0,
                                            device: !0,
                                            browser: !0,
                                            ip: !0,
                                            operatingSystem: !0
                                        },
                                        userChatRetention: p.website.general.chatSession.toLowerCase() || "session",
                                        captureIPDevice: p.website.advanced.dataCapture.ipAndDevice,
                                        captureURLSource: p.website.advanced.dataCapture.urlSource
                                    },
                                    triggerSettings: {
                                        autoTrigger: 1,
                                        autoTriggerOnDesktop: p.website.advanced.triggers.desktop.time,
                                        autoTriggerOnMobile: p.website.advanced.triggers.mobile.time,
                                        openWhenUserClose: "after_seconds" === O ? "seconds" : O,
                                        autoTriggerWhenUserClose: p.website.advanced.autoOpenAfterClose.seconds,
                                        disableAutoTriggerOnMobile: !p.website.advanced.triggers.mobile.enable,
                                        disableAutoTriggerOnDesktop: !p.website.advanced.triggers.desktop.enable
                                    },
                                    userAccessSettings: {
                                        showOn: p.website.advanced.deviceSupport.toLowerCase(),
                                        blockedIps: "BLOCK" === p.website.access.ipRule.action ? p.website.access.ipRule.ipAddresses : [],
                                        hideOnUrls: "BLOCK" === p.website.access.urlRule.action ? p.website.access.urlRule.urls : [],
                                        showOnUrls: "ALLOW" === p.website.access.urlRule.action ? p.website.access.urlRule.urls : [],
                                        hideInCountries: "BLOCK" === p.website.access.countryRule.action ? p.website.access.countryRule.countries : [],
                                        showInCountries: "ALLOW" === p.website.access.countryRule.action ? p.website.access.countryRule.countries : [],
                                        availabilityType: "all_days",
                                        whitelistDomains: [],
                                        availability: [],
                                        flowUrlMapping: []
                                    },
                                    seoSettings: {
                                        googleAnalyticsId: "",
                                        facebookPixelId: "",
                                        metaTitle: "",
                                        metaImage: "",
                                        favicon: "",
                                        metaDescription: "",
                                        metaKeywords: ""
                                    },
                                    chatMenu: {
                                        isCustomResponsePlaceholderEnabled: !0,
                                        placeholder: k("placeholderReplyBox"),
                                        voiceSupport: {
                                            isEnabled: !1,
                                            isDefault: !1
                                        },
                                        ticketing: {
                                            enabled: !1
                                        },
                                        knowledgeBase: {
                                            enabled: !1
                                        },
                                        toWhatsapp: !1,
                                        hideTransferToWhatsApp: !0,
                                        isAiDisclaimerActive: null !== (c = p.website.general.isAiDisclaimerActive) && void 0 !== c && c,
                                        hideRefreshChat: p.website.general.restartSession,
                                        isRatingEnabled: p.website.general.rateConversation,
                                        toChatBot: !0,
                                        toLiveChat: p.website.general.liveChat.enable,
                                        refreshChat: p.website.general.restartSession,
                                        liveChatRequestExpiryTime: p.website.general.liveChat.requestExpiryTime,
                                        refreshChatText: k("refreshChatText"),
                                        botMessageSubScript: "Bot",
                                        callButtonTitle: k("callButtonTitle"),
                                        clearChatOnReload: !1,
                                        clearChatOnRestart: !1,
                                        aiDisclaimerMessage: k("aiDisclaimerMessage")
                                    },
                                    chatRating: {
                                        title: k("ratingTitle"),
                                        description: k("ratingSubTitle"),
                                        closeButton: k("ratingCloseButton"),
                                        restartButton: k("ratingRestartButton")
                                    },
                                    aiSettings: {
                                        isStreamingEnabled: null === (d = null === p || void 0 === p || null === (u = p.ai) || void 0 === u ? void 0 : u.enableResponseStreaming) || void 0 === d || d
                                    }
                                },
                                lastIntractedAt: new Date,
                                flows: [],
                                _customer: C,
                                _agency: B,
                                _user: y,
                                installations: [],
                                createdAt: new Date,
                                updatedAt: new Date,
                                __v: 0,
                                profile: m,
                                uuid: f,
                                _chatWindowUser: y,
                                agency: {
                                    name: "Default Agency",
                                    meta: {
                                        domains: [],
                                        logo: null === S || void 0 === S || null === (g = S.meta) || void 0 === g ? void 0 : g.logo,
                                        brand: null === S || void 0 === S || null === (h = S.meta) || void 0 === h ? void 0 : h.brand,
                                        websiteUrl: null === S || void 0 === S || null === (w = S.meta) || void 0 === w ? void 0 : w.websiteUrl,
                                        _id: "",
                                        poweredBy: null === S || void 0 === S || null === (b = S.meta) || void 0 === b ? void 0 : b.poweredBy,
                                        isPoweredByEnabled: null === S || void 0 === S ? void 0 : S.isAgencyConfigurationEnabled.poweredBy
                                    },
                                    type: S.type
                                },
                                version: "v3"
                            })
                        }
                    }, {
                        key: "openNonAiChatBot",
                        value: function() {
                            var e = this;
                            this.checkIsInstallationVerification();
                            var t = window.location.hostname,
                                n = window.location.pathname;
                            this.botpenguinWindow = new window.BotPenguin;
                            var i = "https://api.v7.botpenguin.com/";
                            if ("true" === localStorage.getItem("isAgent")) i += "ai-agent-widget/".concat(localStorage.getItem("__BotPenguinUser"), "/").concat(localStorage.getItem("__BotPenguin"), "?uuid=").concat(localStorage.getItem("BotPenguin_User_uuid"));
                            else if ("true" !== localStorage.getItem("old")) i += "website-widget/".concat(localStorage.getItem("__BotPenguinUser"), "/").concat(localStorage.getItem("__BotPenguin"), "?uuid=").concat(localStorage.getItem("BotPenguin_User_uuid"));
                            else {
                                var o = localStorage.getItem("old-botpenguin-api-key");
                                o = unescape(o).split("(->)")[0], i += "old-website-widget/".concat(encodeURI(o), "?uuid=").concat(localStorage.getItem("BotPenguin_User_uuid"))
                            }
                            fetch(i, {
                                method: "GET",
                                headers: {
                                    "Content-Type": "application/json"
                                }
                            }).then((function(e) {
                                return e.json()
                            })).then((function(i) {
                                var o, a, s, l, c, d, u, g, h, w, p, v, f;
                                if ("true" === localStorage.getItem("isAgent") && (i.data = e.transFormAgentData(i.data)), null === i || void 0 === i || null === (o = i.data) || void 0 === o || null === (a = o.design) || void 0 === a ? void 0 : a.launcherCustomCSS) {
                                    var y = document.createElement("style");
                                    y.textContent = i.data.design.launcherCustomCSS, document.head.appendChild(y);
                                    var B = document.getElementById("botpenguin-launcher-text-12");
                                    B && B.classList.add("launcher-customCSS")
                                }
                                if (!i.data.configuration.generalSettings.status) throw new Error("This bot is currently inactive.");
                                (null === (s = i.data) || void 0 === s || null === (l = s.design) || void 0 === l ? void 0 : l.fontFamilyLink) && e.getDynamicFont(null === (v = i.data) || void 0 === v || null === (f = v.design) || void 0 === f ? void 0 : f.fontFamilyLink);
                                var C = (new b.a).getDevice().type,
                                    S = i.data.configuration.userAccessSettings.showOn;
                                if (C = C || "desktop", "all" !== S && C !== S) throw new Error("Not supported on this device");
                                if (i.data.configuration.userAccessSettings.hideOnUrls.some((function(e) {
                                        var i = new URL(e);
                                        return i.host === t && i.pathname === n
                                    }))) throw new Error("Hidden on this page");
                                window.BotPenguinData = i.data;
                                var T = i.data;
                                if (!i.data) throw new Error(i.message);
                                localStorage.setItem("BotPenguin_User_uuid", i.data.uuid), e.setState({
                                    callToAction: T.design.callToAction,
                                    text: T.design.welcomeMessage,
                                    theme: T.design.themeColor,
                                    image: T.design.avatar,
                                    position: e.getPosition(T.design.position, (null === (c = T.design) || void 0 === c ? void 0 : c.mobilePosition) || T.design.position),
                                    render: !0,
                                    avatarBgOffLauncher: T.design.avatarBgOffLauncher || !1,
                                    avatarIconSizeLauncher: T.design.avatarIconSizeLauncher || 1,
                                    avatarOutlineOffLauncher: T.design.avatarOutlineOffLauncher || !1
                                }), (null === (d = T.design) || void 0 === d || null === (u = d.callToAction) || void 0 === u ? void 0 : u.autoHide) && (null === (g = T.design) || void 0 === g || null === (h = g.callToAction) || void 0 === h ? void 0 : h.duration) && (setTimeout((function() {
                                    e.setState(Object(r.a)(Object(r.a)({}, e.state), {}, {
                                        callToAction: Object(r.a)(Object(r.a)({}, e.state.callToAction), {}, {
                                            hide: !0
                                        })
                                    }))
                                }), 1e3 * T.design.callToAction.duration), setTimeout((function() {
                                    e.setState(Object(r.a)(Object(r.a)({}, e.state), {}, {
                                        callToAction: Object(r.a)(Object(r.a)({}, e.state.callToAction), {}, {
                                            hidden: !0
                                        })
                                    }))
                                }), 1e3 * (T.design.callToAction.duration + 1))), window.postMessage({
                                    origin: "BotPenguin",
                                    action: "position",
                                    position: e.getPosition(T.design.position, (null === (w = T.design) || void 0 === w ? void 0 : w.mobilePosition) || T.design.position)
                                }, "*");
                                var A = document.getElementById("BotPenguin-messenger");
                                A.setAttribute("class", String(e.getPosition(T.design.position, (null === (p = T.design) || void 0 === p ? void 0 : p.mobilePosition) || T.design.position)));
                                var I = window.BotPenguinData.design,
                                    k = localStorage.getItem("userPreferredWidth"),
                                    O = localStorage.getItem("userPreferredHeight");
                                "v2" === T.version && I.enableChatWindowResize && Number(k) && Number(O) ? (A.style.width = k + "px", A.style.height = O + "px") : (A.style.height = (i.data.design.height || ("v2" === T.version ? 700 : 500)) + "px", A.style.width = (i.data.design.width || ("v2" === T.version ? 400 : 360)) + "px"), i.data.configuration.seoSettings.googleAnalyticsId && i.data.configuration.seoSettings.googleAnalyticsId.length && document.querySelector("body").append(function(e) {
                                    var t = document.createElement("script");
                                    t.setAttribute("src", "https://www.googletagmanager.com/gtag/js?id=".concat(e));
                                    var n = document.createElement("script");
                                    t.setAttribute("async", "true"), n.textContent = "window.dataLayer = window.dataLayer || []; \n function gtag(){dataLayer.push(arguments)} \n gtag('js', new Date()) \n gtag('config', '".concat(e, "')");
                                    var i = document.createElement("script");
                                    i.setAttribute("type", "text/javascript"), i.setAttribute("src", "https://www.google-analytics.com/analytics.js"), i.setAttribute("async", "true");
                                    var o = document.createElement("div");
                                    return o.append(i), o.append(t), o.append(n), o
                                }(i.data.configuration.seoSettings.googleAnalyticsId)), i.data.configuration.seoSettings.facebookPixelId && i.data.configuration.seoSettings.facebookPixelId.length && m(i.data.configuration.seoSettings.facebookPixelId);
                                var x = document.getElementById("BotPenguin-messenger").contentWindow.document;
                                x.open();
                                var P = "";
                                P = "true" === localStorage.getItem("isAgent") ? "https://window-3.botpenguin.com" : T && "v2" === T.version ? "https://window-2.botpenguin.com" : "https://window-new.botpenguin.com", fetch(P).then((function(e) {
                                    return e.text()
                                })).then((function(e) {
                                    x.write(e), x.close()
                                }))
                            })).catch((function(e) {
                                console.log("%c".concat(e), "color: red; font-weight: bold; font-size: ".concat("20px", ";"))
                            }))
                        }
                    }, {
                        key: "openWindow",
                        value: function() {
                            this.botpenguinWindow.openWindow()
                        }
                    }, {
                        key: "renderBlank",
                        value: function() {
                            return Object(i.jsx)("div", {})
                        }
                    }, {
                        key: "renderComponent",
                        value: function() {
                            var e, t, n, o, a, s, l, c, d, u, g, h, w = this,
                                b = void 0 === (null === (e = this.state.callToAction) || void 0 === e ? void 0 : e.isEnabled) || (null === (t = this.state.callToAction) || void 0 === t ? void 0 : t.isEnabled),
                                p = void 0 !== (null === (n = this.state.callToAction) || void 0 === n ? void 0 : n.bgColor) ? null === (o = this.state.callToAction) || void 0 === o ? void 0 : o.bgColor : "#fff",
                                v = void 0 !== (null === (a = this.state.callToAction) || void 0 === a ? void 0 : a.textColor) ? null === (s = this.state.callToAction) || void 0 === s ? void 0 : s.textColor : "#000",
                                m = (null === (l = this.state.callToAction) || void 0 === l ? void 0 : l.position) || "left",
                                f = (null === (c = this.state.callToAction) || void 0 === c ? void 0 : c.texts) || [];
                            return Object(i.jsx)("div", {
                                id: "botpenguin-launcher-12",
                                className: "botpenguin-" + this.state.position + " fade-in",
                                children: Object(i.jsxs)("div", {
                                    className: "botpenguin-launcherImage-12 ".concat("left" === m ? "d-flex" : ""),
                                    children: [!b || (null === (d = this.state) || void 0 === d || null === (u = d.callToAction) || void 0 === u ? void 0 : u.hide) || (null === (g = this.state) || void 0 === g || null === (h = g.callToAction) || void 0 === h ? void 0 : h.hidden) ? "" : Object(i.jsxs)("div", {
                                        children: [f.map((function(e, t) {
                                            return Object(i.jsx)("div", {
                                                id: "botpenguin-launcher-cta-text-".concat(t),
                                                className: "botpenguin-launcher-text-12",
                                                style: {
                                                    backgroundColor: p
                                                },
                                                onClick: function() {
                                                    return w.openWindow()
                                                },
                                                children: Object(i.jsx)("span", {
                                                    style: {
                                                        color: v
                                                    },
                                                    children: e
                                                })
                                            }, t)
                                        })), "true" !== localStorage.getItem("isAgent") && Object(i.jsx)(i.Fragment, {
                                            children: Object(i.jsx)("div", {
                                                id: "botpenguin-launcher-text-12",
                                                className: "botpenguin-launcher-text-12",
                                                style: {
                                                    backgroundColor: p
                                                },
                                                onClick: function() {
                                                    return w.openWindow()
                                                },
                                                children: Object(i.jsx)("span", {
                                                    style: {
                                                        color: v
                                                    },
                                                    children: this.state.text
                                                })
                                            })
                                        })]
                                    }), Object(i.jsx)("div", {
                                        className: "d-flex justify-content-end ".concat("left" === m ? "flex-direction-column" : ""),
                                        children: Object(i.jsx)("span", {
                                            className: "botpenguin-launcher-image-12",
                                            onClick: function() {
                                                return w.openWindow()
                                            },
                                            style: Object(r.a)(Object(r.a)(Object(r.a)({}, this.state.avatarOutlineOffLauncher && {
                                                boxShadow: "none"
                                            }), !this.state.avatarBgOffLauncher && {
                                                background: this.state.theme
                                            }), {}, {
                                                zIndex: 1,
                                                position: "relative",
                                                width: 44 * (this.state.avatarIconSizeLauncher || 1) + "px",
                                                height: 44 * (this.state.avatarIconSizeLauncher || 1) + "px"
                                            }),
                                            children: Object(i.jsx)("img", {
                                                src: this.state.image,
                                                alt: ""
                                            })
                                        })
                                    })]
                                })
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this.state.render ? this.renderComponent() : this.renderBlank()
                        }
                    }]), n
                }(a.a.Component);
            l.a.render(Object(i.jsxs)("div", {
                className: "BotPenguin-chat",
                children: [Object(i.jsx)(f, {}), Object(i.jsx)("iframe", {
                    title: "BotPenguin",
                    src: "about:blank",
                    id: "BotPenguin-messenger",
                    allowFullScreen: !0,
                    allowpaymentrequest: "true",
                    name: "BotPenguin"
                })]
            }), document.querySelector("botpenguin-root"))
        }
    },
    [
        [19, 1, 2]
    ]
]);