function createBPMeta() {
    let e = document.createElement("meta");
    e.name = "viewport", e.content = "width=device-width, initial-scale=1", document.head.appendChild(e)
}

function createBPStyles() {
    let e = document.createElement("style");
    e.appendChild(document.createTextNode('.BotPenguin-chat *{box-sizing:content-box!important;-webkit-box-sizing:content-box!important;font-family:user-font,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,Ubuntu,Cantarell,"Open Sans","Helvetica Neue",sans-serif!important}@media screen and (max-width:550px){#BotPenguin-messenger{width:100%!important;height:100%!important;bottom:0!important;right:0!important;left:0!important;border-radius:0!important;margin:0!important}}#BotPenguin-messenger{background:transparent;z-index:2147483647;width:360px;height:500px;position:fixed;bottom:20px;right:20px;border:none;border-radius:10px;box-shadow:0 0 3px 1px hsla(0,0%,57.3%,.3);left:auto;display:none}.left{left:20px!important}.center{left:0!important;right:0!important;margin:auto!important}#botpenguin-launcher-12{position:fixed;z-index:2147483647;bottom:20px;right:20px;cursor:pointer;visibility:hidden;transition:visibility .7s,opacity .5s linear;opacity:0;width:-webkit-fit-content;width:-moz-fit-content;width:fit-content}.botpenguin-launcher-text-12{font-weight:600;color:#000;position:relative;margin-bottom:2px;box-shadow:0 0 3px 1px hsla(0,0%,57.3%,.3);max-width:230px;background:#fff;padding:13px;vertical-align:bottom;cursor:pointer;border-radius:20px 20px 3px 20px;display:inline-block;margin-right:8px;margin-top:0;font-size:16px;word-spacing:2px;overflow:hidden;display:block;margin-bottom:10px;font-family:user-font,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,Ubuntu,Cantarell,"Open Sans","Helvetica Neue",sans-serif}span.botpenguin-launcher-image-12{overflow:hidden;display:inline-block;vertical-align:middle;border-radius:50%;height:44px;width:44px;box-shadow:0 0 3px 1px hsla(0,0%,57.3%,.3);padding:8px}span.botpenguin-launcher-image-12 img{width:100%;height:100%;border-radius:100%}.botpenguin-right{right:20px;left:auto}.botpenguin-left{right:auto;left:20px}.botpenguin-center{right:20px!important;top:auto!important;bottom:50%!important}@media screen and (max-width:550px){.botpenguin-launcher-text-12{max-width:215px;padding:12px;font-size:16px}span.botpenguin-launcher-image-12{height:44px;width:44px}}@media screen and (max-width:350px){.botpenguin-launcher-text-12{max-width:185px;padding:12px;font-size:16px}span.botpenguin-launcher-image-12{height:44px;width:44px}}@media screen and (max-width:300px){.botpenguin-launcher-text-12{max-width:160px;padding:12px;font-size:16px}span.botpenguin-launcher-image-12{height:44px;width:44px}}.hide{-webkit-animation:right-animate .6s ease forwards;animation:right-animate .6s ease forwards}@-webkit-keyframes right-animate{0%{transform:translateX(0) scaleX(1) scaleY(1)}to{transform:translateX(65%) scaleX(0)}}@keyframes right-animate{0%{transform:translateX(0) scaleX(1) scaleY(1)}to{transform:translateX(65%) scaleX(0)}}.scale-in-br{-webkit-animation:scale-in-br .3s cubic-bezier(0,1.2,1,1) both;animation:scale-in-br .3s cubic-bezier(0,1.2,1,1) both}@-webkit-keyframes scale-in-br{0%{transform:scale(0);transform-origin:100% 100%;opacity:1}to{transform:scale(1);transform-origin:100% 100%;opacity:1}}@keyframes scale-in-br{0%{transform:scale(0);transform-origin:100% 100%;opacity:1}to{transform:scale(1);transform-origin:100% 100%;opacity:1}}.scale-out-br{-webkit-animation:scale-out-br .3s cubic-bezier(0,1.2,1,1) both;animation:scale-out-br .3s cubic-bezier(0,1.2,1,1) both}@-webkit-keyframes scale-out-br{to{transform:scale(0);transform-origin:100% 100%;opacity:1}0%{transform:scale(1);transform-origin:100% 100%;opacity:1}}@keyframes scale-out-br{to{transform:scale(0);transform-origin:100% 100%;opacity:1}0%{transform:scale(1);transform-origin:100% 100%;opacity:1}}.fade-in{-webkit-animation:fade-in 1.5s cubic-bezier(.39,.575,.565,1) both;animation:fade-in 1.5s cubic-bezier(.39,.575,.565,1) both}@-webkit-keyframes fade-in{0%{opacity:0}to{opacity:1}}@keyframes fade-in{0%{opacity:0}to{opacity:1}}.d-none{display:none}.d-flex{display:flex}.justify-content-end{justify-content:end}.flex-direction-column{flex-direction:column}')), document.head.appendChild(e)
}

function insertBPScript() {
    let e = document.createElement("script");
    e.defer = !0, e.src = "https://cdn.express-chat.com/window-script/runtime-main.d5772693.js", document.body.appendChild(e);
    let t = document.createElement("script");
    t.defer = !0, t.src = "https://cdn.express-chat.com/window-script/2.1ec8f493.chunk.js", document.body.appendChild(t);
    let n = document.createElement("script");
    n.defer = !0, n.src = "https://cdn.express-chat.com/window-script/main.f9c344ee.chunk.js", document.body.appendChild(n)
}(() => {
    if (document.querySelector("botpenguin-root")) throw new Error("The bot element already exist, please remove existing script to continue");
    let e = document.getElementById("BotPenguin-messenger-widget") || document.getElementById("BotPenguin-messenger-widget-js") || document.getElementById("BotPenguin-messenger-widget-js-after") || document.getElementById("messenger-widget-b") || document.getElementById("messenger-widget-b-js") || document.getElementById("messenger-widget-b-js-after");
    if (e) {
        let t = e.innerText.split(",");
        localStorage.setItem("__BotPenguinUser", t[1]), localStorage.setItem("__BotPenguin", t[0]), t.length < 2 ? (localStorage.setItem("old", "true"), localStorage.setItem("old-botpenguin-api-key", encodeURIComponent(String(decodeURI(e.innerText)))), localStorage.removeItem("isAgent")) : t.length > 2 ? localStorage.setItem("isAgent", "true") : (localStorage.setItem("old", "false"), localStorage.removeItem("isAgent"));
        const n = [],
            i = {},
            a = e.attributes;
        for (let e = 0; e < a.length; e++) {
            const t = a[e];
            if (t.name.startsWith("ctx-")) {
                const e = t.value,
                    a = t.name.replace("ctx-", "");
                new Set(["name", "email", "phone", "prefix"]).has(a) ? i[a] = e : n.push({
                    key: a,
                    value: (e ? e.trim() : "") || null
                })
            }
        }
        localStorage.setItem("Ctx_Custom_Attributes", JSON.stringify(n)), localStorage.setItem("Ctx_Default_Attributes", JSON.stringify(i))
    } else {
        let e = document.getElementById("Ym90cGVuZ3VpbkFwaQ").src;
        if (e = new URL(String(e)), e = e.searchParams.get("apiKey"), !e) throw new Error("Invalid Script");
        localStorage.setItem("old", "true"), localStorage.setItem("old-botpenguin-api-key", encodeURIComponent(String(e)))
    }
    createBPStyles(), createBPMeta();
    let t = document.createElement("botpenguin-root");
    document.body.appendChild(t), insertBPScript()
})();