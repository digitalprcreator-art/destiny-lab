"use strict";
(self.webpackChunkmessenger_v2 = self.webpackChunkmessenger_v2 || []).push([
    [6151, 8656], {
        10573: (e, t, s) => {
            s.r(t), s.d(t, {
                default: () => B
            });
            var n = s(10300),
                i = s(9950),
                l = s(25817),
                a = s(80150),
                o = s(38751),
                r = s(29942),
                d = s(1092),
                c = s(34928),
                u = s(23507),
                h = s(69772),
                m = s(44414);

            function g() {
                const e = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    t = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.configuration)),
                    s = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)),
                    {
                        viewType: g
                    } = s,
                    {
                        backgroundColor: x,
                        landingPageChatBackgroundColor: v
                    } = e || {},
                    f = "launcher-icon" === g ? x : v || "#FFFFFF",
                    [w, p] = (0, i.useState)([!1, !1, !1, !1, !1]),
                    [j, k] = (0, i.useState)({
                        title: "Rate the conversation",
                        description: "Thanks for Interacting with us!",
                        closeButton: "Close Chat",
                        restartButton: "Restart Chat"
                    });
                (0, i.useEffect)((() => {
                    if (t && t.chatMenu && t.chatMenu.userRatingCustomImage) {
                        const e = document.getElementById("user-rating-image");
                        if (e) {
                            e.src = t.chatMenu.userRatingCustomImage;
                            const s = new URL(t.chatMenu.userRatingCustomImage),
                                n = s.searchParams.get("width"),
                                i = s.searchParams.get("height");
                            e.style.width = n ? n + "px" : "100%", e.style.height = i ? i + "px" : "100%"
                        }
                    }
                }), [t]), (0, i.useEffect)((() => {
                    var e, s;
                    null !== t && void 0 !== t && null !== (e = t.chatMenu) && void 0 !== e && e.isRatingEnabled || N(), null !== t && void 0 !== t && null !== (s = t.chatMenu) && void 0 !== s && s.chatRating && k({
                        title: t.chatMenu.chatRating.title || "",
                        description: t.chatMenu.chatRating.description,
                        closeButton: t.chatMenu.chatRating.closeButton,
                        restartButton: t.chatMenu.chatRating.restartButton
                    })
                }), [t]);
                const b = e => {
                        p((t => t.map(((t, s) => e >= s))))
                    },
                    N = () => {
                        if (l.e.dispatch((0, a.A)(!1)), window.parent && window.parent.BotPenguin) {
                            (new window.parent.BotPenguin).closeWindow(), localStorage.setItem("bp-user-close", "true")
                        }
                    },
                    y = async e => {
                        try {
                            await (0, o.dI)(e), sessionStorage.setItem("BotPenguin_rating", String(e)), N()
                        } catch (t) {
                            console.log({
                                error: t
                            }), N()
                        }
                    },
                    C = () => {
                        (new window.parent.BotPenguin).closeWindow(), localStorage.setItem("bp-user-close", "true"), l.e.dispatch((0, a.A)(!1))
                    };
                return (0, m.jsx)(m.Fragment, {
                    children: t && t.chatMenu && t.chatMenu.hasOwnProperty("isRatingEnabled") && (0, m.jsxs)("div", {
                        className: "flex flex-col justify-between h-dvh relative overflow-y-auto",
                        id: "user-rating",
                        style: {
                            backgroundColor: f
                        },
                        children: [(0, m.jsxs)("div", {
                            id: "ele-12",
                            className: "flex flex-col justify-center items-center text-center",
                            children: [(0, m.jsx)("div", {
                                id: "ele-13",
                                style: {
                                    background: !e.userRatingCustomCSSBackground && e.themeColor ? e.themeColor : ""
                                },
                                className: "w-full text-center",
                                children: (0, m.jsx)("img", {
                                    id: "user-rating-image",
                                    src: "https://cdn.express-chat.com/messenger/rating-screen.png",
                                    alt: "Rate us",
                                    style: { ...!t.chatMenu.userRatingCustomImage && {
                                            maxHeight: "256px"
                                        }
                                    },
                                    className: "m-auto"
                                })
                            }), (0, m.jsx)("div", {
                                id: "ele-14",
                                className: "font-mSemiBold text-2xl mt-10",
                                children: j.title || "Your Opinion Matters to Us!"
                            }), (0, m.jsx)("div", {
                                id: "ele-15",
                                className: "font-mRegular text-sm mt-4 pl-10 pr-10",
                                children: j.description || "Your feedback is valuable! Let us know how we can make your next chat experience even better."
                            }), (0, m.jsx)("div", {
                                id: "ele-16",
                                className: "flex justify-start items-start mt-6",
                                style: {
                                    height: "70px"
                                },
                                children: w.map(((e, t) => (0, m.jsx)("div", {
                                    children: [0, 4].includes(t) ? (0, m.jsx)(m.Fragment, {
                                        children: (0, m.jsxs)("div", {
                                            className: "ele-user-rating-img-container flex flex-col cursor-pointer",
                                            children: [(0, m.jsx)("img", {
                                                width: 54,
                                                alt: "",
                                                className: "p-2",
                                                src: e ? "https://cdn.express-chat.com/messenger/filled_star_1.svg" : "https://cdn.express-chat.com/messenger/blank_star_1.svg",
                                                onMouseEnter: () => b(t),
                                                onMouseLeave: () => p([!1, !1, !1, !1, !1]),
                                                onClick: () => y(t + 1)
                                            }, t), (0, m.jsx)("div", {
                                                className: "ele-user-rating-text text-xs",
                                                children: 0 === t ? "Bad" : "Good"
                                            })]
                                        })
                                    }) : (0, m.jsx)("img", {
                                        width: 54,
                                        alt: "",
                                        className: "p-2",
                                        src: e ? "https://cdn.express-chat.com/messenger/filled_star_1.svg" : "https://cdn.express-chat.com/messenger/blank_star_1.svg",
                                        onMouseEnter: () => b(t),
                                        onMouseLeave: () => p([!1, !1, !1, !1, !1]),
                                        onClick: () => y(t + 1)
                                    }, t)
                                }, "rating " + t)))
                            }), (0, m.jsx)("div", {
                                id: "ele-20",
                                className: "rating-button mt-6 p-3 rounded-md cursor-pointer",
                                onClick: C,
                                style: {
                                    background: e.themeColor || "#226CF4",
                                    color: "white"
                                },
                                children: j.closeButton || "Close"
                            }), (0, m.jsx)("div", {
                                id: "ele-21",
                                className: "rating-button mt-4 p-3 cursor-pointer",
                                onClick: () => {
                                    l.e.dispatch((0, d.VU)({
                                        value: "",
                                        original: ""
                                    })), l.e.dispatch((0, c.t)("BOT")), (0, u.K_)(!0), l.e.dispatch((0, a.A)(!1)), l.e.dispatch((0, h.h8)({
                                        selectedTags: []
                                    }))
                                },
                                style: {
                                    color: e.themeColor || "#226CF4"
                                },
                                children: j.restartButton || "Restart"
                            })]
                        }), (0, m.jsx)("div", {
                            id: "ele-22",
                            className: "h-3 max-h-4 mb-4 text-sm text-center",
                            children: (0, m.jsx)(r.A, {})
                        }), (0, m.jsx)("div", {
                            id: "ele-23",
                            className: "absolute cross cursor-pointer",
                            onClick: C,
                            children: (0, m.jsx)("img", {
                                src: "https://cdn.express-chat.com/messenger/cross-1.svg",
                                alt: "close"
                            })
                        })]
                    })
                })
            }
            var x = s(47582),
                v = s(72796),
                f = s(32775),
                w = s(49672),
                p = s(86224),
                j = s(27945),
                k = s(56517),
                b = s(17472),
                N = s(53202),
                y = s(98656);

            function C(e) {
                let {
                    children: t
                } = e;
                const s = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    [l, a] = (0, i.useState)(!1),
                    o = (0, i.useCallback)((e => {
                        if (!s.enableChatWindowResize) return;
                        const t = e.clientX,
                            n = e.clientY,
                            i = window.top,
                            l = null === i || void 0 === i ? void 0 : i.innerWidth,
                            o = null === i || void 0 === i ? void 0 : i.innerHeight;
                        let r = 0;
                        const d = e => {
                                const s = Date.now();
                                if (s - r < 16) return;
                                r = s;
                                const i = window.parent.document.getElementById("BotPenguin-messenger");
                                if (!i) return void console.error("Chat window not found!");
                                const a = window.getComputedStyle(i),
                                    d = parseFloat(a.width),
                                    c = parseFloat(a.height);
                                let u = d - (e.clientX - t),
                                    h = c - (e.clientY - n);
                                l && o && (u = Math.max(100, Math.min(u, l - 20)), h = Math.max(100, Math.min(h, o - 20))), localStorage.setItem("userPreferredWidth", String(u)), localStorage.setItem("userPreferredHeight", String(h)), i.style.setProperty("transition", "width 0s ease, height 0s ease"), i.style.setProperty("width", `${u}px`, "important"), i.style.setProperty("height", `${h}px`, "important")
                            },
                            c = () => {
                                document.removeEventListener("mousemove", d), document.removeEventListener("mouseup", c), a(!1)
                            };
                        document.addEventListener("mousemove", d), document.addEventListener("mouseup", c), a(!0)
                    }), [s.enableChatWindowResize]);
                return (0, i.useEffect)((() => {
                    const e = e => o(e);
                    return () => {
                        document.removeEventListener("mousemove", e), document.removeEventListener("mouseup", e)
                    }
                }), [l, o]), (0, m.jsxs)("div", {
                    id: "resizable-box",
                    className: "relative",
                    children: [s.enableChatWindowResize && (0, m.jsxs)(m.Fragment, {
                        children: [(0, m.jsx)("div", {
                            className: "absolute z-40 top-0 left-0 h-full w-2.5 cursor-ew-resize bg-transparent",
                            onMouseDown: e => o(e)
                        }), (0, m.jsx)("div", {
                            className: "absolute z-40 top-0 left-0 w-full h-2.5 cursor-n-resize bg-transparent",
                            onMouseDown: e => o(e)
                        })]
                    }), t]
                })
            }

            function B() {
                const [e, t] = (0, i.useState)(!0), s = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)), l = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.messages)), a = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.ratingScreen)), o = (0, n.d4)((e => e && e.configuration ? e.configuration : void 0)), r = (0, n.d4)((e => e && e.footerTab)), [d, c] = (0, i.useState)({
                    currentPath: window.location.pathname,
                    start: !1,
                    shouldFetchData: !1
                });
                (0, i.useEffect)((() => {
                    (0, w.sE)(), t(!1)
                }), []), (0, i.useEffect)((() => {
                    const e = setTimeout((() => {
                        null !== s && void 0 !== s && s.fontFamilyLink && (0, f.Lr)(null === s || void 0 === s ? void 0 : s.fontFamilyLink);
                        let e = window.parent.document.getElementById("BotPenguin-messenger");
                        var t = new MutationObserver((function(e) {
                            e.forEach((function(e) {
                                (0, f.W2)()
                            }))
                        }));
                        e && t.observe(e, {
                            attributes: !0,
                            attributeFilter: ["style"]
                        }), localStorage.setItem("questions", JSON.stringify([]))
                    }), 100);
                    return () => clearTimeout(e)
                }), [s]), (0, i.useEffect)((() => {
                    const e = e => {
                        if ("BotPenguin" === e.data.origin)
                            if ("start" === e.data.action)(0, f.W2)(), !d.start && o && (0, p.lf)(o.generalSettings.notificationSound), l.length || d.start || (c({ ...d,
                                start: !0
                            }), (0, x.JC)(), (0, v.Mz)()), c({ ...d,
                                shouldFetchData: !0
                            });
                            else if ("hide" === e.data.action) {
                            (new window.parent.BotPenguin).closeWindow(), localStorage.setItem("bp-user-close", "true")
                        }
                    };
                    return window.addEventListener("message", e), () => {
                        window.removeEventListener("message", e)
                    }
                }));
                const u = e => {
                    var t, s;
                    switch (e) {
                        case "knowledgeBase":
                            return !!o && o.chatMenu && (null === (t = o.chatMenu.knowledgeBase) || void 0 === t ? void 0 : t.enabled);
                        case "tickets":
                            return !!o && o.chatMenu && (null === (s = o.chatMenu.ticketing) || void 0 === s ? void 0 : s.enabled);
                        default:
                            return !1
                    }
                };
                return (0, m.jsx)(m.Fragment, {
                    children: a ? (0, m.jsx)(g, {}) : (0, m.jsx)(m.Fragment, {
                        children: e ? (0, m.jsx)(m.Fragment, {
                            children: (0, m.jsx)(y.default, {})
                        }) : (0, m.jsxs)(C, {
                            children: ["Chat" === r && (0, m.jsxs)("div", {
                                id: "ele-3",
                                className: "h-dvh flex flex-col",
                                children: [(0, m.jsx)("div", {
                                    id: "ele-4",
                                    className: "flex-grow overflow-y-auto hide-scrollbar relative w-100",
                                    children: (0, m.jsx)(k.A, {
                                        design: s,
                                        shouldFetchData: d.shouldFetchData
                                    })
                                }), (u("knowledgeBase") || u("tickets")) && (0, m.jsx)("div", {
                                    id: "ele-5",
                                    className: "h-24 min-h-24",
                                    children: (0, m.jsx)(j.A, {})
                                })]
                            }), "Knowledge Base" === r && (0, m.jsxs)("div", {
                                id: "ele-6",
                                className: "h-dvh flex flex-col",
                                children: [(0, m.jsx)("div", {
                                    id: "ele-7",
                                    className: "flex-grow overflow-y-auto hide-scrollbar",
                                    children: (0, m.jsx)(b.A, {
                                        design: s
                                    })
                                }), (u("knowledgeBase") || u("tickets")) && (0, m.jsx)("div", {
                                    id: "ele-8",
                                    className: "h-24 min-h-24",
                                    children: (0, m.jsx)(j.A, {})
                                })]
                            }), "Tickets" === r && (0, m.jsxs)("div", {
                                id: "ele-9",
                                className: "h-dvh flex flex-col",
                                children: [(0, m.jsx)("div", {
                                    id: "ele-10",
                                    className: "flex-grow overflow-y-auto hide-scrollbar",
                                    children: (0, m.jsx)(N.A, {
                                        design: s
                                    })
                                }), (u("knowledgeBase") || u("tickets")) && (0, m.jsx)("div", {
                                    id: "ele-11",
                                    className: "h-24 min-h-24",
                                    children: (0, m.jsx)(j.A, {})
                                })]
                            })]
                        })
                    })
                })
            }
        },
        98656: (e, t, s) => {
            s.r(t), s.d(t, {
                default: () => i
            });
            var n = s(44414);

            function i() {
                return (0, n.jsxs)("div", {
                    id: "ele-167",
                    className: "h-dvh flex flex-col justify-between items-center",
                    children: [(0, n.jsxs)("div", {
                        id: "ele-168",
                        className: "skeleton-loader",
                        children: [(0, n.jsx)("div", {
                            id: "ele-169",
                            className: "skeleton-header h-12 rounded-xl"
                        }), (0, n.jsx)("div", {
                            id: "ele-170",
                            className: "left skeleton-text skeleton-title rounded-xl"
                        }), (0, n.jsx)("div", {
                            id: "ele-171",
                            className: "left skeleton-text skeleton-subtitle rounded-xl"
                        }), (0, n.jsx)("div", {
                            id: "ele-172",
                            className: "left skeleton-text skeleton-subtitle rounded-xl"
                        }), (0, n.jsx)("div", {
                            id: "ele-173",
                            className: "right skeleton-text skeleton-subtitle rounded-xl mt-2"
                        }), (0, n.jsx)("div", {
                            id: "ele-174",
                            className: "right skeleton-text skeleton-subtitle rounded-xl"
                        }), (0, n.jsx)("div", {
                            id: "ele-175",
                            className: "left skeleton-text skeleton-title rounded-xl"
                        }), (0, n.jsx)("div", {
                            id: "ele-176",
                            className: "right skeleton-text skeleton-subtitle rounded-xl mt-2"
                        }), (0, n.jsx)("div", {
                            id: "ele-177",
                            className: "right skeleton-text skeleton-subtitle rounded-xl"
                        }), (0, n.jsx)("div", {
                            id: "ele-178",
                            className: "right skeleton-text skeleton-title rounded-xl"
                        })]
                    }), (0, n.jsx)("div", {
                        id: "ele-179",
                        className: "skeleton-loader",
                        children: (0, n.jsx)("div", {
                            id: "ele-180",
                            className: "skeleton-input rounded-xl h-12 mt-auto",
                            children: (0, n.jsx)("div", {
                                id: "ele-181",
                                className: "skeleton-input-box rounded-xl"
                            })
                        })
                    })]
                })
            }
        }
    }
]);