(self.webpackChunkmessenger_v2 = self.webpackChunkmessenger_v2 || []).push([
    [9547], {
        80150: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => l
            });
            var i = s(26668);
            const l = e => ({
                type: i.R,
                payload: e
            })
        },
        56517: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => st
            });
            var i = s(9950),
                l = s(69772),
                n = s(10300),
                a = s(23507),
                o = s(43008),
                r = s(25817),
                d = s(11378),
                c = s(99603),
                u = s.n(c),
                m = s(44414);
            let h = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !1
            });

            function p(e) {
                const {
                    message: t,
                    currentIndex: s,
                    count: d,
                    topMargin: c
                } = e, u = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)), p = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)), g = (0, n.wA)(), [x, v] = (0, i.useState)([]);
                (0, i.useEffect)((() => {
                    v((() => t.options))
                }), [v, t.options]);
                const f = (0, i.useCallback)(((e, t, s) => {
                    if ("live_chat" === t.type) {
                        var i;
                        const {
                            flows: e
                        } = r.e.getState(), s = (null === (i = e[0]) || void 0 === i ? void 0 : i.questions).find((e => e.id === t.target));
                        g((0, l.h8)({
                            liveChat: !0,
                            activeQuestion: s,
                            activeQuestionType: null === s || void 0 === s ? void 0 : s.type
                        })), (0, a.GV)()
                    }
                    null !== s && void 0 !== s && s.length && g((0, l.h8)({
                        selectedTags: [...(null === p || void 0 === p ? void 0 : p.selectedTags) || [], ...s]
                    })), (0, o.Jx)(e, e, t.target)
                }), [g, null === p || void 0 === p ? void 0 : p.selectedTags]);
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        className: "ele-single-select max-w-80 w-fit relative",
                        children: [(0, m.jsx)("div", {
                            className: `ele-single-select-message-label rounded-tl-xl rounded-tr-xl py-2 px-4 bg-primaryBgColor ${c} ${"bubble"===u.singleSelectViewType?"w-fit rounded-br-xl":""}`,
                            children: (0, m.jsx)("p", {
                                className: "prose",
                                dangerouslySetInnerHTML: {
                                    __html: h.render(t.label)
                                }
                            })
                        }), (!u.singleSelectViewType || "list" === u.singleSelectViewType) && s === d - 1 && (0, m.jsx)("div", {
                            className: "options-container  border-solid border-2 border-t-0 border-primaryBgColor rounded-bl-xl rounded-br-xl",
                            children: x.map(((e, t) => (0, m.jsx)("div", {
                                onClick: () => {
                                    var t;
                                    return f(e.value, e.next || null, null === e || void 0 === e || null === (t = e.actionBasedChatResponse) || void 0 === t ? void 0 : t.tagIds)
                                },
                                className: `ele-list-single-select bg-white option flex cursor-pointer justify-center p-2 items-center border-solid border-t-2 border-primaryBgColor hover:bg-primaryBgColor ${t===x.length-1?"hover:rounded-b-lg":""} last:rounded-b-lg`,
                                children: (0, m.jsx)("p", {
                                    className: "text-primaryColor text-center",
                                    style: {
                                        color: null === u || void 0 === u ? void 0 : u.themeColor
                                    },
                                    children: e.value
                                })
                            }, e._id + e.id)))
                        }), "bubble" === u.singleSelectViewType && s === d - 1 && (0, m.jsx)("div", {
                            className: "flex flex-wrap ele-single-select-bubble-container",
                            children: x.map(((e, t) => (0, m.jsx)("div", {
                                onClick: () => {
                                    var t;
                                    return f(e.value, e.next || null, null === e || void 0 === e || null === (t = e.actionBasedChatResponse) || void 0 === t ? void 0 : t.tagIds)
                                },
                                className: `ele-bubble-single-select bg-white mt-2 mr-2 text-center border border-${null!==u&&void 0!==u&&u.themeColor?"["+(null===u||void 0===u?void 0:u.themeColor)+"]":"primaryColor"} px-3 py-2 rounded-full cursor-pointer w-fit hover:bg-primaryBgColor hover:border-primaryBgColor`,
                                children: (0, m.jsx)("p", {
                                    className: "text-primaryColor text-center",
                                    style: {
                                        color: null === u || void 0 === u ? void 0 : u.themeColor
                                    },
                                    children: e.value
                                })
                            }, "bubble " + e._id + e.id)))
                        })]
                    })
                })
            }
            h.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            var g = s(94879),
                x = s(38612),
                v = s(94453),
                f = s(1092);

            function b(e) {
                const {
                    message: t,
                    show: s
                } = e, [l, n] = (0, i.useState)(null), a = Boolean(l), o = !!localStorage.getItem("agentId"), d = () => {
                    n(null)
                }, c = e => {
                    if ("copy" === e) {
                        const e = (null === t || void 0 === t ? void 0 : t.text) || (null === t || void 0 === t ? void 0 : t.label);
                        navigator.clipboard.writeText(e)
                    } else "reply" === e && r.e.dispatch((0, f.Zd)(t));
                    d()
                };
                return o ? (0, m.jsxs)("div", {
                    className: "ele-message-action absolute right-1 text-white top-1 cursor-pointer",
                    children: [(s || a) && (0, m.jsx)("div", {
                        className: "ele-message-action-options h-8 w-8 bg-white text-center rounded-full flex items-center justify-center hover:border",
                        children: (0, m.jsx)(v.A, {
                            onClick: e => {
                                n(e.currentTarget)
                            },
                            fontSize: "medium",
                            id: "basic-button",
                            "aria-controls": a ? "basic-menu" : void 0,
                            "aria-haspopup": "true",
                            "aria-expanded": a ? "true" : void 0,
                            className: "text-primaryText"
                        })
                    }), (0, m.jsxs)(g.A, {
                        id: "basic-menu",
                        anchorEl: l,
                        open: a,
                        onClose: d,
                        MenuListProps: {
                            "aria-labelledby": "basic-button"
                        },
                        children: [(0, m.jsx)(x.A, {
                            onClick: () => c("reply"),
                            children: (0, m.jsx)("span", {
                                className: "font-mRegular text-primaryText text-sm",
                                children: " Reply"
                            })
                        }), (0, m.jsx)(x.A, {
                            onClick: () => c("copy"),
                            children: (0, m.jsx)("span", {
                                className: "font-mRegular text-primaryTex text-sm",
                                children: "Copy"
                            })
                        })]
                    })]
                }) : null
            }
            var j = s(71201),
                y = s(21270);

            function w(e) {
                var t, s;
                const {
                    backgroundColor: i,
                    parentMessage: l,
                    messagePosition: n
                } = e, a = (null === l || void 0 === l ? void 0 : l.label) || (null === l || void 0 === l ? void 0 : l.text);
                return (0, m.jsxs)("div", {
                    className: "ele-text-message-parent flex relative min-w-[150px] d-flex h-100  my-2 text-sm",
                    children: [(0, m.jsx)("div", {
                        className: "ele-text-message-status-indicator w-[3px] rounded-[10px] scroll-my-3 mr-1 py-5",
                        style: {
                            backgroundColor: i
                        }
                    }), (0, m.jsxs)("div", {
                        className: "ele-text-message-content rounded-xl py-2 px-4 bg-primaryColor break-words overflow-hidden truncate w-full " + ("right" === n ? "text-white" : ""),
                        style: {
                            backgroundColor: i
                        },
                        title: a,
                        children: [(0, m.jsx)("p", {
                            className: "ele-text-message-sender m-0 opacity-70",
                            children: (null === l || void 0 === l ? void 0 : l.messagedBy) || "you"
                        }), (0, m.jsxs)("div", {
                            className: "ele-text-media-container-sender flex justify-start items-center",
                            children: [(null === l || void 0 === l ? void 0 : l.medias) && (null === l || void 0 === l ? void 0 : l.medias[0]) && "image" === (null === l || void 0 === l ? void 0 : l.medias[0].type) && (0, m.jsxs)(m.Fragment, {
                                children: [(0, m.jsx)("img", {
                                    className: "ele-image-container-sender",
                                    alt: "parent-reply",
                                    src: null === l || void 0 === l || null === (t = l.medias[0]) || void 0 === t ? void 0 : t.url,
                                    width: "40",
                                    height: "40"
                                }), (0, m.jsx)("p", {
                                    className: "ele-image-caption-container-sender mb-0 ml-2",
                                    children: "photo"
                                })]
                            }), (null === l || void 0 === l ? void 0 : l.medias) && (null === l || void 0 === l ? void 0 : l.medias[0]) && "video" === (null === l || void 0 === l ? void 0 : l.medias[0].type) && (0, m.jsxs)(m.Fragment, {
                                children: [(0, m.jsx)("video", {
                                    className: "ele-video-container-sender",
                                    src: null === l || void 0 === l || null === (s = l.medias[0]) || void 0 === s ? void 0 : s.url,
                                    width: "40",
                                    height: "40"
                                }), (0, m.jsx)("p", {
                                    className: "ele-video-caption-container-sender mb-0 ml-2",
                                    children: "video"
                                })]
                            }), (null === l || void 0 === l ? void 0 : l.medias) && (null === l || void 0 === l ? void 0 : l.medias[0]) && "document" === (null === l || void 0 === l ? void 0 : l.medias[0].type) && (0, m.jsxs)(m.Fragment, {
                                children: [(0, m.jsx)(j.A, {
                                    fontSize: "medium",
                                    id: "description-icon",
                                    "aria-haspopup": "true"
                                }), (0, m.jsx)("p", {
                                    className: "ele-document-caption-container-sender mb-0 ml-2",
                                    children: "document"
                                })]
                            }), (null === l || void 0 === l ? void 0 : l.medias) && (null === l || void 0 === l ? void 0 : l.medias[0]) && "audio" === (null === l || void 0 === l ? void 0 : l.medias[0].type) && (0, m.jsxs)(m.Fragment, {
                                children: [(0, m.jsx)(y.A, {
                                    fontSize: "medium",
                                    id: "audiotrackIcon-icon",
                                    "aria-haspopup": "true"
                                }), (0, m.jsx)("p", {
                                    className: "ele-video-caption-container-sender mb-0 ml-2",
                                    children: "audio"
                                })]
                            })]
                        }), a && (!(null !== l && void 0 !== l && l.medias) || !(null !== l && void 0 !== l && l.medias.length)) && (0, m.jsx)(m.Fragment, {
                            children: a
                        })]
                    })]
                })
            }
            var N = s(51162);
            const k = () => (0, m.jsx)("div", {
                id: "ele-278",
                className: "main-container fade-in",
                children: (0, m.jsx)("div", {
                    id: "ele-280",
                    className: "rounded-xl py-3 px-5 max-w-80 bg-primaryBgColor relative rounded-bl-none mt-3 min-w-20 ",
                    children: (0, m.jsx)("img", {
                        className: "h-5",
                        src: "https://cdn.express-chat.com/messenger/typing.gif",
                        alt: "loading..."
                    })
                })
            });

            function C() {
                return (0, m.jsx)("div", {
                    className: "spectrum-container flex items-center justify-center h-spectrum w-spectrum bg-bpPrimary rounded-full cursor-pointer",
                    children: (0, m.jsxs)("div", {
                        className: "spectrum flex items-center",
                        children: [(0, m.jsx)("div", {
                            className: "bar bg-white opacity-50 w-spectrum-bar rounded-md"
                        }), (0, m.jsx)("div", {
                            className: "bar bg-white opacity-50 w-spectrum-bar rounded-md"
                        }), (0, m.jsx)("div", {
                            className: "bar bg-white opacity-50 w-spectrum-bar rounded-md"
                        })]
                    })
                })
            }
            var S = s(32775);
            let T = (0, d.A)({
                html: !0,
                linkify: !0,
                typographer: !0,
                breaks: !0
            });
            T.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            const E = e => {
                (0, N.Ad)(e).catch((e => console.log(e)))
            };

            function A(e) {
                var t, s, a, o, r, d, c, u;
                const {
                    message: h,
                    topMargin: p
                } = e, g = (0, n.d4)((e => e.environment)), x = (0, n.wA)(), v = null === g || void 0 === g ? void 0 : g.activeMID, [f, b] = (0, i.useState)(e.hasClickedThumbsUp || !1), [j, y] = (0, i.useState)(e.hasClickedThumbsUp || !1), [w, A] = (0, i.useState)(""), [M, B] = (0, i.useState)(0), [I, _] = (0, i.useState)(""), [R, F] = (0, i.useState)(""), L = null === g || void 0 === g || null === (t = g.chatMenu) || void 0 === t || null === (s = t.voiceSupport) || void 0 === s ? void 0 : s.isEnabled;
                (0, i.useEffect)((() => {
                    var e, t;
                    const s = g.isResponseStreamingEnabled,
                        i = v === h.mid,
                        n = null !== (e = null === g || void 0 === g || null === (t = g.ai) || void 0 === t ? void 0 : t.streaming) && void 0 !== e && e;
                    if (!s) return A(null === h || void 0 === h ? void 0 : h.label), void(i && L && g.isVoiceOutputEnabled);
                    if (i) {
                        if (i && n) {
                            const e = setInterval((() => {
                                if (M < (null === h || void 0 === h ? void 0 : h.label.length)) {
                                    const e = (null === h || void 0 === h ? void 0 : h.label.indexOf(" ", M + 1)) + 1 || (null === h || void 0 === h ? void 0 : h.label.length),
                                        t = null === h || void 0 === h ? void 0 : h.label.slice(M, e);
                                    A((e => e + `${t}`)), B(e), L && g.isVoiceOutputEnabled && _((e => {
                                        const s = e + t;
                                        return /[.!?,:;]/.test(t) ? (F(R + s), "") : s
                                    }))
                                } else clearInterval(e), x((0, l.rk)({
                                    streaming: !1
                                })), L && I && g.isVoiceOutputEnabled && (F((e => e + I)), _("")), x((0, l.h8)({
                                    isVoiceOutputEnabled: !1
                                }))
                            }), 200);
                            return () => clearInterval(e)
                        }
                    } else A(null === h || void 0 === h ? void 0 : h.label)
                }), [h.label, M, I, v, x, R, _, g.isResponseStreamingEnabled, null === g || void 0 === g || null === (a = g.ai) || void 0 === a ? void 0 : a.streaming, null === g || void 0 === g || null === (o = g.chatMenu) || void 0 === o || null === (r = o.voiceSupport) || void 0 === r ? void 0 : r.isEnabled, g.isVoiceOutputEnabled, h.mid, L]);
                const D = e => {
                    "thumbsUp" === e ? (b(!0), y(!1), E({
                        mid: h.mid,
                        hasClickedThumbsUp: !0,
                        hasClickedThumbsDown: !1
                    })) : (b(!1), y(!0), E({
                        mid: h.mid,
                        hasClickedThumbsUp: !1,
                        hasClickedThumbsDown: !0
                    }))
                };
                return (0, m.jsx)(m.Fragment, {
                    children: w ? (0, m.jsx)("div", {
                        className: "main-container fade-in ai mb-3 max-w-80",
                        children: (0, m.jsx)("div", {
                            className: "message flex items-end",
                            children: (0, m.jsxs)("div", {
                                className: `rounded-xl py-2 px-4 bg-primaryBgColor relative  ${p}`,
                                children: [(0, m.jsx)("div", {
                                    onClick: e => {
                                        "IMG" === e.target.tagName && x((0, l.h8)({
                                            imagePreview: {
                                                isActive: !0,
                                                src: e.target.currentSrc
                                            }
                                        }))
                                    },
                                    className: "ele-text-message-label prose " + (null !== h && void 0 !== h && h._parent ? "ml-4" : ""),
                                    dangerouslySetInnerHTML: {
                                        __html: T.render((P = (0, N.$8)(w || ""), P.replace(/\\n/g, "\n").replace(/^-(?=[^\s\n])/gm, "- ").replace(/>(\*{1,2})([a-zA-Z\xc0-\u017e\u0400-\u04ff0-9])/g, ">$1 $2")))
                                    }
                                }), "right" !== h.position && h.shouldFeedbackVisible && (0, m.jsxs)("div", {
                                    className: "text-right mt-1 ele-text-message-feedback",
                                    children: [g.activeMID === h.mid && "ai" === (null === g || void 0 === g || null === (d = g.activeQuestion) || void 0 === d ? void 0 : d.type.toLowerCase()) && (null === g || void 0 === g || null === (c = g.chatMenu) || void 0 === c || null === (u = c.voiceSupport) || void 0 === u ? void 0 : u.isEnabled) && (null === g || void 0 === g ? void 0 : g.isVoiceOutputEnabled) && (0, m.jsx)("div", {
                                        className: "inline-block mr-1",
                                        onClick: () => {
                                            (0, S.OK)()
                                        },
                                        children: (0, m.jsx)(C, {})
                                    }), f ? (0, m.jsx)("img", {
                                        onClick: () => D("thumbsUp"),
                                        alt: "refresh",
                                        className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                        src: "https://cdn.express-chat.com/messenger/thumbs-up.svg"
                                    }) : (0, m.jsx)("img", {
                                        onClick: () => D("thumbsUp"),
                                        src: "https://cdn.express-chat.com/messenger/thumbs-up-blank.svg",
                                        alt: "refresh",
                                        className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                        onMouseEnter: e => {
                                            e.target.src = "https://cdn.express-chat.com/messenger/thumbs-up.svg"
                                        },
                                        onMouseLeave: e => {
                                            e.target.src = "https://cdn.express-chat.com/messenger/thumbs-up-blank.svg"
                                        }
                                    }), j ? (0, m.jsx)("img", {
                                        onClick: () => D("thumbsDown"),
                                        src: "https://cdn.express-chat.com/messenger/thumbs-down.svg",
                                        alt: "refresh",
                                        className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer"
                                    }) : (0, m.jsx)("img", {
                                        onClick: () => D("thumbsDown"),
                                        src: "https://cdn.express-chat.com/messenger/thumbs-down-blank.svg",
                                        alt: "refresh",
                                        className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                        onMouseEnter: e => {
                                            e.target.src = "https://cdn.express-chat.com/messenger/thumbs-down.svg"
                                        },
                                        onMouseLeave: e => {
                                            e.target.src = "https://cdn.express-chat.com/messenger/thumbs-down-blank.svg"
                                        }
                                    })]
                                })]
                            })
                        })
                    }) : (0, m.jsx)(k, {})
                });
                var P
            }
            let M = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !1
            });

            function B(e) {
                const {
                    message: t,
                    topMargin: s
                } = e, [l, n] = (0, i.useState)(e.hasClickedThumbsUp || !1), [a, o] = (0, i.useState)(e.hasClickedThumbsDown || !1), [r, d] = (0, i.useState)(!1), c = e => {
                    "thumbsUp" === e ? (n(!0), o(!1), E({
                        mid: t.mid,
                        hasClickedThumbsUp: !0,
                        hasClickedThumbsDown: !1
                    })) : (n(!1), o(!0), E({
                        mid: t.mid,
                        hasClickedThumbsUp: !1,
                        hasClickedThumbsDown: !0
                    }))
                };
                return (0, m.jsx)(m.Fragment, {
                    children: "user" !== t.messagedBy && (0, m.jsxs)("div", {
                        className: `ele-text-message rounded-xl py-2 px-4 max-w-80 bg-primaryBgColor relative ${s} inline-block`,
                        onMouseEnter: () => {
                            d(!0)
                        },
                        onMouseLeave: () => {
                            d(!1)
                        },
                        children: [t._parent ? (0, m.jsx)(w, {
                            parentMessage: t._parent,
                            backgroundColor: "#EBEDED",
                            messagePosition: t.position
                        }) : null, t.shouldFeedbackVisible ? (0, m.jsx)("div", {
                            className: "ele-text-message-label prose " + (null !== t && void 0 !== t && t._parent ? "ml-4" : ""),
                            dangerouslySetInnerHTML: {
                                __html: M.render(t.label)
                            }
                        }) : (0, m.jsx)("div", {
                            className: null !== t && void 0 !== t && t._parent ? "ml-4 ele-text-message-label prose" : "ele-text-message-label prose",
                            dangerouslySetInnerHTML: {
                                __html: M.render(t.label)
                            }
                        }), "right" !== t.position && t.shouldFeedbackVisible && (0, m.jsxs)("div", {
                            className: "text-right mt-1 ele-text-message-feedback",
                            children: [l ? (0, m.jsx)("img", {
                                onClick: () => c("thumbsUp"),
                                alt: "refresh",
                                className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                src: "https://cdn.express-chat.com/messenger/thumbs-up.svg"
                            }) : (0, m.jsx)("img", {
                                onClick: () => c("thumbsUp"),
                                src: "https://cdn.express-chat.com/messenger/thumbs-up-blank.svg",
                                alt: "refresh",
                                className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                onMouseEnter: e => {
                                    e.target.src = "https://cdn.express-chat.com/messenger/thumbs-up.svg"
                                },
                                onMouseLeave: e => {
                                    e.target.src = "https://cdn.express-chat.com/messenger/thumbs-up-blank.svg"
                                }
                            }), a ? (0, m.jsx)("img", {
                                onClick: () => c("thumbsDown"),
                                src: "https://cdn.express-chat.com/messenger/thumbs-down.svg",
                                alt: "refresh",
                                className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer"
                            }) : (0, m.jsx)("img", {
                                onClick: () => c("thumbsDown"),
                                src: "https://cdn.express-chat.com/messenger/thumbs-down-blank.svg",
                                alt: "refresh",
                                className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                onMouseEnter: e => {
                                    e.target.src = "https://cdn.express-chat.com/messenger/thumbs-down.svg"
                                },
                                onMouseLeave: e => {
                                    e.target.src = "https://cdn.express-chat.com/messenger/thumbs-down-blank.svg"
                                }
                            })]
                        }), (0, m.jsx)(b, {
                            message: t,
                            show: r
                        })]
                    })
                })
            }
            M.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            let I = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !1
            });

            function _(e) {
                const t = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    s = (0, n.wA)(),
                    {
                        message: l,
                        currentIndex: a,
                        count: o,
                        topMargin: r
                    } = e,
                    [d, c] = (0, i.useState)([{
                        value: "Option 1",
                        status: !1
                    }]),
                    [u, h] = (0, i.useState)([]);
                (0, i.useEffect)((() => {
                    c((() => l.options))
                }), [l.options]);
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        className: "ele-multi-select max-w-80 w-fit",
                        children: [(0, m.jsx)("div", {
                            className: `ele-multi-select-message-label rounded-tl-xl rounded-tr-xl py-2 px-4 bg-primaryBgColor ${r}`,
                            children: (0, m.jsx)("p", {
                                className: "prose",
                                dangerouslySetInnerHTML: {
                                    __html: I.render(l.label)
                                }
                            })
                        }), a === o - 1 && (0, m.jsx)("div", {
                            className: "options-container  border-solid border-2 border-t-0 border-primaryBgColor rounded-bl-xl rounded-br-xl",
                            children: d.map(((e, i) => (0, m.jsxs)("div", {
                                onClick: t => (e => {
                                    let t = [];
                                    if (u.includes(e.value)) {
                                        const s = u.filter((t => t !== e.value));
                                        h(s), t = s
                                    } else t = [...u, e.value], h(t);
                                    s((0, f.VU)({
                                        value: t.join(", ")
                                    }))
                                })(e),
                                className: "ele-bubble-multiselect option cursor-pointer hover:bg-primaryBgColor flex justify-between p-2 items-center border-solid border-t-2 border-primaryBgColor " + (i === d.length - 1 ? "hover:rounded-b-lg" : ""),
                                children: [(0, m.jsx)("p", {
                                    className: "text-primaryColor",
                                    style: {
                                        color: null === t || void 0 === t ? void 0 : t.themeColor
                                    },
                                    children: e.value
                                }), (0, m.jsx)("input", {
                                    id: "link-checkbox",
                                    type: "checkbox",
                                    checked: u.includes(e.value),
                                    style: {
                                        accentColor: null === t || void 0 === t ? void 0 : t.themeColor
                                    },
                                    className: "w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded dark:bg-gray-700 dark:border-gray-600 focus:outline-none cursor-pointer ml-2.5",
                                    onChange: e => !1
                                })]
                            }, i + e.value)))
                        })]
                    })
                })
            }
            I.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            let R = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !1
            });

            function F(e) {
                const {
                    message: t,
                    currentIndex: s,
                    count: l,
                    topMargin: a
                } = e, r = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)), [d, c] = (0, i.useState)([]);
                (0, i.useEffect)((() => {
                    c(t.options)
                }), [t.options]);
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        className: "ele-rating-container max-w-80 w-fit",
                        children: [(0, m.jsx)("div", {
                            className: `ele-rating-message-label rounded-tl-xl rounded-tr-xl py-2 px-4 bg-primaryBgColor ${a}`,
                            children: (0, m.jsx)("p", {
                                className: "prose",
                                dangerouslySetInnerHTML: {
                                    __html: R.render(t.label)
                                }
                            })
                        }), s === l - 1 && (0, m.jsx)("div", {
                            className: "options-container  border-solid border-2 border-t-0 border-primaryBgColor rounded-bl-xl rounded-br-xl",
                            children: d.map(((e, t) => (0, m.jsx)("div", {
                                className: "ele-rating option flex cursor-pointer justify-center p-2 items-center border-solid border-t-2 border-primaryBgColor hover:bg-primaryBgColor  " + (t === d.length - 1 ? "hover:rounded-b-lg" : ""),
                                onClick: () => (e => {
                                    (0, o.Jx)(e.value)
                                })(e),
                                children: (0, m.jsx)("p", {
                                    id: "ele-238",
                                    className: "text-primaryColor text-center",
                                    style: {
                                        color: null === r || void 0 === r ? void 0 : r.themeColor
                                    },
                                    children: e.value
                                })
                            }, "rating " + t)))
                        })]
                    })
                })
            }
            R.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            var L = s(59254),
                D = s(61188);
            let P = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !1
            });
            P.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            const O = (0, L.Ay)(D.Ay)((e => {
                let {
                    theme: t
                } = e;
                return {
                    height: 5,
                    padding: "15px 0",
                    "& .MuiSlider-thumb": {
                        height: 24,
                        width: 24,
                        backgroundColor: "#fff",
                        boxShadow: "0 0 2px 0px rgba(0, 0, 0, 0.1)",
                        "&:focus, &:hover, &.Mui-active": {
                            boxShadow: "0px 0px 3px 1px rgba(0, 0, 0, 0.1)",
                            "@media (hover: none)": {
                                boxShadow: "0px 3px 8px #00000026"
                            }
                        },
                        "&:before": {
                            boxShadow: "0px 0px 1px 0px rgba(0,0,0,0.2), 0px 0px 0px 0px rgba(0,0,0,0.14), 0px 0px 1px 0px rgba(0,0,0,0.12)"
                        }
                    },
                    "& .MuiSlider-valueLabel": {
                        fontSize: 16,
                        fontWeight: "normal",
                        top: 58,
                        backgroundColor: "unset",
                        color: t.palette.text.primary,
                        "&::before": {
                            display: "none"
                        },
                        "& *": {
                            background: "transparent",
                            color: "dark" === t.palette.mode ? "#fff" : "#000"
                        }
                    },
                    "& .MuiSlider-track": {
                        border: "none",
                        height: 5
                    },
                    "& .MuiSlider-rail": {
                        opacity: .5,
                        boxShadow: "inset 0px 0px 4px -2px #000",
                        backgroundColor: "#d0d0d0"
                    }
                }
            }));

            function $(e) {
                const {
                    message: t,
                    currentIndex: s,
                    count: l,
                    topMargin: a
                } = e, [o, r] = (0, i.useState)([1, 100]), d = (0, n.wA)(), c = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)), u = (0, n.d4)((e => {
                    var t;
                    return null === e || void 0 === e || null === (t = e.environment) || void 0 === t ? void 0 : t.direction
                }));
                return (0, i.useEffect)((() => (s === l - 1 && d((0, f.VU)({
                    value: `${e.message.rangePrefix||""} ${o[0]} ${e.message.rangeSuffix||""} ${o[1]}`
                })), () => {
                    s === l - 1 && d((0, f.VU)({
                        value: "",
                        original: ""
                    }))
                })), [o, e, d, s, l]), (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        className: "w-4/6 ele-range",
                        children: [(0, m.jsx)("div", {
                            className: `ele-range-message-label rounded-xl py-2 px-4 w-fit bg-primaryBgColor ${a}`,
                            children: (0, m.jsx)("p", {
                                className: "prose",
                                dangerouslySetInnerHTML: {
                                    __html: P.render(t.label)
                                }
                            })
                        }), s === l - 1 && (0, m.jsxs)("div", {
                            className: "range-slider w-100 flex items-center mt-1",
                            children: [(0, m.jsx)("span", {
                                style: {
                                    marginLeft: 20
                                },
                                className: "text-gray-400 mr-2 ele-range-min-range",
                                children: t.minRange || 0
                            }), (0, m.jsx)(O, {
                                getAriaLabel: () => "Temperature range",
                                value: o,
                                style: {
                                    color: c.themeColor
                                },
                                onChange: (e, t) => {
                                    r(t)
                                },
                                valueLabelDisplay: "auto",
                                min: t.minRange || 0,
                                max: t.maxRange || 100,
                                step: t.rangeStep || 1
                            }), (0, m.jsx)("span", {
                                style: {
                                    marginLeft: 20
                                },
                                className: "text-gray-400 ele-range-max-range " + ("rtl" === u ? "mr-4" : "mr-2"),
                                children: t.maxRange || 100
                            })]
                        })]
                    })
                })
            }
            let z = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !1
            });
            z.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            const U = e => {
                const {
                    message: t,
                    topMargin: s
                } = e, [l, a] = (0, i.useState)(!1), o = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design));
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        className: `ele-image image-container relative inline-block rounded-xl py-2 px-4 max-w-80 bg-primaryBgColor max-w-image ${s} ${"right"===t.position&&"bg-primaryColor"}`,
                        onMouseEnter: () => {
                            a(!0)
                        },
                        onMouseLeave: () => {
                            a(!1)
                        },
                        children: [null !== t && void 0 !== t && t._parent ? (0, m.jsx)(w, {
                            backgroundColor: "right" === t.position ? (0, S.sG)(o.themeColor, 10) : "#EBEDED",
                            parentMessage: null === t || void 0 === t ? void 0 : t._parent,
                            messagePosition: t.position
                        }) : null, t.medias && t.medias.length ? t.medias.map((e => (0, m.jsx)(m.Fragment, {
                            children: (0, m.jsxs)("div", {
                                children: [(0, m.jsx)("span", {
                                    className: "mb-4 ele-image-message-label",
                                    children: e.caption
                                }), (0, m.jsx)("img", {
                                    className: "rounded-lg ele-image-src",
                                    src: e.url,
                                    alt: ""
                                })]
                            }, e.url + t.mid)
                        }))) : (0, m.jsxs)(m.Fragment, {
                            children: [(0, m.jsx)("span", {
                                className: "mb-4 ele-image-message-label prose",
                                dangerouslySetInnerHTML: {
                                    __html: z.render(t.label)
                                }
                            }), (0, m.jsx)("img", {
                                className: "rounded-lg ele-image-src",
                                src: t.source,
                                alt: ""
                            })]
                        }), (0, m.jsx)(b, {
                            message: t,
                            show: l
                        })]
                    })
                })
            };
            var W = s(38092),
                q = s.n(W);
            let V = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !1
            });
            V.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            const Q = e => {
                const {
                    message: t,
                    topMargin: s
                } = e, [l, a] = (0, i.useState)(!1), o = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design));
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        className: `ele-video image-container relative rounded-xl py-2 px-4 pb-4 max-w-80 bg-primaryBgColor ${s} v-border ${"right"===t.position&&"bg-primaryColor"}`,
                        onMouseEnter: () => {
                            a(!0)
                        },
                        onMouseLeave: () => {
                            a(!1)
                        },
                        children: [null !== t && void 0 !== t && t._parent ? (0, m.jsx)(w, {
                            backgroundColor: "right" === t.position ? (0, S.sG)(o.themeColor, 10) : "#EBEDED",
                            parentMessage: null === t || void 0 === t ? void 0 : t._parent,
                            messagePosition: t.position
                        }) : null, t.medias && t.medias.length ? t.medias.map((e => (0, m.jsx)(m.Fragment, {
                            children: (0, m.jsxs)("div", {
                                children: [(0, m.jsx)(q(), {
                                    url: e.url,
                                    controls: !0,
                                    playing: !1,
                                    width: "auto",
                                    config: {
                                        youtube: {
                                            playerVars: {
                                                origin: window.location.origin
                                            }
                                        }
                                    },
                                    style: {
                                        borderRadius: "10px"
                                    }
                                }), (0, m.jsx)(b, {
                                    message: t,
                                    show: l
                                })]
                            }, e.url + t.mid)
                        }))) : (0, m.jsxs)(m.Fragment, {
                            children: [(0, m.jsx)("p", {
                                className: "mb-2 ele-video-message-label prose",
                                dangerouslySetInnerHTML: {
                                    __html: V.render(t.label)
                                }
                            }), (0, m.jsx)(q(), {
                                url: t.source,
                                controls: !0,
                                playing: !1,
                                width: "auto",
                                config: {
                                    youtube: {
                                        playerVars: {
                                            origin: window.location.origin
                                        }
                                    }
                                },
                                style: {
                                    borderRadius: "10px"
                                }
                            })]
                        })]
                    })
                })
            };
            var H = s(29635);
            const G = e => {
                    const {
                        message: t,
                        topMargin: s
                    } = e, [l, a] = (0, i.useState)(!1), o = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)), r = e => {
                        const t = e.match(/\.([a-zA-Z0-9]+)(\?.*)?$/);
                        return t ? t[1] : ""
                    };
                    return (0, m.jsx)(m.Fragment, {
                        children: (0, m.jsxs)("div", {
                            className: `ele-document image-container relative inline-block rounded-xl py-2 px-2 max-w-80 bg-primaryBgColor max-w-image ${s} ${"right"===t.position&&"bg-primaryColor"}`,
                            onMouseEnter: () => {
                                a(!0)
                            },
                            onMouseLeave: () => {
                                a(!1)
                            },
                            children: [null !== t && void 0 !== t && t._parent ? (0, m.jsx)(w, {
                                backgroundColor: "right" === t.position ? (0, S.sG)(o.themeColor, 10) : "#EBEDED",
                                parentMessage: null === t || void 0 === t ? void 0 : t._parent,
                                messagePosition: t.position
                            }) : null, t.medias && t.medias.length ? t.medias.map((e => (0, m.jsxs)("div", {
                                className: "ele-document-container flex cursor-pointer h-[60px] w-full",
                                onClick: () => (e => {
                                    const t = document.createElement("a");
                                    document.body.appendChild(t), t.setAttribute("style", "display: none"), t.setAttribute("target", "_blank"), t.href = e, t.download = e.split("/").pop(), t.click(), window.URL.revokeObjectURL(e), t.remove()
                                })(e.url),
                                children: [(0, m.jsx)("div", {
                                    className: "ele-document-image-container w-16 bg-footerSelectedBG flex items-center justify-center flex-col rounded-l-xl",
                                    children: (0, m.jsx)(j.A, {
                                        fontSize: "medium",
                                        id: "description-icon",
                                        "aria-haspopup": "true",
                                        className: "text-primaryColor ele-document-image-icon"
                                    })
                                }), (0, m.jsxs)("div", {
                                    className: "ele-document-text-container flex p-4 items-center justify-between bg-white rounded-r-xl w-48 min-w-48 max-w-60",
                                    children: [(0, m.jsxs)("span", {
                                        className: "ele-document-text-message cursor-pointer",
                                        children: ["document.", r(e.url)]
                                    }), (0, m.jsx)("span", {
                                        className: "ele-document-download-container cursor-pointer bg-gray-100 p-1 rounded-full",
                                        children: (0, m.jsx)(H.A, {
                                            fontSize: "medium",
                                            id: "download-button",
                                            "aria-haspopup": "true",
                                            className: "text-primaryColor ele-document-download-btn"
                                        })
                                    })]
                                })]
                            }, e.url + t.mid))) : null, (0, m.jsx)(b, {
                                message: t,
                                show: l
                            })]
                        })
                    })
                },
                K = e => {
                    const {
                        message: t,
                        topMargin: s
                    } = e, [l, a] = (0, i.useState)(!1), o = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design));
                    return (0, m.jsx)(m.Fragment, {
                        children: (0, m.jsxs)("div", {
                            className: `ele-audio image-container relative inline-block rounded-xl py-2 px-4 max-w-80 bg-primaryBgColor max-w-image ${s} ${"right"===t.position&&"bg-primaryColor"}`,
                            onMouseEnter: () => {
                                a(!0)
                            },
                            onMouseLeave: () => {
                                a(!1)
                            },
                            children: [null !== t && void 0 !== t && t._parent ? (0, m.jsx)(w, {
                                backgroundColor: "right" === t.position ? (0, S.sG)(o.themeColor, 10) : "#EBEDED",
                                parentMessage: null === t || void 0 === t ? void 0 : t._parent,
                                messagePosition: t.position
                            }) : null, t.medias && t.medias.length ? t.medias.map((e => (0, m.jsxs)(m.Fragment, {
                                children: [(0, m.jsx)("span", {
                                    className: "mb-4 ele-audio-message-label",
                                    children: e.caption
                                }), (0, m.jsxs)("audio", {
                                    controls: !0,
                                    controlsList: "nodownload noplaybackrate nofullscreen",
                                    className: "d-block ele-audio-src",
                                    children: [(0, m.jsx)("source", {
                                        src: e.url,
                                        type: "audio/mpeg"
                                    }), "Your browser does not support the audio tag."]
                                })]
                            }))) : (0, m.jsxs)(m.Fragment, {
                                children: [(0, m.jsx)("span", {
                                    className: "mb-4 ele-audio-message-label",
                                    children: t.label
                                }), (0, m.jsxs)("audio", {
                                    controls: !0,
                                    controlsList: "nodownload noplaybackrate nofullscreen",
                                    className: "d-block ele-audio-src",
                                    children: [(0, m.jsx)("source", {
                                        src: t.source,
                                        type: "audio/mpeg"
                                    }), "Your browser does not support the audio tag."]
                                })]
                            }), (0, m.jsx)(b, {
                                message: t,
                                show: l
                            })]
                        })
                    })
                };
            var J = s(84892);
            let Y = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !1
            });

            function Z(e) {
                const {
                    message: t,
                    topMargin: s
                } = e, [l, n] = (0, i.useState)([{
                    value: "https://botpenguin.com",
                    title: "Visit Telegram"
                }, {
                    value: "https://botpenguin.com",
                    title: "Visit Instagram"
                }, {
                    value: "https://botpenguin.com",
                    title: "Visit Facebook"
                }, {
                    value: "https://botpenguin.com",
                    title: "Visit Website"
                }]);
                (0, i.useEffect)((() => {
                    n((() => t.links))
                }), [t]);
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        className: "max-w-80 ele-contact",
                        children: [(0, m.jsx)("div", {
                            id: "ele-247",
                            className: `ele-contact-message-label rounded-tl-xl rounded-tr-xl w-fit py-2 px-4 bg-primaryBgColor ${s}`,
                            children: (0, m.jsx)("p", {
                                className: "prose",
                                dangerouslySetInnerHTML: {
                                    __html: Y.render(t.label)
                                }
                            })
                        }), (0, m.jsx)("div", {
                            className: "ele-contact-options options-container max-w-70 border-solid border-2 border-t-0 border-primaryBgColor rounded-bl-xl rounded-br-xl",
                            children: l.map((e => (0, m.jsx)(m.Fragment, {
                                children: (0, m.jsxs)("div", {
                                    className: "ele-contacts link cursor-pointer  flex justify-center p-2 items-center border-solid border-t-2 border-primaryBgColor hover:bg-secondaryBgColor",
                                    onClick: () => {
                                        return t = e.value, void window.open(t, "_blank");
                                        var t
                                    },
                                    children: [(0, m.jsx)(J.A, {
                                        className: "ele-contacts-launch-icon text-primaryColor text-base mr-1"
                                    }), (0, m.jsx)("p", {
                                        id: "ele-250",
                                        className: "ele-contacts-link-title text-primaryColor ",
                                        children: e.title
                                    })]
                                })
                            })))
                        })]
                    })
                })
            }
            Y.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            const X = e => {
                const t = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    s = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment));
                return "top" === t.avatarPlacement ? (0, m.jsxs)("div", {
                    className: "flex",
                    children: [(0, m.jsx)("img", {
                        className: `ele-bot-icon avatar border-secondaryBgColor ${t.avatarOutlineOffMessage?"":"border-2"} mt-2 ${"ltr"===(null===s||void 0===s?void 0:s.direction)?"mr-2":"ml-2"}`,
                        alt: "",
                        style: {
                            width: 25 * (t.avatarIconSizeMessageBubble || 1) + "px",
                            height: 25 * (t.avatarIconSizeMessageBubble || 1) + "px",
                            borderRadius: "50%"
                        },
                        src: "agent" === e.type && s.agentAvatar || t.avatar
                    }), "top" === t.avatarPlacement && (0, m.jsx)("p", {
                        className: "ele-text-bot-name mt-auto text-xs",
                        style: {
                            color: "#333333"
                        },
                        children: "agent" === e.type && s.agentName ? s.agentName : t.name
                    })]
                }) : (0, m.jsx)("img", {
                    className: `ele-bot-icon avatar border-secondaryBgColor ${t.avatarOutlineOffMessage?"":"border-2"} mt-2 ${"ltr"===(null===s||void 0===s?void 0:s.direction)?"mr-2":"ml-2"}`,
                    alt: "",
                    style: {
                        width: 42 * (t.avatarIconSizeMessageBubble || 1) + "px",
                        height: 42 * (t.avatarIconSizeMessageBubble || 1) + "px",
                        borderRadius: "50%"
                    },
                    src: "agent" === e.type && s.agentAvatar || t.avatar
                })
            };

            function ee() {
                const e = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design));
                return (0, m.jsx)("div", {
                    id: "ele-278",
                    className: "main-container fade-in",
                    children: (0, m.jsxs)("div", {
                        id: "ele-279",
                        className: "message items-end  " + ("top" !== e.avatarPlacement ? "flex" : ""),
                        children: [(0, m.jsx)(X, {
                            type: "bot"
                        }), (0, m.jsx)("div", {
                            id: "ele-280",
                            className: "rounded-xl py-3 px-5 max-w-80 bg-primaryBgColor relative rounded-bl-none mt-3 min-w-20 " + ("top" === e.avatarPlacement ? "inline-block" : ""),
                            children: (0, m.jsx)("img", {
                                className: "h-5",
                                src: "https://cdn.express-chat.com/messenger/typing.gif",
                                alt: "loading..."
                            })
                        })]
                    })
                })
            }

            function te(e) {
                const {
                    message: t
                } = e;
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsx)("div", {
                        className: "ele-push-notification text-center mt-5 mb-5",
                        children: (0, m.jsxs)("div", {
                            className: "ele-push-notification-body text-center",
                            children: ["blue" === t.color ? (0, m.jsxs)("h5", {
                                className: "text-bpPrimary ele-push-notification-title",
                                children: [t.title, " "]
                            }) : (0, m.jsxs)("h5", {
                                className: "text-bpRed ele-push-notification-error-title",
                                children: [t.title, " "]
                            }), (0, m.jsx)("p", {
                                className: "text-secondaryText ele-push-notification-text",
                                children: t.text
                            })]
                        })
                    })
                })
            }
            var se = s(15291);

            function ie(e) {
                const t = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    s = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.configuration));
                return (0, m.jsxs)("div", {
                    className: "ele-system-message flex align-middle justify-around items-center w-full mt-2",
                    children: [(0, m.jsx)("div", {
                        className: "ele-system-message-line line"
                    }), (() => {
                        switch (e.method) {
                            case "chat-request-accepted":
                                return (0, m.jsx)(m.Fragment, {
                                    children: (0, m.jsxs)("p", {
                                        dir: "ltr",
                                        className: "ele-system-message-accepted text-secondaryText text-xs p-2 pl-2 pr-2 flex text-center align-middle items-center",
                                        children: [(0, m.jsx)("span", {
                                            className: "font-bold ele-system-message-agent-name",
                                            style: {
                                                color: s.chatMenu.liveChatInitiatePrimaryColor || "#226CF4"
                                            },
                                            children: e.agentName || "Agent"
                                        }), " \xa0 has joined the chat"]
                                    })
                                });
                            case "initiating-live-chat":
                                return (0, m.jsx)(m.Fragment, {
                                    children: (0, m.jsxs)("div", {
                                        className: "ele-system-message-initiate text-secondaryText text-xs p-2 pl-2 pr-2 flex flex-col text-center align-middle items-center",
                                        children: [(0, m.jsx)("div", {
                                            className: "ele-system-message-title",
                                            style: {
                                                color: s.chatMenu.liveChatInitiatePrimaryColor || "#226CF4"
                                            },
                                            children: e.title
                                        }), (0, m.jsx)("div", {
                                            className: "ele-systyem-message-subtitle",
                                            style: {
                                                color: s.chatMenu.liveChatInitiateSecondaryColor || "#333333"
                                            },
                                            children: e.subTitle
                                        })]
                                    })
                                });
                            case "no-agent-found":
                                return (0, m.jsx)(m.Fragment, {
                                    children: (0, m.jsxs)("div", {
                                        className: "ele-system-message-no-agent text-secondaryText text-xs p-2 pl-2 pr-2 flex flex-col text-center align-middle items-center",
                                        children: [(0, m.jsx)("div", {
                                            className: "ele-system-message-title",
                                            style: {
                                                color: s.chatMenu.liveChatUnavailablePrimaryColor || "#b3261e"
                                            },
                                            children: e.title
                                        }), (0, m.jsx)("div", {
                                            className: "ele-systyem-message-subtitle",
                                            style: {
                                                color: s.chatMenu.liveChatInitiateSecondaryColor || "#333333"
                                            },
                                            children: e.subTitle
                                        })]
                                    })
                                });
                            default:
                                return (0, m.jsx)(m.Fragment, {
                                    children: (0, m.jsxs)("div", {
                                        className: "ele-system-message-default text-secondaryText text-xs p-2 pl-2 pr-2 flex flex-col text-center align-middle items-center",
                                        children: [(0, m.jsx)("div", {
                                            className: "ele-system-message-title",
                                            style: {
                                                color: t.themeColor || "#226CF4"
                                            },
                                            children: e.title
                                        }), (0, m.jsx)("div", {
                                            className: "ele-systyem-message-subtitle",
                                            children: e.subTitle
                                        })]
                                    })
                                })
                        }
                    })(), (0, m.jsx)("div", {
                        className: "ele-system-message-line line"
                    })]
                })
            }
            var le = s(59051),
                ne = s.n(le);

            function ae(e) {
                var t, l, a;
                const {
                    message: o
                } = e, r = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.configuration)), d = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)), c = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)), [u, h] = (0, i.useState)((new Date).toISOString());
                (0, i.useEffect)((() => {
                    var e;
                    return (async e => {
                        try {
                            await s(6391)(`./${e}`), ne().locale(e), h((new Date).toISOString())
                        } catch (t) {
                            ne().locale("en"), h((new Date).toISOString())
                        }
                    })(null === r || void 0 === r || null === (e = r.generalSettings) || void 0 === e ? void 0 : e.language).catch((e => console.log(e))), () => {
                        ne().locale("en")
                    }
                }), [null === r || void 0 === r || null === (t = r.generalSettings) || void 0 === t ? void 0 : t.language]), (0, i.useEffect)((() => {
                    const e = setInterval((() => {
                        h((new Date).toISOString())
                    }), 1e4);
                    return () => clearInterval(e)
                }), []);
                const p = e => {
                    const t = new Date(e).toISOString();
                    try {
                        return ne()(t).isBefore(ne()().subtract(30, "seconds")) ? ne()(t).isBefore(ne()().subtract(1, "days")) ? " . " + ne()(t).format("lll") : " . " + ne()(t).format("LT") : " " + ne()(t).fromNow()
                    } catch (s) {
                        return ""
                    }
                };
                return o && o.createdAt && p(null === o || void 0 === o ? void 0 : o.createdAt) && (null === r || void 0 === r ? void 0 : r.generalSettings) && (0, m.jsx)(m.Fragment, {
                    children: "right" !== o.position && (0, m.jsxs)("p", {
                        id: "ele-275",
                        className: "messaged-by p-2  text-secondaryText text-xs",
                        style: { ..."top" !== (null === d || void 0 === d ? void 0 : d.avatarPlacement) && {
                                marginLeft: "54px"
                            }
                        },
                        children: ["agent" === o.messageBy ? `${c.agentName}` : "" + (null !== r && void 0 !== r && null !== (l = r.chatMenu) && void 0 !== l && l.botMessageSubScript ? `${null===r||void 0===r||null===(a=r.chatMenu)||void 0===a?void 0:a.botMessageSubScript}` : ""), p(null === o || void 0 === o ? void 0 : o.createdAt), " "]
                    })
                })
            }
            var oe = s(66699),
                re = s(42209),
                de = s(87305),
                ce = s(42834);
            const ue = e => {
                    const t = (0, n.wA)(),
                        {
                            label: s,
                            source: o,
                            iframeTitle: r,
                            justHide: d
                        } = e,
                        [c, u] = (0, i.useState)(!1),
                        h = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                        p = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)),
                        [g, x] = (0, i.useState)("collapsed"),
                        v = () => {
                            const e = "collapsed" === g ? "expanded" : "collapsed";
                            x(e), "expanded" === e ? window.parent.postMessage({
                                origin: "BotPenguin",
                                action: "ele-expand"
                            }, "*") : window.parent.postMessage({
                                origin: "BotPenguin",
                                action: "ele-collapse"
                            }, "*")
                        };
                    return (0, i.useEffect)((() => () => {
                        window.parent.postMessage({
                            origin: "BotPenguin",
                            action: "ele-collapse"
                        }, "*")
                    }), []), (0, i.useEffect)((() => {
                        const e = document.getElementById("dynamicText");
                        if (e) {
                            const t = function(e) {
                                let [t, s, i] = e.match(/\d+/g).map(Number);
                                return t /= 255, s /= 255, i /= 255, t = t <= .03928 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4), s = s <= .03928 ? s / 12.92 : Math.pow((s + .055) / 1.055, 2.4), i = i <= .03928 ? i / 12.92 : Math.pow((i + .055) / 1.055, 2.4), .2126 * t + .7152 * s + .0722 * i
                            }(getComputedStyle(e).backgroundColor);
                            e.style.color = t > .5 ? "black" : "white"
                        }
                    }), []), (0, m.jsx)(m.Fragment, {
                        children: (0, m.jsxs)("div", {
                            id: "ele-281",
                            className: "image-container divyansh inline-block rounded-md py-2 px-4 max-w-80 bg-primaryBgColor overflow-x-hidden max-w-image",
                            children: [(0, m.jsx)("div", {
                                className: "absolute left-0 top-0 w-full h-[57px] rounded-md rounded-b-none fade-in-bottom p-4 text-center",
                                style: {
                                    background: h.themeColor || "#226CF4"
                                },
                                id: "dynamicText",
                                children: (0, m.jsxs)("div", {
                                    id: "ele-282",
                                    className: "relative font-mSemiBold",
                                    children: [r, (0, m.jsxs)("div", {
                                        id: "ele-283",
                                        className: "absolute right-2 top-0 flex justify-end",
                                        children: ["launcher-icon" === p.viewType ? "collapsed" === g ? (0, m.jsx)(de.A, {
                                            className: "align-middle !text-xl m-auto text-white cursor-pointer",
                                            onClick: v
                                        }) : (0, m.jsx)(ce.A, {
                                            className: "align-middle !text-xl m-auto text-white cursor-pointer",
                                            onClick: v
                                        }) : null, (0, m.jsx)(re.A, {
                                            className: "!align-middle !text-2xl text-white cursor-pointer ml-4",
                                            onClick: () => {
                                                d ? t((0, l.h8)({
                                                    iframeActive: {}
                                                })) : (0, a.sZ)()
                                            }
                                        })]
                                    })]
                                })
                            }), (0, m.jsxs)("div", {
                                id: "ele-284",
                                className: "absolute left-0 bottom-0 w-full h-[calc(100%-56px)] bg-white z-10 fade-in-bottom",
                                children: [!c && (0, m.jsx)(oe.A, {
                                    sx: {
                                        backgroundColor: "#f0f0f0",
                                        "& .MuiLinearProgress-bar": {
                                            backgroundColor: "#a9a9a9"
                                        }
                                    }
                                }), (0, m.jsx)("iframe", {
                                    id: "ele-285",
                                    title: s,
                                    className: "h-full w-full",
                                    src: "https://" + o,
                                    onLoad: () => {
                                        u(!0)
                                    }
                                })]
                            })]
                        })
                    })
                },
                me = e => {
                    const t = (0, n.wA)(),
                        s = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.attributes)),
                        {
                            label: i,
                            topMargin: a,
                            iframeCTA: o,
                            iframeTitle: r
                        } = e;
                    return (0, m.jsxs)("div", {
                        className: "max-w-80 ele-iframe",
                        children: [(0, m.jsx)("div", {
                            className: `ele-iframe-title rounded-tl-xl rounded-tr-xl w-fit py-2 px-4 bg-primaryBgColor ${a}`,
                            children: (0, m.jsx)("p", {
                                children: (() => {
                                    try {
                                        let e = (0, N.yn)((0, S.ws)(i), [...s]);
                                        return e = e.replace("{{name}}", sessionStorage.getItem("name") || "User"), e || i
                                    } catch (e) {
                                        return i
                                    }
                                })()
                            })
                        }), (0, m.jsx)("div", {
                            className: "ele-iframe-open-btn-container options-container max-w-70 border-solid border-2 border-t-0 border-primaryBgColor rounded-bl-xl rounded-br-xl",
                            children: (0, m.jsxs)("div", {
                                className: "ele-iframe-open-btn link cursor-pointer  flex justify-center p-2 items-center border-solid border-t-2 border-primaryBgColor hover:bg-secondaryBgColor",
                                onClick: () => {
                                    t((0, l.h8)({
                                        iframeActive: {
                                            label: i,
                                            source: e.source,
                                            iframeCTA: o,
                                            iframeTitle: r,
                                            justHide: !0
                                        }
                                    }))
                                },
                                children: [(0, m.jsx)(J.A, {
                                    className: " text-primaryColor !text-lg mr-1 ele-iframe-launch-icon"
                                }), (0, m.jsx)("p", {
                                    className: "ele-iframe-cta text-primaryColor ",
                                    children: o
                                })]
                            })
                        })]
                    })
                };

            function he() {
                const [e, t] = (0, i.useState)(!1), s = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)), l = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)), a = null === s || void 0 === s ? void 0 : s.activeQuestion;
                (0, i.useEffect)((() => {
                    t(!1)
                }), [a.suggestions]);
                return (0, m.jsx)(m.Fragment, {
                    children: !e && (0, m.jsx)("div", {
                        id: "ele-286",
                        className: "space-y-2 px-4 mt-2 max-h-72 overflow-hidden flex justify-end items-end flex-wrap",
                        children: ((null === a || void 0 === a ? void 0 : a.suggestions) || []).map(((e, s) => (0, m.jsx)("button", {
                            className: "ele-ai-suggestions-button flex ml-2 justify-end max-w-[80%] text-left text-sm",
                            onClick: () => {
                                return s = e, (0, S.OK)(), t(!0), void(0, o.Jx)(s);
                                var s
                            },
                            children: (0, m.jsx)("div", {
                                className: "ele-ai-suggestions-btn-text-container flex items-center py-1 px-3 border border-solid max-w-full text-sm border-primaryColor text-primaryColor cursor-pointer rounded-xl",
                                children: (0, m.jsx)("p", {
                                    className: "ele-ai-suggestions-btn-text overflow-hidden w-full break-words",
                                    style: {
                                        color: l.themeColor || "#226CF4"
                                    },
                                    children: e
                                })
                            })
                        }, ((e, t) => `${e}_${(new Date).getTime()}_${t}`)(e, s))))
                    })
                })
            }
            var pe = s(95570),
                ge = s(67956),
                xe = s(47582),
                ve = s(72796);
            const fe = () => {
                const e = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    t = (null === e || void 0 === e ? void 0 : e.name) || "",
                    s = (null === e || void 0 === e ? void 0 : e.welcomeMessage) || "",
                    i = (null === e || void 0 === e ? void 0 : e.icebreakers) || [],
                    l = (null === e || void 0 === e ? void 0 : e.themeColor) || "#226CF4",
                    a = async e => {
                        const t = (0, ge.A)();
                        r.e.dispatch((0, f.iW)({
                            label: e,
                            position: "right",
                            type: "STATEMENT",
                            mid: t,
                            createdAt: String(new Date),
                            delay: 0
                        })), (0, xe.Ic)("message", {
                            text: e,
                            messageBy: "user",
                            mid: t
                        }), (0, ve.hb)({
                            type: "message",
                            text: e,
                            messagedBy: "user",
                            questionType: "statement",
                            mid: t,
                            isErrorMessage: !1
                        }).catch(console.log), (0, S.W2)(), (0, se.z)(0)
                    };
                return (0, m.jsxs)("div", {
                    className: "main-container flex flex-col items-center justify-center h-full w-full pt-16",
                    children: [(0, m.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [(0, m.jsx)("div", {
                            className: "p-1 rounded-full w-16 h-16",
                            style: {
                                background: l
                            },
                            children: (0, m.jsx)("img", {
                                className: "h-14 w-14 rounded-full bg-white",
                                src: null === e || void 0 === e ? void 0 : e.avatar,
                                alt: "avatar"
                            })
                        }), (0, m.jsx)("div", {
                            className: "text-xl text-center mt-2 mb-1",
                            style: {
                                fontWeight: 600
                            },
                            children: t
                        })]
                    }), !!s && (0, m.jsx)("div", {
                        className: "text-center text-gray-500 mb-6",
                        children: s
                    }), !s && (0, m.jsx)("div", {
                        className: "mb-6"
                    }), i.length ? 1 === i.length ? (0, m.jsx)("div", {
                        className: "flex justify-center gap-3",
                        children: (0, m.jsxs)("button", {
                            onClick: () => a(i[0]),
                            className: "flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-500 text-sm cursor-pointer",
                            children: [(0, m.jsx)("span", {
                                children: "\u2197"
                            }), " ", i[0]]
                        })
                    }) : 2 === i.length ? (0, m.jsx)("div", {
                        className: "flex justify-center gap-3",
                        children: (0, m.jsxs)("div", {
                            className: "flex flex-col md:flex-row gap-3",
                            children: [(0, m.jsxs)("button", {
                                onClick: () => a(i[0]),
                                className: "flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-500 text-sm cursor-pointer",
                                children: [(0, m.jsx)("span", {
                                    children: "\u2197"
                                }), " ", i[0]]
                            }), (0, m.jsxs)("button", {
                                onClick: () => a(i[1]),
                                className: "flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-500 text-sm cursor-pointer",
                                children: [(0, m.jsx)("span", {
                                    children: "\u2197"
                                }), " ", i[1]]
                            })]
                        })
                    }) : (0, m.jsx)("div", {
                        className: "flex justify-center gap-3",
                        children: (0, m.jsxs)("div", {
                            className: "flex flex-col gap-3",
                            children: [(0, m.jsxs)("div", {
                                className: "flex flex-col md:flex-row gap-3",
                                children: [(0, m.jsxs)("button", {
                                    onClick: () => a(i[0]),
                                    className: "flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-500 text-sm cursor-pointer",
                                    children: [(0, m.jsx)("span", {
                                        children: "\u2197"
                                    }), " ", i[0]]
                                }), (0, m.jsxs)("button", {
                                    onClick: () => a(i[1]),
                                    className: "flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-500 text-sm cursor-pointer",
                                    children: [(0, m.jsx)("span", {
                                        children: "\u2197"
                                    }), " ", i[1]]
                                })]
                            }), (0, m.jsx)("div", {
                                className: "flex justify-center",
                                children: (0, m.jsxs)("button", {
                                    onClick: () => a(i[2]),
                                    className: "flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-500 text-sm cursor-pointer",
                                    children: [(0, m.jsx)("span", {
                                        children: "\u2197"
                                    }), " ", i[2]]
                                })
                            })]
                        })
                    }) : null]
                })
            };
            let be = (0, d.A)({
                html: !1,
                linkify: !0,
                typographer: !0,
                breaks: !0
            });
            be.use(u(), {
                attrs: {
                    target: "_blank",
                    rel: "noopener"
                }
            });
            const je = e => {
                (0, N.Ad)(e).catch((e => console.log(e)))
            };

            function ye(e) {
                var t, s, a, o, r, d, c, u, h;
                const {
                    message: p,
                    topMargin: g
                } = e, x = (0, n.d4)((e => e.environment)), v = (0, n.wA)(), f = null === x || void 0 === x ? void 0 : x.activeMID, [b, j] = (0, i.useState)(e.hasClickedThumbsUp || !1), [y, w] = (0, i.useState)(e.hasClickedThumbsUp || !1), [T, E] = (0, i.useState)(""), [A, M] = (0, i.useState)(0), [B, I] = (0, i.useState)(""), [_, R] = (0, i.useState)(""), F = null === x || void 0 === x || null === (t = x.chatMenu) || void 0 === t || null === (s = t.voiceSupport) || void 0 === s ? void 0 : s.isEnabled;
                (0, i.useEffect)((() => {
                    var e, t;
                    const s = x.isResponseStreamingEnabled,
                        i = f === p.mid,
                        n = null !== (e = null === x || void 0 === x || null === (t = x.ai) || void 0 === t ? void 0 : t.streaming) && void 0 !== e && e;
                    if (s)
                        if (i) {
                            if (i && n) {
                                const e = setInterval((() => {
                                    if (A < (null === p || void 0 === p ? void 0 : p.label.length)) {
                                        const e = (null === p || void 0 === p ? void 0 : p.label.indexOf(" ", A + 1)) + 1 || (null === p || void 0 === p ? void 0 : p.label.length),
                                            t = null === p || void 0 === p ? void 0 : p.label.slice(A, e);
                                        E((e => e + `${t}`)), M(e), F && x.isVoiceOutputEnabled && I((e => {
                                            const s = e + t;
                                            return /[.!?,:;]/.test(t) ? (R(_ + s), "") : s
                                        }))
                                    } else clearInterval(e), v((0, l.rk)({
                                        streaming: !1
                                    })), F && B && x.isVoiceOutputEnabled && (R((e => e + B)), I("")), v((0, l.h8)({
                                        isVoiceOutputEnabled: !1
                                    }))
                                }), 200);
                                return () => clearInterval(e)
                            }
                        } else E(null === p || void 0 === p ? void 0 : p.label);
                    else E(null === p || void 0 === p ? void 0 : p.label)
                }), [p.label, A, B, f, v, _, I, x.isResponseStreamingEnabled, null === x || void 0 === x || null === (a = x.ai) || void 0 === a ? void 0 : a.streaming, null === x || void 0 === x || null === (o = x.chatMenu) || void 0 === o || null === (r = o.voiceSupport) || void 0 === r ? void 0 : r.isEnabled, x.isVoiceOutputEnabled, p.mid, F]);
                const L = e => {
                    "thumbsUp" === e ? (j(!0), w(!1), je({
                        mid: p.mid,
                        hasClickedThumbsUp: !0,
                        hasClickedThumbsDown: !1
                    })) : (j(!1), w(!0), je({
                        mid: p.mid,
                        hasClickedThumbsUp: !1,
                        hasClickedThumbsDown: !0
                    }))
                };
                return (0, m.jsx)(m.Fragment, {
                    children: T ? (0, m.jsx)("div", {
                        className: "main-container fade-in ai mb-3 max-w-80",
                        children: (0, m.jsx)("div", {
                            className: "message flex items-end",
                            children: (0, m.jsxs)("div", {
                                className: `rounded-xl py-2 px-4 bg-primaryBgColor relative  ${g}`,
                                children: [(0, m.jsx)("div", {
                                    onClick: e => {
                                        "IMG" === e.target.tagName && v((0, l.h8)({
                                            imagePreview: {
                                                isActive: !0,
                                                src: e.target.currentSrc
                                            }
                                        }))
                                    },
                                    className: "ele-text-message-label prose " + (null !== p && void 0 !== p && p._parent ? "ml-4" : ""),
                                    dangerouslySetInnerHTML: {
                                        __html: be.render((0, N.$8)(T || ""))
                                    }
                                }), "right" !== p.position && p.shouldFeedbackVisible && (0, m.jsxs)("div", {
                                    className: "text-right mt-1 ele-text-message-feedback",
                                    children: [x.activeMID === p.mid && "ai_agent" === (null === x || void 0 === x || null === (d = x.activeQuestion) || void 0 === d || null === (c = d.type) || void 0 === c ? void 0 : c.toLowerCase()) && (null === x || void 0 === x || null === (u = x.chatMenu) || void 0 === u || null === (h = u.voiceSupport) || void 0 === h ? void 0 : h.isEnabled) && (null === x || void 0 === x ? void 0 : x.isVoiceOutputEnabled) && (0, m.jsx)("div", {
                                        className: "inline-block mr-1",
                                        onClick: () => {
                                            (0, S.OK)()
                                        },
                                        children: (0, m.jsx)(C, {})
                                    }), b ? (0, m.jsx)("img", {
                                        onClick: () => L("thumbsUp"),
                                        alt: "refresh",
                                        className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                        src: "https://cdn.express-chat.com/messenger/thumbs-up.svg"
                                    }) : (0, m.jsx)("img", {
                                        onClick: () => L("thumbsUp"),
                                        src: "https://cdn.express-chat.com/messenger/thumbs-up-blank.svg",
                                        alt: "refresh",
                                        className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                        onMouseEnter: e => {
                                            e.target.src = "https://cdn.express-chat.com/messenger/thumbs-up.svg"
                                        },
                                        onMouseLeave: e => {
                                            e.target.src = "https://cdn.express-chat.com/messenger/thumbs-up-blank.svg"
                                        }
                                    }), y ? (0, m.jsx)("img", {
                                        onClick: () => L("thumbsDown"),
                                        src: "https://cdn.express-chat.com/messenger/thumbs-down.svg",
                                        alt: "refresh",
                                        className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer"
                                    }) : (0, m.jsx)("img", {
                                        onClick: () => L("thumbsDown"),
                                        src: "https://cdn.express-chat.com/messenger/thumbs-down-blank.svg",
                                        alt: "refresh",
                                        className: "transition-transform duration-250 transform hover:scale-150 inline-block w-6 cursor-pointer",
                                        onMouseEnter: e => {
                                            e.target.src = "https://cdn.express-chat.com/messenger/thumbs-down.svg"
                                        },
                                        onMouseLeave: e => {
                                            e.target.src = "https://cdn.express-chat.com/messenger/thumbs-down-blank.svg"
                                        }
                                    })]
                                })]
                            })
                        })
                    }) : (0, m.jsx)(k, {})
                })
            }
            var we = s(34928);
            const Ne = ["statement", "question", "email", "phone", "file", "appointment", "location", "date", "number", "smart_question", "name", "live_chat"],
                ke = ["statement", "video", "image", "contact", "system"],
                Ce = ["live_chat_notification", "live_chat"],
                Se = ["image", "video", "audio", "document"],
                Te = ["ai", "ai_agent"];

            function Ee(e) {
                var t, s, a, o, d;
                const c = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)),
                    u = (0, i.useRef)(c),
                    h = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.flows)),
                    g = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.messages)),
                    x = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    [v, j] = (0, i.useState)(!0),
                    [y, k] = (0, i.useState)(""),
                    C = (0, i.useCallback)((() => {
                        const e = g[g.length - 1],
                            {
                                createdAt: t,
                                isErrorMessage: s,
                                position: i,
                                type: n
                            } = e || {};
                        let a = parseInt(sessionStorage.getItem("myTabCount") || "0");
                        const o = "live_chat" === (null === c || void 0 === c ? void 0 : c.activeQuestionType) || "STATEMENT" === (null === c || void 0 === c ? void 0 : c.activeQuestionType);
                        if (!v || a) return e && e.label ? (0, S.W2)((null === e || void 0 === e ? void 0 : e.id) + " " + (e.label || "").slice(-10)) : (0, S.W2)(), !1;
                        if (localStorage.getItem("agentId") && localStorage.getItem("agentData")) {
                            var d;
                            let e;
                            if (e = (0, ve.GO)(localStorage.getItem("agentData") || "", "server-bp-678#1"), r.e.dispatch((0, l.h8)({
                                    typing: !1,
                                    refresh: !0,
                                    liveChat: !0,
                                    iframeActive: {},
                                    activeQuestion: { ...null === (d = u.current) || void 0 === d ? void 0 : d.activeQuestion,
                                        aiConfig: {},
                                        suggestions: []
                                    },
                                    batchedMessages: "",
                                    currentTimerRef: null,
                                    ...e && {
                                        chatRequestRejected: !1,
                                        disableStartButton: !1,
                                        chatRequestAccepted: !0,
                                        agentId: e.agentId,
                                        agentAvatar: e.picture,
                                        agentName: e.name
                                    }
                                })), r.e.dispatch((0, f.VU)({
                                    status: !1
                                })), r.e.dispatch((0, we.t)("AGENT")), (0, S.W2)(), !g.length) {
                                const t = (0, ge.A)();
                                (0, xe.Ic)("message", {
                                    agentName: e.name,
                                    type: "system",
                                    method: "chat-request-accepted",
                                    mid: t
                                }), r.e.dispatch((0, f.iW)({
                                    agentName: e.name,
                                    type: "system",
                                    method: "chat-request-accepted",
                                    mid: t
                                }))
                            }
                            return !1
                        }
                        return s || !g.length || !o && "right" === e.position || t && ne()(t).isBefore(ne()().subtract(1, "hour")) || ke.includes(n) && "left" === i ? (j(!1), !0) : (r.e.dispatch((0, l.h8)({
                            activeQuestion: e,
                            activeQuestionType: e.type
                        })), j(!1), !1)
                    }), [g, v, null === c || void 0 === c ? void 0 : c.activeQuestionType]);
                (0, i.useEffect)((() => {
                    if ("launcher-icon" === (null === c || void 0 === c ? void 0 : c.viewType) ? h.length && (null === e || void 0 === e ? void 0 : e.shouldFetchData) : h.length) {
                        if (C()) {
                            var t;
                            !g.length && (null === x || void 0 === x || null === (t = x.icebreakers) || void 0 === t ? void 0 : t.length) > 0 || (0, se.z)()
                        }
                    }
                }), [h, C, null === e || void 0 === e ? void 0 : e.shouldFetchData, null === c || void 0 === c ? void 0 : c.viewType, null === x || void 0 === x ? void 0 : x.icebreakers, g]);
                const T = (e, t) => {
                        if ("right" === t.position || "system" === t.type) return !1;
                        const s = g[e - 1];
                        return "top" === x.avatarPlacement ? !s || "right" === s.position || "system" === s.type || !ke.includes(null === s || void 0 === s ? void 0 : s.type.toLowerCase()) && !ke.includes(t.type.toLowerCase()) : "right" !== t.position && "system" !== t.type && (!ke.includes(t.type.toLowerCase()) || e === g.length - 1 && "user" !== t.messagedBy || t.isErrorMessage)
                    },
                    E = (e, t) => -1 === t ? "mt-3" : g[t].position === e ? "mt-2" : "mt-3",
                    M = e => {
                        const t = Se.includes(e.type) && "right" === e.position ? "flex-col-reverse" : "";
                        return "top" === x.avatarPlacement ? `${t}` : `flex ${t}`
                    },
                    I = e => "top" === x.avatarPlacement ? `flex items-end ${Se.includes(e.type)&&"right"===e.position&&"flex-col-reverse"}` : "";
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        id: "chatArea",
                        children: [g.length ? g.map(((e, t) => {
                            var s, i, l, n;
                            const a = g.length;
                            return (0, m.jsxs)("div", {
                                className: "ele-chatblock",
                                children: [(0, m.jsxs)("div", {
                                    className: "main-container",
                                    children: [(0, m.jsx)(pe.Hg, {
                                        name: (null === e || void 0 === e ? void 0 : e.id) + " " + (e.label || "").slice(-10),
                                        children: (0, m.jsxs)("div", {
                                            className: `message bp-fade-in items-end ${M(e)}`,
                                            children: [T(t, e) ? (0, m.jsx)(X, {
                                                type: "agent" === e.messageBy ? "agent" : "bot"
                                            }) : (0, m.jsx)("div", {
                                                style: {
                                                    width: "system" === e.type ? "0" : "50px"
                                                }
                                            }), Ne.includes(e.type.toLowerCase()) && "right" !== e.position && (0, m.jsx)(B, {
                                                message: e,
                                                topMargin: E(e.position, t - 1)
                                            }), "button" === e.type && (0, m.jsx)(p, {
                                                message: e,
                                                currentIndex: t,
                                                count: a,
                                                topMargin: E(e.position, t - 1)
                                            }), "multi_select" === e.type && (0, m.jsx)(_, {
                                                message: e,
                                                currentIndex: t,
                                                count: a,
                                                topMargin: E(e.position, t - 1)
                                            }), "rating" === e.type && (0, m.jsx)(F, {
                                                message: e,
                                                currentIndex: t,
                                                count: a,
                                                topMargin: E(e.position, t - 1)
                                            }), "range" === e.type && (0, m.jsx)($, {
                                                message: e,
                                                currentIndex: t,
                                                count: a,
                                                topMargin: E(e.position, t - 1)
                                            }), "image" === e.type && (0, m.jsx)(U, {
                                                message: e,
                                                topMargin: E(e.position, t - 1)
                                            }), "video" === e.type && (0, m.jsx)(Q, {
                                                message: e,
                                                topMargin: E(e.position, t - 1)
                                            }), "contact" === e.type && (0, m.jsx)(Z, {
                                                message: e,
                                                topMargin: E(e.position, t - 1)
                                            }), "iframe" === e.type && (0, m.jsx)(m.Fragment, {
                                                children: "top" === x.avatarPlacement ? (0, m.jsxs)("div", {
                                                    className: "flex",
                                                    children: [(0, m.jsx)(me, { ...e,
                                                        topMargin: E(e.position, t - 1)
                                                    }), " "]
                                                }) : (0, m.jsx)(me, { ...e,
                                                    topMargin: E(e.position, t - 1)
                                                })
                                            }), "system" === e.type && (0, m.jsx)(ie, { ...e,
                                                topMargin: E(e.position, t - 1)
                                            }), "document" === e.type && (0, m.jsx)(m.Fragment, {
                                                children: "top" === x.avatarPlacement ? (0, m.jsxs)("div", {
                                                    className: I(e),
                                                    children: [(0, m.jsx)(G, {
                                                        message: e,
                                                        topMargin: E(e.position, t - 1)
                                                    }), " "]
                                                }) : (0, m.jsx)(G, {
                                                    message: e,
                                                    topMargin: E(e.position, t - 1)
                                                })
                                            }), "audio" === e.type && (0, m.jsx)(K, {
                                                message: e,
                                                topMargin: E(e.position, t - 1)
                                            }), "ai" === e.type.toLowerCase() && (0, m.jsx)(A, {
                                                message: e,
                                                topMargin: E(e.position, t - 1)
                                            }), "ai_agent" === e.type.toLowerCase() && (0, m.jsx)(ye, {
                                                message: e,
                                                topMargin: E(e.position, t - 1)
                                            })]
                                        })
                                    }), Ce.includes(e.type.toLowerCase()) && (0, m.jsx)(te, {
                                        message: e
                                    }), ("user" === e.messagedBy || "right" === e.position) && !Se.includes(e.type) && (0, m.jsx)("div", {
                                        className: "flex-col",
                                        children: (0, m.jsx)("div", {
                                            className: "ele-chat-message-container flex flex-row-reverse pr-0",
                                            children: (0, m.jsxs)("div", {
                                                className: `ele-chat-message-content max-w-80 rounded-xl break-normal py-2 px-4 bg-primaryColor text-white break-words relative ${E(e.position,t-1)}`,
                                                style: {
                                                    backgroundColor: x.themeColor
                                                },
                                                onMouseEnter: () => {
                                                    k(String(t))
                                                },
                                                onMouseLeave: () => {
                                                    k("")
                                                },
                                                children: [null !== e && void 0 !== e && e._parent ? (0, m.jsx)(w, {
                                                    backgroundColor: (0, S.sG)(x.themeColor, 10),
                                                    parentMessage: null === e || void 0 === e ? void 0 : e._parent,
                                                    messagePosition: e.position
                                                }) : null, (0, m.jsx)("p", {
                                                    className: null !== e && void 0 !== e && e._parent ? "ml-4 ele-chat-message-label" : "ele-chat-message-label",
                                                    children: e.label
                                                }), (0, m.jsx)(b, {
                                                    message: e,
                                                    show: y === String(t)
                                                })]
                                            })
                                        })
                                    })]
                                }), t === g.length - 1 && !c.typing && ("agent" === e.messageBy || !Ce.includes(null === (s = g[g.length - 1]) || void 0 === s || null === (i = s.type) || void 0 === i ? void 0 : i.toLowerCase())) && (0, m.jsx)(ae, {
                                    message: e
                                }), (e.skip || e.back) && t === g.length - 1 && !ke.includes(null === (l = g[g.length - 1]) || void 0 === l || null === (n = l.type) || void 0 === n ? void 0 : n.toLowerCase()) && (0, m.jsxs)("div", {
                                    className: "flex flex-row items-end justify-end cursor-pointer",
                                    children: [e.back && (0, m.jsx)("div", {
                                        className: "ele-back-btn rounded-xl py-2 px-5 border-x border-y border-customBorder2",
                                        onClick: N.aX,
                                        children: "Back"
                                    }), e.skip && (0, m.jsx)("div", {
                                        className: "ele-skip-btn rounded-xl py-2 px-5 bg-primaryBgColor ml-2",
                                        onClick: N.iv,
                                        children: "Skip"
                                    })]
                                })]
                            }, `${e.mid} ${String(e.createdAt)}`)
                        })) : (null === x || void 0 === x || null === (t = x.icebreakers) || void 0 === t ? void 0 : t.length) > 0 ? (0, m.jsx)(fe, {}) : "", c.iframeActive && c.iframeActive.source && (0, m.jsx)(ue, { ...c.iframeActive
                        }), (c.typing || Te.includes(null === c || void 0 === c || null === (s = c.activeQuestion) || void 0 === s || null === (a = s.type) || void 0 === a ? void 0 : a.toLowerCase()) && c.isAiResponding) && (0, m.jsx)(ee, {}), (0, m.jsx)("div", {
                            id: "ele-306",
                            children: Te.includes(null === c || void 0 === c || null === (o = c.activeQuestion) || void 0 === o || null === (d = o.type) || void 0 === d ? void 0 : d.toLowerCase()) && (() => {
                                var e, t;
                                return !(null === c || void 0 === c || null === (e = c.activeQuestion) || void 0 === e || null === (t = e.suggestions) || void 0 === t || !t.length)
                            })() && "voice" !== (null === c || void 0 === c ? void 0 : c.activeInput) && (0, m.jsx)(he, {})
                        })]
                    })
                })
            }
            var Ae = s(28429),
                Me = s(80150),
                Be = s(18581);

            function Ie() {
                var e, t, s;
                const i = (0, Ae.zy)(),
                    l = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)),
                    a = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    o = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.configuration));
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        id: "ele-header",
                        className: "p-4 bg-bpPrimary rounded-xl flex flex-row justify-between h-full text-white",
                        style: {
                            backgroundColor: a.themeColor || "#226CF4"
                        },
                        children: [(0, m.jsxs)("div", {
                            id: "ele-01",
                            className: "flex flex-row justify-start items-center",
                            children: [(0, m.jsx)("div", {
                                className: "flex relative",
                                id: "ele-02",
                                children: (0, m.jsx)("img", {
                                    id: "ele-03",
                                    className: "inline-block h-8 w-8 min-w-8 rounded-full bg-white",
                                    src: a.avatar,
                                    alt: ""
                                })
                            }), (0, m.jsxs)("div", {
                                id: "ele-185",
                                className: "grid grid-cols-1 " + ("ltr" === (null === l || void 0 === l ? void 0 : l.direction) ? "ml-4" : "mr-4"),
                                children: [(0, m.jsx)("div", {
                                    id: "ele-186",
                                    className: "font-mSemiBold text-base",
                                    children: null === a || void 0 === a ? void 0 : a.name
                                }), o && o.generalSettings && o.generalSettings.waitingMessage && (0, m.jsxs)("div", {
                                    id: "ele-187",
                                    className: "text-xs flex flex-row justify-start items-center",
                                    children: [(0, m.jsx)("img", {
                                        src: "https://cdn.express-chat.com/messenger/clock.svg",
                                        alt: "clock",
                                        className: "inline-block " + ("ltr" === (null === l || void 0 === l ? void 0 : l.direction) ? "mr-1" : "ml-1")
                                    }), " ", (0, m.jsx)("span", {
                                        className: "opacity-75 text-xs truncate text-nowrap",
                                        children: o.generalSettings.waitingMessage
                                    })]
                                })]
                            })]
                        }), (0, m.jsxs)("div", {
                            id: "ele-188",
                            className: "flex flex-row justify-end h-full items-center",
                            children: [(!(null !== o && void 0 !== o && null !== (e = o.chatMenu) && void 0 !== e && e.hideTransferToWhatsApp) || (null === o || void 0 === o || null === (t = o.chatMenu) || void 0 === t ? void 0 : t.toLiveChat) || (null === o || void 0 === o || null === (s = o.chatMenu) || void 0 === s ? void 0 : s.refreshChat)) && (0, m.jsx)(Be.A, {
                                color: "#fff"
                            }), l && "launcher-icon" === l.viewType && (0, m.jsx)("div", {
                                id: "ele-189",
                                className: "cursor-pointer hover:opacity-70",
                                onClick: () => {
                                    const e = i.pathname.split("/");
                                    e[e.length - 1], e[e.length - 2];
                                    if (sessionStorage.getItem("BotPenguin_rating") || !o.chatMenu.isRatingEnabled) {
                                        (new window.parent.BotPenguin).closeWindow(), localStorage.setItem("bp-user-close", "true"), r.e.dispatch((0, Me.A)(!1))
                                    } else r.e.dispatch((0, Me.A)(!0))
                                },
                                children: (0, m.jsx)(re.A, {
                                    className: "align-middle !text-3xl"
                                })
                            })]
                        })]
                    })
                })
            }
            var _e = s(64942),
                Re = s(29942);

            function Fe() {
                return (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsx)("div", {
                        id: "ele-381",
                        role: "status",
                        className: "animate-pulse h-14 p-4",
                        children: (0, m.jsxs)("div", {
                            id: "ele-382",
                            className: "animate-pulse h-14 items-center align-middle",
                            children: [(0, m.jsx)("div", {
                                id: "ele-383",
                                className: "h-2.5 bg-gray-300 rounded-full dark:bg-gray-700 max-w-[640px] mb-2.5 mx-auto"
                            }), (0, m.jsx)("div", {
                                id: "ele-384",
                                className: "h-2.5 mx-auto bg-gray-300 rounded-full dark:bg-gray-700 max-w-[540px]"
                            }), (0, m.jsx)("span", {
                                id: "ele-385",
                                className: "sr-only",
                                children: "Loading..."
                            })]
                        })
                    })
                })
            }
            const Le = {
                    sun: 0,
                    mon: 1,
                    tue: 2,
                    wed: 3,
                    thu: 4,
                    fri: 5,
                    sat: 6
                },
                De = {
                    15: "quarter",
                    10: "tenth",
                    30: "half",
                    60: "one",
                    90: "one-half",
                    120: "two"
                };
            var Pe = s(16676);

            function Oe() {
                const [e, t] = (0, i.useState)(""), [s, a] = (0, i.useState)((0, ge.A)()), d = (0, i.useRef)(s), [c, u] = (0, i.useState)(!1), [h, p] = (0, i.useState)(""), g = (0, i.useRef)(null), x = (0, i.useRef)(null), v = (0, i.useRef)(null), b = (0, i.useRef)(null), j = (0, i.useRef)([]), y = (0, i.useRef)(null), w = (0, i.useRef)(-1), N = (0, i.useRef)(!1), k = (0, i.useRef)(null), C = (0, i.useRef)(null), T = (0, i.useRef)(""), E = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)), A = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment.activeQuestion)), M = c, B = (0, n.d4)((e => {
                    var t;
                    return null === (t = e.ai) || void 0 === t ? void 0 : t.aiReplies
                })) || 0, I = (0, n.wA)();
                (0, i.useEffect)((() => {
                    b.current || (b.current = new(window.AudioContext || window.webkitAudioContext)({
                        latencyHint: "interactive",
                        sampleRate: 24e3
                    }), y.current = b.current.createAnalyser(), y.current.fftSize = 2048, y.current.smoothingTimeConstant = .96)
                }), []), (0, i.useEffect)((() => {
                    d.current = s
                }), [s]), (0, i.useEffect)((() => {
                    const e = e => {
                            const s = e.detail;
                            if (s.sessionId !== d.current) return;
                            const i = s.result;
                            if (i.channel && i.channel.alternatives && i.channel.alternatives[0]) {
                                const e = i.channel.alternatives[0].transcript;
                                e && e.trim() && (t((t => {
                                    const s = (t + " " + e).trim();
                                    return T.current = s, D(s, d.current), s
                                })), C.current && clearTimeout(C.current), C.current = setTimeout((() => {
                                    R(), D(T.current, d.current), (0, o.Jx)(T.current, "", null, !1, "", d.current), t(""), T.current = "", a((0, ge.A)())
                                }), 5e3))
                            }
                        },
                        s = e => {
                            const t = e.detail;
                            t.sessionId === d.current && (console.error("Backend transcription error:", t.error), p(t.error), u(!1), I((0, l.En)({
                                isMicOn: !1,
                                isListening: !1
                            })))
                        },
                        i = e => {
                            const t = e.detail;
                            N.current = !0, b.current.decodeAudioData(t).then((e => {
                                if (!e) return;
                                const t = (0, ve.Rg)(b.current, e, w, y.current);
                                t.onended = () => {
                                    const e = j.current.indexOf(t);
                                    e > -1 && j.current.splice(e, 1), 0 === j.current.length && (N.current = !1, k.current && k.current(), I((0, l.h8)({
                                        isVoiceOutputEnabled: !1
                                    })))
                                }, j.current.push(t)
                            })).catch((e => {
                                console.log("Error while decoding audio:", e), N.current = !1
                            }))
                        },
                        n = () => {
                            j.current.forEach((e => e.stop())), j.current = [], w.current = -1, N.current = !1
                        },
                        r = () => {
                            console.log("Voice output ended - you can add custom logic here")
                        };
                    return window.addEventListener("transcription-result", e), window.addEventListener("transcription-error", s), window.addEventListener("audio-generated", i), window.addEventListener("clear-audio", n), window.addEventListener("voice-output-ended", r), () => {
                        window.removeEventListener("transcription-result", e), window.removeEventListener("transcription-error", s), window.removeEventListener("audio-generated", i), window.removeEventListener("clear-audio", n), window.removeEventListener("voice-output-ended", r)
                    }
                }), [I]);
                const _ = async () => {
                        try {
                            const e = (0, ge.A)();
                            a(e), t(""), p(""), (0, xe.Ic)("start-transcription", {
                                sessionId: e
                            }), await (async () => {
                                try {
                                    p("");
                                    const e = await navigator.mediaDevices.getUserMedia({
                                        audio: {
                                            echoCancellation: !0,
                                            noiseSuppression: !0,
                                            autoGainControl: !0,
                                            sampleRate: 16e3
                                        }
                                    });
                                    v.current = e;
                                    const t = new(window.AudioContext || window.webkitAudioContext)({
                                        sampleRate: 16e3
                                    });
                                    g.current = t;
                                    const s = t.createMediaStreamSource(e),
                                        i = t.createScriptProcessor(4096, 1, 1);
                                    x.current = i, i.onaudioprocess = e => {
                                        const t = e.inputBuffer.getChannelData(0),
                                            s = new Int16Array(t.length);
                                        for (let i = 0; i < t.length; i++) {
                                            const e = Math.max(-1, Math.min(1, t[i]));
                                            s[i] = 32767 * e
                                        }(0, xe.Ic)("audio-chunk", {
                                            sessionId: d.current,
                                            audioData: s.buffer
                                        })
                                    }, s.connect(i), i.connect(t.destination)
                                } catch (h) {
                                    console.error("Error capturing audio:", h), p("Microphone access denied. Please allow microphone access and refresh.")
                                }
                            })(), u(!0), I((0, l.En)({
                                isMicOn: !0,
                                isListening: !0
                            }))
                        } catch (e) {
                            console.error("Failed to start backend transcription:", e), p("Failed to start transcription. Check console for details.")
                        }
                    },
                    R = () => {
                        C.current && (clearTimeout(C.current), C.current = null), (0, xe.Ic)("stop-transcription", {
                            sessionId: d.current
                        }), F(), u(!1), I((0, l.En)({
                            isMicOn: !1,
                            isListening: !1
                        }))
                    },
                    F = () => {
                        v.current && (v.current.getTracks().forEach((e => e.stop())), v.current = null), g.current && (g.current.close(), g.current = null), x.current && (x.current.disconnect(), x.current = null)
                    },
                    L = (0, i.useCallback)((async () => {
                        await (async () => {
                            c ? R() : _()
                        })()
                    }), []),
                    D = (0, i.useCallback)(((e, t) => {
                        if (!e || !e.trim()) return;
                        const s = (r.e.getState().messages || []).find((e => e.mid === t));
                        (0, S.OK)(), I(s ? (0, f.pj)({
                            label: e.trim(),
                            position: "right",
                            type: "STATEMENT",
                            mid: t,
                            questionId: null === A || void 0 === A ? void 0 : A.id,
                            isTemp: !0
                        }) : (0, f.iW)({
                            label: e.trim(),
                            position: "right",
                            type: "STATEMENT",
                            mid: t,
                            questionId: null === A || void 0 === A ? void 0 : A.id,
                            isTemp: !0
                        }))
                    }), [I, null === A || void 0 === A ? void 0 : A.id]);
                return (0, i.useEffect)((() => {
                    null !== E && void 0 !== E && E.isVoiceOutputEnabled && !c && B > 0 && L()
                }), [null === E || void 0 === E ? void 0 : E.isVoiceOutputEnabled, c, L, B]), (0, i.useEffect)((() => () => {
                    F(), c && ((0, xe.Ic)("stop-transcription", {
                        sessionId: d.current
                    }), u(!1)), C.current && clearTimeout(C.current)
                }), []), (0, m.jsxs)("div", {
                    className: "voice-input-container flex flex-col justify-center items-center h-voice",
                    children: [(0, m.jsxs)("div", {
                        className: "relative",
                        children: [(0, m.jsxs)("button", {
                            id: "speech",
                            className: `btn relative rounded-full p-4 shadow-lg transition-all duration-300 transform ${null!==E&&void 0!==E&&E.typing?"bg-secondaryBgColor cursor-not-allowed opacity-50":M?"bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 animate-pulse":"bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 hover:scale-110"} group`,
                            onClick: () => {
                                null !== E && void 0 !== E && E.typing || (M ? R() : (L(), (0, S.OK)()))
                            },
                            disabled: null === E || void 0 === E ? void 0 : E.typing,
                            title: null !== E && void 0 !== E && E.typing ? "Please wait, AI is responding..." : M ? "Stop voice recording" : "Start voice recording",
                            children: [(0, m.jsx)(Pe.A, {
                                fontSize: "large",
                                sx: {
                                    color: "white",
                                    filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.1))"
                                }
                            }), (0, m.jsx)("div", {
                                className: "absolute inset-0 rounded-full bg-white opacity-0 group-hover:opacity-20 transition-opacity duration-300"
                            })]
                        }), M && !(null !== E && void 0 !== E && E.typing) && (0, m.jsxs)(m.Fragment, {
                            children: [(0, m.jsx)("div", {
                                className: "absolute inset-0 rounded-full border-2 border-blue-300 animate-ping"
                            }), (0, m.jsx)("div", {
                                className: "absolute inset-0 rounded-full border-2 border-indigo-300 animate-pulse",
                                style: {
                                    animationDelay: "0.5s"
                                }
                            }), (0, m.jsx)("div", {
                                className: "absolute -inset-2 rounded-full border-2 border-blue-200 animate-ping",
                                style: {
                                    animationDelay: "1s"
                                }
                            })]
                        })]
                    }), (0, m.jsx)("p", {
                        className: "text-secondaryText my-2 mb-0",
                        children: null !== E && void 0 !== E && E.typing ? "AI is responding..." : M ? "Listening..." : "Tap to Speak"
                    }), h && (0, m.jsx)("p", {
                        className: "text-red-500 text-xs mt-1 text-center",
                        children: h
                    }), e && (0, m.jsx)("div", {
                        className: "mt-2 text-center",
                        children: (0, m.jsxs)("p", {
                            className: "text-sm text-gray-600 italic",
                            children: ['"', e, '"']
                        })
                    })]
                })
            }
            var $e = s(49672);
            const ze = (0, i.lazy)((() => Promise.all([s.e(8461), s.e(3406)]).then(s.bind(s, 73406)))),
                Ue = (0, i.lazy)((() => Promise.all([s.e(7592), s.e(8727)]).then(s.bind(s, 98727)))),
                We = (0, i.lazy)((() => s.e(404).then(s.bind(s, 58023)))),
                qe = (0, i.lazy)((() => Promise.all([s.e(2059), s.e(7609)]).then(s.bind(s, 47609)))),
                Ve = (0, i.lazy)((() => s.e(4879).then(s.bind(s, 4879)))),
                Qe = ["name", "statement", "question", "location", "button", "multi_select", "email", "smart_question", "live_chat", "image", "video", "contact", "rating", "range", "AI", "AI_AGENT", "live_chat", "ai", "ai_agent"],
                He = ["ai", "ai_agent"],
                Ge = ["phone"],
                Ke = ["number"],
                Je = ["upload", "file"],
                Ye = ["appointment"],
                Ze = ["date"];

            function Xe(e) {
                var t, s, l, a, o, r, d, c, u;
                const [h, p] = (0, i.useState)("text"), [g, x] = (0, i.useState)(), [v, f] = (0, i.useState)("initial"), b = (0, i.useRef)(v), [j, y] = (0, i.useState)(null), [w, N] = (0, i.useState)("document"), [k, C] = (0, i.useState)(!1), S = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.messages)), T = (0, i.useRef)(S), E = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)), A = (0, i.useRef)(E), M = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.botHandler));
                (0, i.useEffect)((() => {
                    if (null !== S && void 0 !== S && S.length) {
                        const e = null === E || void 0 === E ? void 0 : E.activeQuestion;
                        x(e), p(null === e || void 0 === e ? void 0 : e.type)
                    }
                    Je.includes(h) && C(!0)
                }), [S, E, h]), (0, i.useEffect)((() => {
                    let e;
                    A.current && (0, $e.UF)(A.current, T.current);
                    const t = () => f("initial");
                    if (E.socketDisconnected) f("offline"), b.current = "offline";
                    else if (!1 === E.socketDisconnected) {
                        "offline" === b.current ? (f("online"), b.current = "online", e = setTimeout(t, 3e3)) : (f("initial"), b.current = "initial")
                    }
                    return () => {
                        e && clearTimeout(e)
                    }
                }), [E.socketDisconnected]);
                const B = e => {
                        const {
                            type: t
                        } = e || {
                            type: ""
                        };
                        return t.includes("image") ? "image" : t.includes("video") ? "video" : t.includes("application") || t.includes("text") ? "document" : t.includes("audio") ? "audio" : ""
                    },
                    I = e => {
                        switch (e) {
                            case "image":
                                return ".jpg, .jpeg, .png, .gif, .bmp, .svg, .webp";
                            case "video":
                                return ".mp4, .avi, .mov, .wmv, .flv, .webm";
                            case "audio":
                                return ".mp3, .wav, .aac, .flac, .ogg, .m4a, .wma, .aiff";
                            case "document":
                                return ".pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx, .txt, .rtf, .odt, .csv, .html, .htm";
                            default:
                                return ""
                        }
                    };
                return (0, i.useEffect)((() => {
                    const e = e => {
                            e.preventDefault(), e.stopPropagation()
                        },
                        t = e => {
                            e.preventDefault(), e.stopPropagation()
                        },
                        s = e => {
                            if (e.preventDefault(), e.stopPropagation(), !E.liveChat) return !1;
                            let t = {
                                blob: null,
                                mediaType: "",
                                mediaName: "",
                                mimetype: ""
                            };
                            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                                const s = e.dataTransfer.files[0],
                                    i = B(s);
                                if (!i) return !1;
                                t = {
                                    blob: s,
                                    mediaType: i,
                                    mediaName: s.name,
                                    mimetype: s.type
                                };
                                const l = I(t.mediaType),
                                    n = (t.mediaName || "").split(".").pop();
                                if (!l.includes(n)) return;
                                N(t.mediaType), y(e.dataTransfer.files[0])
                            }
                        },
                        i = e => {
                            var t, s;
                            const i = null === (t = e.clipboardData || (null === e || void 0 === e || null === (s = e.originalEvent) || void 0 === s ? void 0 : s.clipboardData)) || void 0 === t ? void 0 : t.items;
                            let l = {
                                blob: null,
                                mediaType: "",
                                mediaName: "",
                                mimetype: ""
                            };
                            for (const d of i) {
                                var n, a;
                                const e = B(d);
                                if (!e) return !1;
                                l = {
                                    blob: d.getAsFile(),
                                    mediaType: e,
                                    mediaName: null === (n = d.getAsFile()) || void 0 === n ? void 0 : n.name,
                                    mimetype: null === (a = d.getAsFile()) || void 0 === a ? void 0 : a.type
                                }
                            }
                            const o = I(l.mediaType),
                                r = (l.mediaName || "").split(".").pop();
                            o.includes(r) && (N(l.mediaType), y(l.blob))
                        };
                    return window.addEventListener("dragover", e), window.addEventListener("dragleave", t), window.addEventListener("drop", s), window.addEventListener("paste", i), () => {
                        window.removeEventListener("dragover", e), window.removeEventListener("dragleave", t), window.removeEventListener("drop", s), window.removeEventListener("paste", i)
                    }
                }), [E.liveChat]), (0, m.jsxs)("div", {
                    className: "relative bg-white rounded-xl",
                    children: ["AGENT" === M || E.liveChat ? (0, m.jsx)(i.Suspense, {
                        fallback: (0, m.jsx)(Fe, {}),
                        children: j || k ? (0, m.jsx)(We, {
                            showChatWindowOptions: e.showChatWindowOptions,
                            dragFile: j,
                            setDragFile: y,
                            mediaType: w,
                            setShouldShowUpload: C,
                            shouldShowUpload: k
                        }) : (0, m.jsx)(ze, {
                            message: h,
                            showChatWindowOptions: null === e || void 0 === e ? void 0 : e.showChatWindowOptions,
                            setShouldShowUpload: C
                        })
                    }) : (0, m.jsxs)(m.Fragment, {
                        children: [Ye.includes(h) && (0, m.jsx)(i.Suspense, {
                            fallback: (0, m.jsx)(Fe, {}),
                            children: (0, m.jsx)(qe, {
                                text: null === g || void 0 === g ? void 0 : g.label,
                                min: new Date,
                                max: new Date(null !== g && void 0 !== g && null !== (t = g.appointment) && void 0 !== t && t.futureDays ? (new Date).setDate((new Date).getDate() + g.appointment.futureDays) : (new Date).setDate((new Date).getDate() + 30)),
                                availableDays: null === g || void 0 === g || null === (s = g.appointment) || void 0 === s ? void 0 : s.availableDays.map((e => Le[e])),
                                startTime: null === g || void 0 === g || null === (l = g.appointment) || void 0 === l ? void 0 : l.startTime,
                                endTime: null === g || void 0 === g || null === (a = g.appointment) || void 0 === a ? void 0 : a.endTime,
                                slotInterval: De[(null === g || void 0 === g || null === (o = g.appointment) || void 0 === o ? void 0 : o.interval) || 30] || "half",
                                slots: !0,
                                type: "appointment",
                                showChatWindowOptions: e.showChatWindowOptions,
                                disablePast: !0
                            })
                        }), Ze.includes(h) && (0, m.jsx)(i.Suspense, {
                            fallback: (0, m.jsx)(Fe, {}),
                            children: (0, m.jsx)(qe, {
                                text: null === g || void 0 === g ? void 0 : g.label,
                                time: null === g || void 0 === g ? void 0 : g.showTime,
                                showTime: null === g || void 0 === g ? void 0 : g.showTime,
                                availableDays: [0, 1, 2, 3, 4, 5, 6],
                                type: "date",
                                showChatWindowOptions: e.showChatWindowOptions,
                                disablePast: !1,
                                min: "",
                                max: ""
                            })
                        }), Ge.includes(h) && (0, m.jsx)("div", {
                            id: "ele-374",
                            className: "relative",
                            children: (0, m.jsx)(i.Suspense, {
                                fallback: (0, m.jsx)(Fe, {}),
                                children: (0, m.jsx)(Ue, {
                                    phoneValidation: E.activeQuestion ? E.activeQuestion.phoneValidation : {},
                                    defaultDialCode: E.activeQuestion && E.activeQuestion.defaultDialCode ? E.activeQuestion.defaultDialCode.code || "IN" : "",
                                    showChatWindowOptions: e.showChatWindowOptions
                                })
                            })
                        }), Je.includes(h) && (0, m.jsx)(i.Suspense, {
                            fallback: (0, m.jsx)(Fe, {}),
                            children: (0, m.jsx)(We, {
                                showChatWindowOptions: e.showChatWindowOptions,
                                setShouldShowUpload: C,
                                shouldShowUpload: k
                            })
                        }), Ke.includes(h) && (0, m.jsx)(i.Suspense, {
                            fallback: (0, m.jsx)(Fe, {}),
                            children: (0, m.jsx)(Ve, {
                                showChatWindowOptions: e.showChatWindowOptions
                            })
                        }), Qe.includes(null === h || void 0 === h ? void 0 : h.toLowerCase()) && (0, m.jsx)(i.Suspense, {
                            fallback: (0, m.jsx)(Fe, {}),
                            children: null !== (r = E.chatMenu) && void 0 !== r && null !== (d = r.voiceSupport) && void 0 !== d && d.isEnabled && He.includes(null === (c = E.activeQuestion) || void 0 === c || null === (u = c.type) || void 0 === u ? void 0 : u.toLowerCase()) && "voice" === E.activeInput ? (0, m.jsx)(Oe, {}) : (0, m.jsx)(ze, {
                                message: h,
                                showChatWindowOptions: e.showChatWindowOptions
                            })
                        })]
                    }), (0, m.jsxs)("div", {
                        id: "ele-375",
                        className: "bounce-up flex flex-col items-center text-center bg-primaryBgColor fixed bottom-0 left-0 w-full p-4 rounded-t-3xl border-y border-customBorder2 " + ("offline" === v ? "block" : "hidden"),
                        children: [(0, m.jsx)("div", {
                            id: "ele-376",
                            className: "bg-bpBGRed p-4 rounded-full",
                            children: (0, m.jsx)("img", {
                                src: "https://cdn.express-chat.com/messenger/offline.svg",
                                alt: "",
                                width: 32,
                                height: 32,
                                style: {
                                    height: "32px",
                                    width: "32px"
                                }
                            })
                        }), (0, m.jsx)("div", {
                            id: "ele-377",
                            className: "font-mSemiBold text-xl p-2 mt-2",
                            children: "You're Offline!"
                        }), (0, m.jsx)("div", {
                            id: "ele-378",
                            className: "w-5/6 p-2 text-sm",
                            style: {
                                color: "#666666"
                            },
                            children: "Please check your internet connection. Your messages will be sent once the connection is restored."
                        }), (0, m.jsx)("div", {
                            id: "ele-379",
                            className: "text-sm p-2",
                            children: (0, m.jsx)(Re.A, {})
                        })]
                    }), (0, m.jsx)("div", {
                        id: "ele-380",
                        className: "absolute -top-20 py-2 px-3 rounded-xl fade-in " + ("online" === v ? "block" : "hidden"),
                        style: {
                            color: "#3DA144",
                            background: "#D0F0D2"
                        },
                        children: "You\u2019re back online and can continue chatting. Your connection has been restored."
                    })]
                })
            }

            function et(e) {
                const {
                    src: t
                } = e, s = (0, n.d4)((e => e.environment)), [a, o] = (0, i.useState)(1), r = (0, n.wA)();
                return (0, m.jsxs)("div", {
                    id: "400",
                    className: `absolute ${"rtl"===(null===s||void 0===s?void 0:s.direction)?"right-0":"left-0"} top-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50 transition-opacity duration-300 overflow-hidden`,
                    onClick: e => {
                        e.target.closest("button") || r((0, l.h8)({
                            imagePreview: {}
                        }))
                    },
                    children: [(0, m.jsx)("img", {
                        src: t,
                        alt: "markdown-img",
                        className: "max-w-80 max-h-80 transition-transform duration-300",
                        style: {
                            transform: `scale(${a})`,
                            transition: "transform 0.5s ease-in-out"
                        }
                    }), (0, m.jsx)("div", {
                        id: "401",
                        className: `flex justify-center items-center absolute bottom-0 ${"rtl"===(null===s||void 0===s?void 0:s.direction)?"right-0":"left-0"} w-full mb-4`,
                        children: (0, m.jsxs)("div", {
                            id: "403",
                            className: "bg-bpDarkCharcoal rounded-bpBorder20 p-bpPadding5",
                            children: [(0, m.jsx)("button", {
                                id: "404",
                                className: "text-white mx-2",
                                onClick: e => {
                                    e.preventDefault(), o(a - .4), a < 1 && o(1)
                                },
                                children: (0, m.jsx)("img", {
                                    src: "https://cdn.express-chat.com/messenger/remove.svg",
                                    alt: "zoom-out-image",
                                    className: "inline-block zoom-out mr-2"
                                })
                            }), (0, m.jsx)("button", {
                                id: "408",
                                className: "text-white",
                                onClick: e => {
                                    e.preventDefault(), a > 1 && o(1)
                                },
                                children: (0, m.jsx)("img", {
                                    id: "409",
                                    src: "https://cdn.express-chat.com/messenger/zoom_out.svg",
                                    alt: "handle-iamge",
                                    className: "inline-block cursor-pointer"
                                })
                            }), (0, m.jsx)("button", {
                                id: "406",
                                className: "text-white mx-2",
                                onClick: e => {
                                    e.preventDefault(), o(a + .4)
                                },
                                children: (0, m.jsx)("img", {
                                    src: "https://cdn.express-chat.com/messenger/add.svg",
                                    alt: "zoom-in",
                                    className: "inline-block zoom-in ml-2"
                                })
                            })]
                        })
                    }), (0, m.jsx)("div", {
                        id: "402",
                        className: "absolute bottom-0 right-0 mr-4 mb-4  ",
                        children: (0, m.jsx)("button", {
                            id: "407",
                            className: "text-white bg-bpDarkCharcoal p-bpPadding10 rounded-bpBorder50 flex justify-center items-center",
                            onClick: () => {
                                const e = document.createElement("a");
                                document.body.appendChild(e), e.setAttribute("style", "display: none"), e.setAttribute("target", "_blank"), e.href = t, e.download = t.split("/").pop(), e.click(), window.URL.revokeObjectURL(t), e.remove()
                            },
                            style: {
                                height: "36px",
                                width: "36px"
                            },
                            children: (0, m.jsx)("img", {
                                src: "https://cdn.express-chat.com/messenger/download.svg",
                                alt: "download-image",
                                className: "inline-block"
                            })
                        })
                    })]
                })
            }
            const tt = e => {
                    var t;
                    const s = (0, n.d4)((e => null === e || void 0 === e ? void 0 : e.environment)),
                        {
                            viewType: l
                        } = s,
                        {
                            hideMessengerHeader: a,
                            backgroundColor: o,
                            landingPageChatBackgroundColor: r
                        } = e.design || {},
                        d = window.self !== window.top,
                        c = "landing-page" === l && a && d,
                        u = "launcher-icon" === l ? o : r || "#FFFFFF",
                        h = null === s || void 0 === s ? void 0 : s.activeQuestion;
                    return (0, i.useEffect)((() => {
                        (0, S.JJ)()
                    }), [null === h || void 0 === h || null === (t = h.suggestions) || void 0 === t ? void 0 : t.length]), (0, m.jsxs)(m.Fragment, {
                        children: [(0, m.jsxs)("div", {
                            className: "flex flex-col justify-between font-mRegular min-w-80 p-4 h-full",
                            style: {
                                backgroundColor: u
                            },
                            id: "chatWindow",
                            children: [!c && (0, m.jsx)("div", {
                                id: "ele-182",
                                className: "h-16 max-h-20 rounded-xl",
                                children: (0, m.jsx)(Ie, {})
                            }), (0, m.jsx)("div", {
                                id: "chat-block",
                                className: "h-full flex flex-col justify-between overflow-auto pb-2",
                                children: (0, m.jsx)("div", {
                                    className: "flex-grow",
                                    id: "message-container",
                                    children: (0, m.jsx)(Ee, {
                                        shouldFetchData: Boolean(null === e || void 0 === e ? void 0 : e.shouldFetchData)
                                    })
                                })
                            }), (0, m.jsx)("div", {
                                id: "ele-303",
                                children: (0, m.jsx)(Xe, {
                                    showChatWindowOptions: c
                                })
                            }), (0, m.jsx)("div", {
                                id: "ele-304",
                                className: "h-3 max-h-4 mt-2 text-sm text-center",
                                children: (0, m.jsx)(Re.A, {})
                            }), (0, m.jsxs)("div", {
                                id: "ele-305",
                                className: "position-fixed",
                                children: [" ", (0, m.jsx)(_e.A, {}), " "]
                            })]
                        }), s.imagePreview && s.imagePreview.isActive && s.imagePreview.src && (0, m.jsx)(et, { ...s.imagePreview
                        })]
                    })
                },
                st = (0, i.memo)(tt)
        },
        18581: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => g
            });
            var i = s(9950),
                l = s(34928),
                n = s(23507),
                a = s(1092),
                o = s(69772),
                r = s(10300),
                d = s(94453),
                c = s(29349),
                u = s(32775),
                m = s(44414);
            const h = ["ai", "ai_agent"],
                p = e => {
                    var t, s, p, g, x;
                    const {
                        color: v,
                        shouldDisplayOptionInTyping: f
                    } = e, b = (0, i.useRef)(null), [j, y] = (0, i.useState)(!1), w = (0, r.d4)((e => null === e || void 0 === e ? void 0 : e.environment)), N = (0, r.d4)((e => null === e || void 0 === e ? void 0 : e.configuration)), k = (0, r.d4)((e => e.revisitFlow)), C = (0, r.wA)(), {
                        refreshChatText: S,
                        transferToWhatsAppText: T,
                        startLiveChatText: E,
                        transferToBotText: A,
                        toWhatsapp: M
                    } = (null === N || void 0 === N ? void 0 : N.chatMenu) || {}, {
                        chatRequestAccepted: B,
                        agentId: I
                    } = w || {};
                    let _;
                    _ = !localStorage.getItem("agentId") || !localStorage.getItem("bp-wsn");
                    const R = !(!w.typing && !w.ai.streaming);
                    (0, i.useEffect)((() => (document.addEventListener("mousedown", F), () => {
                        document.removeEventListener("mousedown", F)
                    })));
                    const F = e => {
                        b.current && !b.current.contains(e.target) && y(!1)
                    };
                    return (0, m.jsxs)("div", {
                        id: "ele-190",
                        className: "cursor-pointer rounded-full relative",
                        children: [(0, m.jsx)(d.A, {
                            onClick: () => y(!j),
                            sx: {
                                width: "32px",
                                height: "32px",
                                color: v
                            },
                            className: `hover:opacity-85 !text-2xl ${v} align-middle text-center rounded-full hover:border`
                        }), j && (0, m.jsxs)("div", {
                            id: "ele-191",
                            className: `absolute  ${"ltr"===(null===w||void 0===w?void 0:w.direction)?"right-0":"left-0"} ${f&&"bottom-0"}  bg-white w-52 flex flex-col text-primaryText shadow-xl text-sm rounded-lg items-start z-10`,
                            ref: b,
                            children: [!(null !== N && void 0 !== N && null !== (t = N.chatMenu) && void 0 !== t && t.hideTransferToWhatsApp) && (0, m.jsxs)("div", {
                                id: "ele-192",
                                className: `w-full ${!I&&"cursor-default opacity-60"}`,
                                onClick: () => {
                                    _ && M || ((0, n.$B)(), y(!1))
                                },
                                children: [(0, m.jsxs)("div", {
                                    id: "ele-193",
                                    className: "w-full py-3 px-4",
                                    children: [(0, m.jsx)("span", {
                                        id: "ele-194",
                                        children: (0, m.jsx)("img", {
                                            src: "https://cdn.express-chat.com/messenger/whatsapp.svg",
                                            alt: "whatsapp",
                                            className: "inline-block w-4"
                                        })
                                    }), (0, m.jsx)("span", {
                                        id: "ele-195",
                                        className: "" + ("ltr" === (null === w || void 0 === w ? void 0 : w.direction) ? "ml-2" : "mr-2"),
                                        children: T || "Transfer to Whatsapp"
                                    })]
                                }), (0, m.jsx)("hr", {
                                    id: "ele-196",
                                    className: "w-5/6 h-px float-right bg-gray-100 border-0 rounded"
                                })]
                            }), (null === N || void 0 === N || null === (s = N.chatMenu) || void 0 === s ? void 0 : s.toLiveChat) && (0, m.jsxs)("div", {
                                id: "ele-197",
                                className: "w-full",
                                style: {
                                    pointerEvents: R ? "none" : "auto",
                                    opacity: R ? .5 : 1
                                },
                                onClick: () => (y(!1), B ? (C((0, l.t)("BOT")), C((0, a.Zd)(null)), (0, n.K_)()) : (0, n.GV)()),
                                children: [(0, m.jsxs)("div", {
                                    id: "ele-198",
                                    className: "px-4 py-3 w-full",
                                    children: [(0, m.jsx)("span", {
                                        id: "ele-199",
                                        children: (0, m.jsx)("img", {
                                            src: "https://cdn.express-chat.com/messenger/live-chat.svg",
                                            alt: "chat",
                                            className: "inline-block w-4"
                                        })
                                    }), !1 === B ? (0, m.jsx)("span", {
                                        id: "ele-200",
                                        className: "" + ("ltr" === (null === w || void 0 === w ? void 0 : w.direction) ? "ml-2" : "mr-2"),
                                        children: E || "Start Live Chat"
                                    }) : (0, m.jsx)("span", {
                                        id: "ele-201",
                                        className: "" + ("ltr" === (null === w || void 0 === w ? void 0 : w.direction) ? "ml-2" : "mr-2"),
                                        children: A || "Transfer To Bot"
                                    })]
                                }), (0, m.jsx)("hr", {
                                    id: "ele-202",
                                    className: "w-5/6 h-px float-right bg-gray-100 border-0 rounded"
                                })]
                            }), (null === N || void 0 === N || null === (p = N.chatMenu) || void 0 === p ? void 0 : p.refreshChat) && (0, m.jsxs)("div", {
                                id: "ele-203",
                                className: "px-4 py-3 w-full",
                                style: {
                                    pointerEvents: R ? "none" : "auto",
                                    opacity: R ? .5 : 1
                                },
                                onClick: () => (() => {
                                    const {
                                        clearChatOnRestart: e
                                    } = (null === N || void 0 === N ? void 0 : N.chatMenu) || {};
                                    C((0, a.bo)()), c.Ay.stopListening(), (0, u.OK)(), C((0, o.En)({
                                        isMicOn: !1,
                                        isListening: !1
                                    }));
                                    const t = w.timerRef;
                                    t && clearTimeout(t), e && C((0, a.A3)()), C((0, a.Ah)([k])), C((0, a.VU)({
                                        value: "",
                                        original: ""
                                    })), C((0, l.t)("BOT")), C((0, o.h8)({
                                        selectedTags: [],
                                        batchedMessages: "",
                                        currentTimerRef: null,
                                        activeMID: ""
                                    })), (0, n.K_)(!0), y(!1)
                                })(),
                                children: [(0, m.jsx)("span", {
                                    id: "ele-204",
                                    children: (0, m.jsx)("img", {
                                        src: "https://cdn.express-chat.com/messenger/refresh-chat.svg",
                                        alt: "refresh",
                                        className: "inline-block w-4"
                                    })
                                }), (0, m.jsx)("span", {
                                    id: "ele-205",
                                    className: "" + ("ltr" === (null === w || void 0 === w ? void 0 : w.direction) ? "ml-2" : "mr-2"),
                                    children: S || "Refresh Chat"
                                })]
                            }), (null === N || void 0 === N || null === (g = N.chatMenu) || void 0 === g || null === (x = g.voiceSupport) || void 0 === x ? void 0 : x.isEnabled) && h.includes(w.activeQuestion.type.toLowerCase()) && (0, m.jsxs)("div", {
                                id: "ele-411",
                                className: "px-4 py-3 w-full",
                                style: {
                                    pointerEvents: R ? "none" : "auto",
                                    opacity: R ? .5 : 1
                                },
                                onClick: () => (C((0, a.bo)()), C((0, o.h8)({
                                    activeInput: "voice" === (null === w || void 0 === w ? void 0 : w.activeInput) ? "chat" : "voice"
                                })), void y(!1)),
                                children: [(0, m.jsx)("span", {
                                    id: "ele-412",
                                    children: (0, m.jsx)("img", {
                                        src: "https://cdn.express-chat.com/messenger/swap_horiz.svg",
                                        alt: "refresh",
                                        className: "inline-block w-4"
                                    })
                                }), (0, m.jsx)("span", {
                                    id: "ele-205",
                                    className: "" + ("ltr" === (null === w || void 0 === w ? void 0 : w.direction) ? "ml-2" : "mr-2"),
                                    children: `Switch to ${"voice"===(null===w||void 0===w?void 0:w.activeInput)?"Chat":"Voice"} Input`
                                })]
                            })]
                        })]
                    })
                };
            p.defaultProps = {
                shouldDisplayOptionInTyping: !1
            };
            const g = p
        },
        56931: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => o
            });
            var i = s(10300),
                l = s(42209),
                n = s(63189),
                a = s(44414);

            function o(e) {
                const t = (0, i.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                    s = (0, i.d4)((e => null === e || void 0 === e ? void 0 : e.environment));
                return (0, a.jsx)(a.Fragment, {
                    children: (0, a.jsxs)("div", {
                        id: "ele-46",
                        className: "p-4 bg-bpPrimary rounded-xl flex flex-row justify-between h-full text-white",
                        style: {
                            backgroundColor: t.themeColor || "#226CF4"
                        },
                        children: [(0, a.jsxs)("div", {
                            id: "ele-47",
                            className: "flex flex-row justify-start align-middle items-center",
                            children: [e.showBack && (0, a.jsx)(n.A, {
                                className: "align-middle !text-2xl text-white cursor-pointer mr-4",
                                onClick: e.backMethod
                            }), (0, a.jsx)("div", {
                                id: "ele-48",
                                children: e.type
                            })]
                        }), s && "launcher-icon" === s.viewType && (0, a.jsx)("div", {
                            id: "ele-49",
                            className: "cursor-pointer hover:opacity-70",
                            onClick: () => {
                                (new window.parent.BotPenguin).closeWindow(), localStorage.setItem("bp-user-close", "true")
                            },
                            children: (0, a.jsx)(l.A, {
                                className: "align-middle !text-3xl"
                            })
                        })]
                    })
                })
            }
        },
        42245: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => a
            });
            var i = s(9950),
                l = s(44414);
            const n = e => {
                    let {
                        type: t
                    } = e;
                    return (0, l.jsxs)("div", {
                        id: "ele-50",
                        className: "flex flex-col justify-center flex-grow items-center text-center",
                        children: [(0, l.jsx)("div", {
                            id: "ele-51",
                            className: "mb-8",
                            children: (0, l.jsx)("img", {
                                src: "https://cdn.express-chat.com/messenger/error.svg",
                                alt: "refresh",
                                className: "inline-block w-16"
                            })
                        }), (0, l.jsx)("div", {
                            id: "ele-52",
                            className: "font-mSemiBold mb-2",
                            children: (() => {
                                switch (t) {
                                    case "Knowledge Base":
                                        return "Page not available";
                                    case "Tickets":
                                        return "Help desk not available";
                                    case "Page not published":
                                        return "Page not published";
                                    default:
                                        return "No search results"
                                }
                            })()
                        }), (0, l.jsx)("div", {
                            id: "ele-53",
                            className: "text-lightText text-sm",
                            children: (() => {
                                switch (t) {
                                    case "Knowledge Base":
                                        return "We are currently experiencing some technical difficulties. Please try again later. #100001";
                                    case "Tickets":
                                        return "We are currently experiencing some technical difficulties. Please try again later. #100002";
                                    case "Page not published":
                                        return "We are updating the content of this page. Please try again later. #100003";
                                    default:
                                        return "We couldn\u2019t find any results matching your search. Please try rephrasing your search query"
                                }
                            })()
                        })]
                    })
                },
                a = (0, i.memo)(n)
        },
        17472: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => j
            });
            var i = s(9950),
                l = s(64942),
                n = s(10300),
                a = s(1092),
                o = s(42245),
                r = s(80392),
                d = s(71201),
                c = s(44414);
            const u = e => {
                    const t = (0, n.wA)();
                    return (0, c.jsxs)("div", {
                        id: "ele-54",
                        className: "px-3 py-3 text-xl text-primaryText h-full overflow-hidden",
                        children: [(0, c.jsx)("div", {
                            id: "ele-55",
                            className: "text-primaryText text-lg font-mSemiBold mb-2",
                            children: "Categories"
                        }), (0, c.jsxs)("div", {
                            id: "ele-56",
                            className: "overflow-scroll h-full hide-scrollbar",
                            children: [(e.hubspotPages || []).map((s => {
                                var i;
                                return (0, c.jsxs)("div", {
                                    className: "ele-knowledgebase-hubspotpages flex flex-row items-center mb-2 py-1 px-1 rounded-md cursor-pointer bg-white",
                                    onClick: () => (e => {
                                        e.pages && e.pages.length ? (t((0, a.pm)(e.pages)), t((0, a.$q)("subpage")), t((0, a.y8)({
                                            id: e.id || "",
                                            type: "add"
                                        }))) : e.urls && e.urls.app && (t((0, a.Rk)(e.urls.app)), t((0, a.$q)("content")))
                                    })(s),
                                    children: [(0, c.jsx)(d.A, {
                                        className: "align-middle items-center text-primaryColor",
                                        style: {
                                            color: null === e || void 0 === e || null === (i = e.design) || void 0 === i ? void 0 : i.themeColor
                                        }
                                    }), (0, c.jsxs)("div", {
                                        className: "flex flex-col w-5/6 px-3 ele-knowledgebase-hubspotpage-body",
                                        children: [(0, c.jsx)("div", {
                                            className: "text-sm truncate w-4/5 ele-knowledgebase-hubspotpage-title",
                                            children: s.title
                                        }), (0, c.jsx)("div", {
                                            className: "text-xs truncate w-4/5 leading-5 text-lightText ele-knowledgebase-hubspotpage-description",
                                            children: s.description || s.title
                                        })]
                                    }), (0, c.jsx)(r.A, {
                                        className: "align-middle items-center text-footer"
                                    })]
                                }, `kb-${s.title}`)
                            })), !e.hubspotPages.length && (0, c.jsx)("div", {
                                id: "ele-61",
                                className: "flex mt-12",
                                children: (0, c.jsx)(o.A, {
                                    type: "No Category"
                                })
                            })]
                        })]
                    })
                },
                m = (0, i.memo)(u);
            var h = s(46639);
            const p = () => {
                    const e = (0, i.useRef)(null),
                        [t, s] = (0, i.useState)(!1),
                        [l, a] = (0, i.useState)(!0),
                        r = (0, n.d4)((e => e.knowledgeBase)),
                        d = (0, i.useCallback)((() => {
                            const e = r.activeURL.replaceAll(r.urls.app.split("~")[0], "");
                            if (!r.urls.published && !r.urls.public) return s(!0), a(!1), "";
                            return `https://${new URL(r.urls.published||r.urls.public).hostname}/${e}`
                        }), [r]);
                    return (0, i.useEffect)((() => {
                        const t = e.current;
                        if (t) {
                            const e = () => {
                                a(!1)
                            };
                            return t.addEventListener("load", e), () => {
                                t.removeEventListener("load", e)
                            }
                        }
                    }), []), (0, c.jsxs)(c.Fragment, {
                        children: [l && (0, c.jsx)("div", {
                            id: "ele-62",
                            className: "flex items-center justify-center h-full",
                            children: (0, c.jsx)(h.A, {})
                        }), t ? (0, c.jsx)("div", {
                            id: "ele-63",
                            className: "flex items-center justify-center h-full",
                            children: (0, c.jsx)(o.A, {
                                type: "Knowledge Base"
                            })
                        }) : (0, c.jsx)("iframe", {
                            id: "ele-64",
                            ref: e,
                            title: "help",
                            src: d(),
                            className: "h-full w-full hide-scrollbar rounded-t-md"
                        })]
                    })
                },
                g = (0, i.memo)(p);
            var x = s(56931),
                v = s(51162),
                f = s(19223);
            const b = e => {
                    var t;
                    const s = (0, n.wA)(),
                        [r, d] = (0, i.useState)(""),
                        [u, p] = (0, i.useState)(!1),
                        [b, j] = (0, i.useState)(!0),
                        [y, w] = (0, i.useState)([]),
                        N = (0, n.d4)((e => e.knowledgeBase)),
                        k = (0, i.useCallback)((() => {
                            (0, v.nN)().then((e => {
                                if (!e || e.name && "AxiosError" === e.name) throw new Error("Failed");
                                s((0, a.DZ)({
                                    allPages: e.pages || [],
                                    urls: e.urls
                                }))
                            })).catch((e => {
                                console.log(e), p(!0)
                            })).finally((() => j(!1)))
                        }), [s]);
                    (0, i.useEffect)((() => {
                        s((0, a.$q)("page")), s((0, a.bt)({
                            type: "subpages"
                        })), k()
                    }), [k, s]), (0, i.useEffect)((() => {
                        if ("content" !== N.activeRoute)
                            if (r) {
                                const e = ("page" === N.activeRoute ? N.allPages : N.subPages).filter((e => {
                                    var t;
                                    return e.title.toLowerCase().includes(r.toLowerCase()) || (null === (t = e.description) || void 0 === t ? void 0 : t.toLowerCase().includes(r.toLowerCase()))
                                }));
                                w(e)
                            } else w("page" === N.activeRoute ? N.allPages : N.subPages)
                    }), [N.allPages, N.subPages, N.activeRoute, r]);
                    const C = (e, t) => {
                        for (const s of e) {
                            if (s.id === t) return s;
                            const e = C(s.pages, t);
                            if (e) return e
                        }
                        return null
                    };
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            className: "flex flex-col justify-start rounded-t-2xl font-mRegular min-w-96 px-4 pt-4 h-full overflow-hidden",
                            style: {
                                backgroundColor: null === e || void 0 === e || null === (t = e.design) || void 0 === t ? void 0 : t.backgroundColor
                            },
                            id: "chatWindow",
                            children: [(0, c.jsx)("div", {
                                id: "ele-39",
                                className: "h-16 max-h-20 rounded-xl",
                                children: (0, c.jsx)(x.A, {
                                    type: "Knowledge Base",
                                    backMethod: () => {
                                        const e = [...N.activePageIds].pop();
                                        if (e) {
                                            const t = C(N.allPages, e);
                                            t ? (s((0, a.$q)("subpage")), s((0, a.pm)(t.pages)), s((0, a.y8)({
                                                id: e,
                                                type: "remove"
                                            }))) : (s((0, a.$q)("page")), s((0, a.bt)({
                                                type: "subpages"
                                            })))
                                        } else s((0, a.$q)("page")), s((0, a.bt)({
                                            type: "subpages"
                                        }))
                                    },
                                    showBack: ["content", "subpage"].includes(N.activeRoute)
                                })
                            }), b ? (0, c.jsx)("div", {
                                id: "ele-40",
                                className: "flex items-center justify-center h-full",
                                children: (0, c.jsx)(h.A, {})
                            }) : u ? (0, c.jsx)(c.Fragment, {
                                children: (0, c.jsx)(o.A, {
                                    type: "Knowledge Base"
                                })
                            }) : (0, c.jsxs)(c.Fragment, {
                                children: ["content" !== N.activeRoute && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsxs)("div", {
                                        id: "ele-41",
                                        className: "w-full mt-6 px-4 relative h-11",
                                        children: [(0, c.jsx)("input", {
                                            value: r,
                                            id: "bp-input-4",
                                            placeholder: "Search categories",
                                            onChange: e => d(e.target.value),
                                            className: "w-full outline-none font-mRegular text-base resize-none rounded-xl py-3 pl-8 pr-4 h-full text-primaryText bg-primaryBgColor"
                                        }), (0, c.jsx)(f.A, {
                                            id: "ele-42",
                                            className: "align-middle text-footer !text-lg absolute left-7 top-3 w-8"
                                        })]
                                    }), (0, c.jsxs)("div", {
                                        id: "ele-43",
                                        className: "overflow-y-auto hide-scrollbar",
                                        children: [" ", (0, c.jsx)(m, {
                                            design: null === e || void 0 === e ? void 0 : e.design,
                                            hubspotPages: y
                                        })]
                                    })]
                                }), "content" === N.activeRoute && (0, c.jsxs)("div", {
                                    id: "ele-44",
                                    className: "overflow-y-auto hide-scrollbar h-full",
                                    children: [" ", (0, c.jsx)(g, {})]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: "position-fixed",
                                children: [" ", (0, c.jsx)(l.A, {}), " "]
                            })]
                        })
                    })
                },
                j = (0, i.memo)(b)
        },
        64942: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => l
            });
            var i = s(44414);

            function l() {
                return (0, i.jsx)(i.Fragment, {})
            }
        },
        27945: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => h
            });
            var i = s(10300),
                l = s(26668);
            const n = e => ({
                type: l.Rd,
                payload: e
            });
            var a = s(88569),
                o = s(80937),
                r = s(85907),
                d = s(92613),
                c = s(9950),
                u = s(72796),
                m = s(44414);

            function h() {
                const [e, t] = (0, c.useState)({
                    name: "",
                    email: "",
                    phone: {
                        prefix: "",
                        number: ""
                    }
                }), [s, l] = (0, c.useState)(!1), [h, p] = (0, c.useState)(!1), g = (0, i.wA)(), x = (0, i.d4)((e => null === e || void 0 === e ? void 0 : e.configuration)), v = (0, i.d4)((e => null === e || void 0 === e ? void 0 : e.environment)), f = (0, i.d4)((e => e && e.footerTab)), b = e => {
                    g(n(e))
                };
                (0, c.useEffect)((() => {
                    try {
                        ("true" === sessionStorage.getItem("isUnsure") || v.isAiUnsure) && p(!0)
                    } catch (e) {
                        console.log(e)
                    }
                }), [v.isAiUnsure]);
                const j = t => {
                    var s, i;
                    switch (t) {
                        case "knowledgeBase":
                            return !!x && x.chatMenu && (null === (s = x.chatMenu.knowledgeBase) || void 0 === s ? void 0 : s.enabled);
                        case "tickets":
                            return !!x && x.chatMenu && (null === (i = x.chatMenu.ticketing) || void 0 === i ? void 0 : i.enabled);
                        case "whatsapp":
                            return (null === e || void 0 === e ? void 0 : e.isRootAgency) || !1;
                        default:
                            return !1
                    }
                };
                return (0, c.useEffect)((() => {
                    const i = s => {
                        "BotPenguin" === s.data.origin && ("getRequestedUserMeta" !== s.data.action || e.email || (t(s.data.payload), l(!0), (0, u.Rl)({
                            email: s.data.payload.email,
                            lead: !0
                        }).catch()))
                    };
                    return window.addEventListener("message", i), e.email || s || window.parent.postMessage({
                        origin: "BotPenguin",
                        action: "requestingUserMeta"
                    }, "*"), () => {
                        window.removeEventListener("message", i)
                    }
                }), [e.email, s]), (0, m.jsx)(m.Fragment, {
                    children: (0, m.jsxs)("div", {
                        id: "ele-26",
                        className: "flex flex-row items-center justify-evenly h-full bg-primaryBgColor py-1",
                        children: [(0, m.jsxs)("div", {
                            id: "ele-27",
                            className: "text-center cursor-pointer",
                            onClick: () => b("Chat"),
                            children: [(0, m.jsx)("span", {
                                id: "ele-28",
                                className: `px-5 py-2 flex w-fit m-auto ${"Chat"===f&&"bg-footerSelectedBG rounded-3xl"}`,
                                children: (0, m.jsx)(r.A, {
                                    id: "ele-29",
                                    className: `align-middle !text-2xl text-footer m-auto ${"Chat"===f&&"!text-footerSelected "}`
                                })
                            }), (0, m.jsx)("div", {
                                id: "ele-30",
                                className: "text-sm mt-2 ",
                                children: "Chat"
                            })]
                        }), j("knowledgeBase") && (0, m.jsxs)("div", {
                            id: "ele-31",
                            className: "text-center cursor-pointer",
                            onClick: () => b("Knowledge Base"),
                            children: [(0, m.jsx)("span", {
                                id: "ele-32",
                                className: `px-5 py-2 flex w-fit m-auto ${"Knowledge Base"===f&&"bg-footerSelectedBG rounded-3xl"}`,
                                children: (0, m.jsx)(o.A, {
                                    id: "ele-33",
                                    className: `align-middle !text-2xl text-footer m-auto ${"Knowledge Base"===f&&"!text-footerSelected "}`
                                })
                            }), (0, m.jsx)("div", {
                                id: "ele-34",
                                className: "text-sm mt-2",
                                children: "Knowledge Base"
                            })]
                        }), j("tickets") && (0, m.jsxs)("div", {
                            id: "ele-35",
                            className: "text-center cursor-pointer",
                            onClick: () => b("Tickets"),
                            children: [(0, m.jsx)("span", {
                                id: "ele-36",
                                className: `px-5 py-2 flex ${"Tickets"===f&&"bg-footerSelectedBG rounded-3xl"}`,
                                children: (0, m.jsx)(a.A, {
                                    id: "ele-37",
                                    className: `align-middle !text-2xl text-footer m-auto ${"Tickets"===f&&"!text-footerSelected "}`
                                })
                            }), (0, m.jsx)("div", {
                                id: "ele-38",
                                className: "text-sm mt-2",
                                children: "Tickets"
                            })]
                        }), j("whatsapp") && (0, m.jsxs)("div", {
                            id: "ele-413",
                            className: "text-center" + (h ? " cursor-pointer" : ""),
                            onClick: () => {
                                var t;
                                if (!h) return;
                                const s = `Hi Team,\nI want to build WhatsApp Bot, Please help us build the same. Here are my details\n\nRegistered Email: ${(null===e||void 0===e?void 0:e.email)||""}\nRegistered Phone: ${(null===e||void 0===e||null===(t=e.phone)||void 0===t?void 0:t.number)||"N/A"}\n\nThanks`;
                                window.open(`https://wa.me/916283368463/?text=${encodeURIComponent(s)}`, "_blank'")
                            },
                            children: [(0, m.jsx)("span", {
                                id: "ele-414",
                                className: "px-5 py-2 flex",
                                children: (0, m.jsx)(d.A, {
                                    color: h ? "success" : "disabled",
                                    id: "ele-415",
                                    className: "align-middle !text-2xl text-footer m-auto"
                                })
                            }), (0, m.jsx)("div", {
                                id: "ele-416",
                                className: "text-sm mt-2",
                                children: "WhatsApp"
                            })]
                        })]
                    })
                })
            }
        },
        29942: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => n
            });
            var i = s(10300),
                l = s(44414);

            function n() {
                const e = (0, i.d4)((e => null === e || void 0 === e ? void 0 : e.environment)),
                    t = t => {
                        var s, i, n, a, o, r, d;
                        const c = ["WHITE_LABEL", "SP_IMPLEMENTATION"].includes(null === e || void 0 === e || null === (s = e.agencyData) || void 0 === s ? void 0 : s.type),
                            u = null === (i = e.agencyData) || void 0 === i || null === (n = i.isAgencyConfigurationEnabled) || void 0 === n ? void 0 : n.poweredBy;
                        switch (t) {
                            case "websiteUrl":
                                return c ? (null === (a = e.agencyData.meta) || void 0 === a ? void 0 : a.websiteUrl) || "" : `https://botpenguin.com/?utm_source=referral&utm_medium=${window.location.host}&utm_campaign=chat_window`;
                            case "poweredBy":
                                return null !== (o = e.whitelabel) && void 0 !== o && o.active ? "" : c ? u && (null === e || void 0 === e || null === (r = e.agencyData) || void 0 === r || null === (d = r.meta) || void 0 === d ? void 0 : d.poweredBy) || "" : (0, l.jsxs)("span", {
                                    children: [" ", (0, l.jsx)("span", {
                                        className: "text-primaryText",
                                        children: "Chat \u26a1\ufe0f by Bot"
                                    }), "Penguin "]
                                });
                            default:
                                return ""
                        }
                    };
                return (0, l.jsx)(l.Fragment, {
                    children: (0, l.jsx)("div", {
                        id: "ele-24",
                        className: "",
                        children: (0, l.jsx)("a", {
                            id: "ele-25",
                            href: t("websiteUrl"),
                            target: "_blank",
                            rel: "noopener noreferrer",
                            style: {
                                textDecoration: "none",
                                color: "#1661f5"
                            },
                            children: t("poweredBy")
                        })
                    })
                })
            }
        },
        53202: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => F
            });
            var i = s(9950),
                l = s(10300),
                n = s(33889),
                a = s(24567),
                o = s(44414);
            const r = (0, a.A)(n.A)((e => {
                    let {
                        design: t
                    } = e;
                    return {
                        "& .MuiInputLabel-asterisk": {
                            color: "red"
                        },
                        "& label.Mui-focused": {
                            color: null === t || void 0 === t ? void 0 : t.themeColor
                        },
                        "& label": {
                            color: "#9ca3af",
                            fontWeight: "normal"
                        },
                        "& .MuiOutlinedInput-root": {
                            backgroundColor: "white",
                            "& fieldset": {
                                borderColor: "#d1d5db"
                            },
                            "&:hover fieldset": {
                                borderColor: "#d1d5db",
                                borderWidth: "1px"
                            },
                            "&.Mui-focused fieldset": {
                                borderColor: "#d1d5db",
                                borderWidth: "1px"
                            }
                        }
                    }
                })),
                d = e => (0, o.jsx)(r, {
                    fullWidth: !0,
                    variant: "outlined",
                    ...e
                });
            var c = s(76087),
                u = s.n(c),
                m = s(38612),
                h = s(46639),
                p = s(32775),
                g = s(51162),
                x = s(69772),
                v = s(79708),
                f = s(96319);
            const b = e => {
                    const t = (0, l.wA)(),
                        s = (0, i.useRef)(null),
                        [n, a] = (0, i.useState)(!1),
                        [r, c] = (0, i.useState)([]),
                        b = (0, l.d4)((e => null === e || void 0 === e ? void 0 : e.design)),
                        [j, y] = (0, i.useState)([]),
                        [w, N] = (0, i.useState)(!1),
                        [k, C] = (0, i.useState)(!1),
                        S = (0, l.d4)((e => null === e || void 0 === e ? void 0 : e.environment)),
                        [T, E] = (0, i.useState)({
                            attachments: [],
                            content: "",
                            email: "",
                            name: "",
                            subject: "",
                            category: ""
                        });
                    (0, i.useEffect)((() => {
                        const e = e => {
                            if ("BotPenguin" === e.data.origin && "getRequestedUserMeta" === e.data.action && !T.email) {
                                const {
                                    name: t,
                                    email: s
                                } = e.data.payload;
                                E((e => ({ ...e,
                                    name: t,
                                    email: s
                                }))), C(!0)
                            }
                        };
                        return window.addEventListener("message", e), T.email || k || window.parent.postMessage({
                            origin: "BotPenguin",
                            action: "requestingUserMeta"
                        }, "*"), () => {
                            window.removeEventListener("message", e)
                        }
                    }), [T.email, k]), (0, i.useEffect)((() => {
                        (0, g.bW)().then((e => {
                            y(e)
                        })).catch((e => console.log("Can't fetch categories" + e)))
                    }), []);
                    const A = (e, t) => {
                            E((s => ({ ...s,
                                [t]: e
                            })))
                        },
                        M = () => u().isEmail(T.email.trim()) && T.name.trim() && T.subject.trim() && T.content.trim() && (!!j.length && T.category.trim() || !j.length),
                        B = () => {
                            try {
                                window.newNoteRef && window.newNoteRef.current && window.newNoteRef.current.scrollTo({
                                    top: window.newNoteRef.current.scrollHeight,
                                    behavior: "smooth"
                                })
                            } catch (e) {
                                console.log(e)
                            }
                        };
                    return (0, i.useEffect)((() => {
                        window.newNoteRef = (0, i.createRef)()
                    }), []), (0, i.useEffect)((() => {
                        E((e => ({ ...e,
                            email: S.ticketsEmail || ""
                        })))
                    }), [S.ticketsEmail]), (0, o.jsx)(o.Fragment, {
                        children: (0, o.jsx)("div", {
                            id: "ele-143",
                            className: "relative h-full overflow-y-auto",
                            children: (0, o.jsxs)("div", {
                                id: "ele-144",
                                className: "flex flex-col h-full pt-4 justify-between",
                                children: [(0, o.jsxs)("div", {
                                    id: "ele-145",
                                    className: "w-full px-2 pb-3 h-[calc(100%-3rem)] overflow-scroll hide-scrollbar",
                                    ref: window.newNoteRef,
                                    children: [(0, o.jsx)("div", {
                                        id: "ele-146",
                                        className: "text-primaryText text-base font-mSemiBold",
                                        children: "Ticket Details"
                                    }), (0, o.jsx)("div", {
                                        id: "ele-147",
                                        className: "mt-4",
                                        children: (0, o.jsx)(d, {
                                            design: b,
                                            required: !0,
                                            size: "small",
                                            label: "Full Name",
                                            value: T.name,
                                            inputProps: {
                                                maxLength: 50
                                            },
                                            onChange: e => A(e.target.value, "name")
                                        })
                                    }), (0, o.jsx)("div", {
                                        id: "ele-148",
                                        className: "mt-4",
                                        children: (0, o.jsx)(d, {
                                            design: b,
                                            required: !0,
                                            size: "small",
                                            label: "Email",
                                            value: T.email,
                                            inputProps: {
                                                maxLength: 100
                                            },
                                            error: (I = T.email, !(!I || u().isEmail(I.trim()))),
                                            onChange: e => A(e.target.value, "email")
                                        })
                                    }), (0, o.jsx)("div", {
                                        id: "ele-149",
                                        className: "mt-4",
                                        children: (0, o.jsx)(d, {
                                            design: b,
                                            required: !0,
                                            size: "small",
                                            label: "Issue Title",
                                            value: T.subject,
                                            inputProps: {
                                                maxLength: 500
                                            },
                                            onChange: e => A(e.target.value, "subject")
                                        })
                                    }), (0, o.jsx)("div", {
                                        id: "ele-150",
                                        className: "mt-4",
                                        children: (0, o.jsx)(d, {
                                            design: b,
                                            required: !0,
                                            size: "small",
                                            select: !0,
                                            label: "Category",
                                            value: T.category,
                                            onChange: e => A(e.target.value, "category"),
                                            children: j.map((e => (0, o.jsx)(m.A, {
                                                className: "ele-tickets-category-menuitem",
                                                value: e.value,
                                                children: e.label
                                            }, "category " + e.label)))
                                        })
                                    }), (0, o.jsx)("div", {
                                        id: "ele-152",
                                        className: "mt-4",
                                        children: (0, o.jsx)(d, {
                                            design: b,
                                            required: !0,
                                            label: "Issue Description",
                                            multiline: !0,
                                            rows: 3,
                                            value: T.content,
                                            inputProps: {
                                                maxLength: 1200
                                            },
                                            onChange: e => A(e.target.value, "content")
                                        })
                                    }), !!r.length && (0, o.jsxs)("div", {
                                        id: "ele-153",
                                        className: "mt-4 flex flex-col",
                                        children: [(0, o.jsx)("div", {
                                            id: "ele-154",
                                            className: "text-primaryText text-base font-mSemiBold",
                                            children: "Attachment"
                                        }), r.map((e => (0, o.jsxs)("div", {
                                            className: "ele-create-ticket-attachment-container w-full h-12 flex justify-between bg-secondaryBgColor items-center px-4 mt-3 rounded-md",
                                            children: [(0, o.jsxs)("div", {
                                                className: "ele-create-ticket-attachment-name align-middle items-center w-4/6 truncate ",
                                                children: [e.name, " "]
                                            }), e.uploaded ? (0, o.jsxs)("div", {
                                                children: [e.failed && (0, o.jsx)("span", {
                                                    className: "ele-create-ticket-attachment-upload-failed text-bpRed mx-2",
                                                    children: "Failed"
                                                }), (0, o.jsx)(f.A, {
                                                    className: "align-middle !font-bold !text-2xl text-bpRed2 cursor-pointer ele-create-ticket-attachment-close-icon",
                                                    onClick: () => (e => {
                                                        c((t => t.filter((t => t.name !== e.name))))
                                                    })(e)
                                                })]
                                            }) : (0, o.jsx)(h.A, {
                                                size: 16
                                            })]
                                        }, "file-" + e.name)))]
                                    })]
                                }), (0, o.jsxs)("div", {
                                    id: "ele-159",
                                    className: "flex justify-between border-y border-solid border-gray-300 bg-white w-full fixed bottom-24 left-0 px-4 py-2",
                                    children: [n && (0, o.jsx)("div", {
                                        id: "ele-160",
                                        className: "fixed bottom-40 left-0 px-4 py-2 text-center w-full text-bpRed bg-white border-t border-solid border-gray-300 rounded-t-lg",
                                        children: "Uh-oh, there was a problem, please try again."
                                    }), (0, o.jsxs)("div", {
                                        id: "ele-161",
                                        className: "flex align-middle",
                                        children: [(0, o.jsx)("input", {
                                            id: "ele-162",
                                            className: "hidden",
                                            ref: s,
                                            type: "file",
                                            accept: "image/*",
                                            onChange: e => (e => {
                                                c((t => [...t, {
                                                    name: e.target.files[0].name,
                                                    url: "",
                                                    uploaded: !1,
                                                    failed: !1
                                                }]));
                                                const t = new FormData;
                                                t.append("file", e.target.files[0], e.target.files[0].name), (0, p.o7)(t).then((t => {
                                                    if (!t.data) throw new Error("Upload failed");
                                                    c((s => [...s.filter((t => t.name !== e.target.files[0].name)), {
                                                        name: e.target.files[0].name,
                                                        url: t.data,
                                                        uploaded: !0,
                                                        failed: !1
                                                    }]))
                                                })).catch((t => {
                                                    c((t => [...t.filter((t => t.name !== e.target.files[0].name)), {
                                                        name: e.target.files[0].name,
                                                        url: "",
                                                        uploaded: !0,
                                                        failed: !0
                                                    }]))
                                                })).finally((() => B()))
                                            })(e)
                                        }), (0, o.jsx)(v.A, {
                                            className: "m-auto !font-bold !text-2xl text-footer cursor-pointer",
                                            onClick: () => (s.current.value = null, void s.current.click())
                                        })]
                                    }), (0, o.jsxs)("div", {
                                        className: "flex",
                                        id: "ele-163",
                                        children: [(0, o.jsx)("div", {
                                            id: "ele-164",
                                            className: "align-middle justify-center items-center text-black rounded-lg px-6 py-2 cursor-pointer h-10",
                                            style: {
                                                backgroundColor: "#DFE1E4"
                                            },
                                            onClick: e.backMethod,
                                            children: "Cancel"
                                        }), (0, o.jsxs)("div", {
                                            id: "ele-165",
                                            className: "align-middle justify-center items-center text-white rounded-lg px-6 py-2 ml-4 h-10 " + (M() ? "cursor-pointer" : "opacity-50 cursor-default"),
                                            style: {
                                                backgroundColor: null === b || void 0 === b ? void 0 : b.themeColor
                                            },
                                            onClick: () => {
                                                if (!M() || w) return !1;
                                                N(!0), (0, g.Af)({ ...T,
                                                    attachments: r.map((e => e.url))
                                                }).then((() => {
                                                    t((0, x.h8)({
                                                        ticketsEmail: T.email
                                                    })), e.backMethod()
                                                })).catch((e => {
                                                    console.log(e), a(!0), setTimeout((() => {
                                                        a(!1)
                                                    }), 3e3)
                                                })).finally((() => N(!1)))
                                            },
                                            children: ["Submit Ticket", (0, o.jsx)("span", {
                                                id: "ele-166",
                                                className: "ml-2 ",
                                                children: w && (0, o.jsx)(h.A, {
                                                    size: 12,
                                                    sx: {
                                                        color: "white"
                                                    }
                                                })
                                            })]
                                        })]
                                    })]
                                })]
                            })
                        })
                    });
                    var I
                },
                j = (0, i.memo)(b);
            var y = s(88569),
                w = s(48939);
            const N = e => {
                    const t = (0, l.d4)((e => null === e || void 0 === e ? void 0 : e.design));
                    return (0, o.jsx)(o.Fragment, {
                        children: (0, o.jsx)("div", {
                            id: "ele-68",
                            className: "flex flex-col justify-around h-full",
                            children: (0, o.jsxs)("div", {
                                id: "ele-69",
                                className: "flex flex-col h-fit items-center",
                                children: [(0, o.jsx)("div", {
                                    id: "ele-70",
                                    className: "mb-3",
                                    children: (0, o.jsx)(y.A, {
                                        className: "align-middle !text-5xl text-footer"
                                    })
                                }), (0, o.jsx)("div", {
                                    id: "ele-71",
                                    className: "text-primaryText text-lg font-mSemiBold pb-1",
                                    children: "No Tickets Created Yet"
                                }), (0, o.jsx)("div", {
                                    id: "ele-72",
                                    className: "text-gray-400 text-xs text-center pb-7 px-8",
                                    children: "You haven\u2019t created any help tickets. If you need assistance, please create a new ticket."
                                }), (0, o.jsxs)("div", {
                                    id: "ele-73",
                                    className: "align-middle justify-center items-center text-white rounded-lg px-6 py-2 cursor-pointer shadow-md",
                                    style: {
                                        backgroundColor: null === t || void 0 === t ? void 0 : t.themeColor
                                    },
                                    onClick: e.createNewTicket,
                                    children: [(0, o.jsx)(w.A, {
                                        className: "!text-xl align-middle justify-center items-center"
                                    }), (0, o.jsx)("button", {
                                        id: "ele-74",
                                        className: "align-bottom ml-2",
                                        children: "Create New Ticket"
                                    })]
                                })]
                            })
                        })
                    })
                },
                k = (0, i.memo)(N);
            var C = s(56931);
            const S = e => {
                    const t = (0, l.d4)((e => null === e || void 0 === e ? void 0 : e.design));
                    return (0, o.jsxs)(o.Fragment, {
                        children: [(0, o.jsxs)("div", {
                            id: "ele-76",
                            className: " overflow-y-scroll relative h-full hide-scrollbar",
                            children: [!!e.openTickets.length && (0, o.jsxs)("div", {
                                id: "ele-77",
                                className: "text-primaryText text-xl font-bold px-2 py-4 pb-0",
                                children: [(0, o.jsx)("div", {
                                    id: "ele-78",
                                    className: "pb-2 text-primaryText text-lg font-mSemiBold",
                                    children: "Pending Tickets"
                                }), (0, o.jsx)("div", {
                                    id: "ele-79",
                                    className: "flex flex-col",
                                    children: e.openTickets.map(((t, s) => (0, o.jsxs)("div", {
                                        className: "ele-open-tickets flex flex-col border border-solid rounded-xl p-3 mb-3 cursor-pointer bg-white",
                                        onClick: () => e.setTicketDetails(t),
                                        children: [(0, o.jsxs)("div", {
                                            className: "ele-open-tickets-header flex justify-between",
                                            children: [(0, o.jsxs)("div", {
                                                className: "ele-open-ticket-id text-secondaryText text-xs font-thin",
                                                children: [(0, p.Yq)(t.createdAt), "\u30fb#", t.id]
                                            }), (0, o.jsx)("div", {
                                                className: "ele-open-ticket-status text-orange text-xs",
                                                children: "Pending"
                                            })]
                                        }), (0, o.jsxs)("div", {
                                            className: "ele-open-ticket-body flex flex-col",
                                            children: [(0, o.jsx)("div", {
                                                className: "ele-open-ticket-subject text-sm font-mSemiBold mt-1 font-thin",
                                                children: t.subject
                                            }), (0, o.jsx)("div", {
                                                className: "ele-open-ticket-content text-xs mt-1 text-footer font-thin",
                                                children: t.content
                                            })]
                                        })]
                                    }, "ticket" + t.id)))
                                })]
                            }), !!e.closedTickets.length && (0, o.jsxs)("div", {
                                id: "ele-87",
                                className: "text-primaryText text-xl font-bold px-2 p-4",
                                children: [(0, o.jsx)("div", {
                                    id: "ele-88",
                                    className: "pb-2 text-primaryText text-lg font-mSemiBold",
                                    children: "Resolved Tickets"
                                }), (0, o.jsx)("div", {
                                    id: "ele-89",
                                    className: "flex flex-col",
                                    children: e.closedTickets.map(((t, s) => (0, o.jsxs)("div", {
                                        className: "ele-closed-tickets flex flex-col border border-solid rounded-xl p-3 mb-3 cursor-pointer bg-white",
                                        onClick: () => e.setTicketDetails(t),
                                        children: [(0, o.jsxs)("div", {
                                            className: "flex justify-between ele-closed-ticket-header",
                                            children: [(0, o.jsxs)("div", {
                                                className: "ele-closed-ticket-id text-secondaryText text-xs font-thin",
                                                children: [(0, p.Yq)(t.createdAt), "\u30fb#", t.id]
                                            }), (0, o.jsx)("div", {
                                                className: "ele-closed-ticket-status text-green text-xs",
                                                children: "Resolved"
                                            })]
                                        }), (0, o.jsxs)("div", {
                                            className: "ele-closed-tickets-body flex flex-col",
                                            children: [(0, o.jsx)("div", {
                                                className: "ele-closed-ticket-subject text-sm font-mSemiBold mt-1 font-thin",
                                                children: t.subject
                                            }), (0, o.jsx)("div", {
                                                className: "ele-closed-ticket-content text-xs mt-1 text-footer font-thin",
                                                children: t.content
                                            })]
                                        })]
                                    }, "ticket" + t.id)))
                                })]
                            })]
                        }), (0, o.jsxs)("div", {
                            id: "ele-97",
                            className: "absolute bottom-4 right-0 align-middle justify-center items-center text-white rounded-lg px-6 py-2 cursor-pointer shadow-md",
                            style: {
                                backgroundColor: null === t || void 0 === t ? void 0 : t.themeColor
                            },
                            onClick: e.createNewTicket,
                            children: [(0, o.jsx)(w.A, {
                                className: "!text-xl align-middle justify-center items-center"
                            }), (0, o.jsx)("button", {
                                id: "ele-98",
                                className: "align-bottom ml-2",
                                children: "Create New Ticket"
                            })]
                        })]
                    })
                },
                T = (0, i.memo)(S);
            var E = s(64942),
                A = s(760),
                M = s.n(A);
            const B = e => {
                    const [t, s] = (0, i.useState)([]), [n, a] = (0, i.useState)(""), r = (0, l.d4)((e => null === e || void 0 === e ? void 0 : e.design)), [c, u] = (0, i.useState)(!1);
                    const m = (0, i.useCallback)((() => {
                        (0, g.Vl)(e.ticket.id).then((e => {
                            s((e.results || []).reverse())
                        })).catch((e => console.log(e)))
                    }), [e.ticket.id]);
                    (0, i.useEffect)((() => {
                        m()
                    }), [m]);
                    const x = e => {
                            let {
                                htmlContent: t
                            } = e;
                            const s = M().sanitize(t);
                            return (0, o.jsx)("div", {
                                className: "break-words prose",
                                dangerouslySetInnerHTML: {
                                    __html: s
                                }
                            })
                        },
                        v = () => !!n && !!n.trim().length,
                        f = () => {
                            try {
                                window.notesRef && window.notesRef.current && window.notesRef.current.scrollTo({
                                    top: window.notesRef.current.scrollHeight,
                                    behavior: "smooth"
                                })
                            } catch (e) {
                                console.log(e)
                            }
                        };
                    return (0, o.jsx)(o.Fragment, {
                        children: (0, o.jsxs)("div", {
                            id: "ele-100",
                            className: "relative flex flex-col overflow-y-auto",
                            children: [(0, o.jsx)("div", {
                                id: "ele-101",
                                className: "text-primaryText text-lg font-mSemiBold mt-4 px-2",
                                children: "Ticket Details"
                            }), (0, o.jsxs)("div", {
                                id: "ele-102",
                                className: "flex flex-col",
                                children: [(0, o.jsxs)("div", {
                                    id: "ele-103",
                                    className: "flex justify-between w-full my-2 px-2",
                                    children: [(0, o.jsx)("div", {
                                        id: "ele-104",
                                        className: "text-primaryText text-sm font-bold",
                                        children: "Status: "
                                    }), (0, o.jsxs)("div", {
                                        id: "ele-105",
                                        className: "text-secondaryText w-1/2 text-sm font-thin text-right",
                                        children: [e.ticket.pipelineStage, " "]
                                    })]
                                }), (0, o.jsxs)("div", {
                                    id: "ele-106",
                                    className: "flex justify-between w-full my-2 px-2",
                                    children: [(0, o.jsx)("div", {
                                        id: "ele-107",
                                        className: "text-primaryText text-sm font-bold",
                                        children: "Ticket ID: "
                                    }), (0, o.jsxs)("div", {
                                        id: "ele-108",
                                        className: "text-secondaryText w-1/2 text-sm font-thin text-right",
                                        children: [e.ticket.id, " "]
                                    })]
                                }), (0, o.jsxs)("div", {
                                    id: "ele-109",
                                    className: "flex justify-between w-full my-2 px-2",
                                    children: [(0, o.jsx)("div", {
                                        id: "ele-110",
                                        className: "text-primaryText text-sm font-bold",
                                        children: "Full Name: "
                                    }), (0, o.jsxs)("div", {
                                        id: "ele-111",
                                        className: "text-secondaryText w-1/2 text-sm font-thin text-right",
                                        children: [e.ticket.name, " "]
                                    })]
                                }), (0, o.jsxs)("div", {
                                    id: "ele-112",
                                    className: "flex justify-between w-full my-2 px-2",
                                    children: [(0, o.jsx)("div", {
                                        id: "ele-113",
                                        className: "text-primaryText text-sm font-bold",
                                        children: "Email: "
                                    }), (0, o.jsxs)("div", {
                                        id: "ele-114",
                                        className: "text-secondaryText w-1/2 text-sm font-thin text-right",
                                        children: [e.ticket.email, " "]
                                    })]
                                }), e.ticket.category && (0, o.jsxs)("div", {
                                    id: "ele-115",
                                    className: "flex justify-between w-full my-2 px-2",
                                    children: [(0, o.jsx)("div", {
                                        id: "ele-116",
                                        className: "text-primaryText text-sm font-bold",
                                        children: "Issue Category: "
                                    }), (0, o.jsxs)("div", {
                                        id: "ele-117",
                                        className: "text-secondaryText w-1/2 text-sm font-thin text-right",
                                        children: [(b = e.ticket.category, b.replace(/_/g, " ").toLowerCase().split(" ").map((function(e) {
                                            return e.replace(e[0], e[0].toUpperCase())
                                        })).join(" ")), " "]
                                    })]
                                }), (0, o.jsxs)("div", {
                                    id: "ele-118",
                                    className: "flex justify-between w-full my-2 px-2",
                                    children: [(0, o.jsx)("div", {
                                        id: "ele-119",
                                        className: "text-primaryText text-sm font-bold",
                                        children: "Issue Title: "
                                    }), (0, o.jsxs)("div", {
                                        id: "ele-120",
                                        className: "text-secondaryText w-1/2 text-sm font-thin text-right",
                                        children: [e.ticket.subject, " "]
                                    })]
                                }), (0, o.jsxs)("div", {
                                    id: "ele-121",
                                    className: "flex justify-between w-full my-2 px-2",
                                    children: [(0, o.jsx)("div", {
                                        id: "ele-122",
                                        className: "text-primaryText text-sm font-bold",
                                        children: "Issue Description: "
                                    }), (0, o.jsxs)("div", {
                                        id: "ele-123",
                                        className: "text-secondaryText w-1/2 text-sm font-thin text-right",
                                        children: [e.ticket.content, " "]
                                    })]
                                })]
                            }), "CLOSED" !== e.ticket.status ? (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)("div", {
                                    id: "ele-124",
                                    className: "text-primaryText text-lg font-mSemiBold mt-4 px-2",
                                    children: "Add Comments"
                                }), (0, o.jsx)("div", {
                                    className: "mt-3 px-2",
                                    id: "ele-125",
                                    children: (0, o.jsx)(d, {
                                        design: r,
                                        placeholder: "Write your comment",
                                        multiline: !0,
                                        rows: 4,
                                        value: n,
                                        inputProps: {
                                            maxLength: 2e3
                                        },
                                        onChange: e => a(e.target.value)
                                    })
                                }), (0, o.jsx)("div", {
                                    id: "ele-126",
                                    className: "flex justify-end mt-3 px-2",
                                    children: (0, o.jsxs)("div", {
                                        className: "align-middle justify-center items-center text-white rounded-lg px-6 py-2 ml-4 " + (v() ? "cursor-pointer" : "opacity-50 cursor-default"),
                                        style: {
                                            backgroundColor: null === r || void 0 === r ? void 0 : r.themeColor
                                        },
                                        onClick: () => (() => {
                                            if (!v() || c) return !1;
                                            u(!0), (0, g.l8)(e.ticket.id, n).then((e => {
                                                if (!e || e.name && "AxiosError" === e.name) throw new Error("Failed");
                                                s((t => [{ ...e,
                                                    isNew: !0
                                                }, ...t])), a(""), f()
                                            })).catch((e => console.log(e))).finally((() => u(!1)))
                                        })(),
                                        id: "ele-127",
                                        children: ["Add Comment", (0, o.jsx)("span", {
                                            id: "ele-128",
                                            className: "ml-2 ",
                                            children: c && (0, o.jsx)(h.A, {
                                                size: 12,
                                                sx: {
                                                    color: "white"
                                                }
                                            })
                                        })]
                                    })
                                })]
                            }) : (0, o.jsx)(o.Fragment, {
                                children: !!t && !!t.length && (0, o.jsx)("hr", {
                                    id: "ele-129",
                                    className: "mt-2"
                                })
                            }), !!t && !!t.length && (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)("div", {
                                    id: "ele-130",
                                    className: "text-primaryText text-lg font-mSemiBold mt-4 px-2",
                                    children: "Comments"
                                }), (0, o.jsx)("div", {
                                    className: "flex flex-col w-full px-2 mt-2",
                                    id: "ele-131",
                                    children: t.map((e => (0, o.jsxs)("div", {
                                        id: "ele-132",
                                        className: "flex flex-col mb-4",
                                        children: [(0, o.jsxs)("div", {
                                            id: "ele-133",
                                            className: "flex justify-between item-center align-middle mb-1",
                                            children: [(0, o.jsxs)("div", {
                                                id: "ele-134",
                                                children: [(0, o.jsx)("span", {
                                                    id: "ele-135",
                                                    className: "font-mSemiBold text-sm",
                                                    children: e.createdBy ? "Agent" : "You"
                                                }), "  \xa0 \xa0", (0, o.jsx)("span", {
                                                    id: "ele-136",
                                                    className: "text-lightText text-sm",
                                                    children: (0, p.Yq)(e.createdAt)
                                                })]
                                            }), e.isNew && (0, o.jsx)("div", {
                                                id: "ele-137",
                                                className: "w-3 h-3 rounded-full my-auto",
                                                style: {
                                                    backgroundColor: null === r || void 0 === r ? void 0 : r.themeColor
                                                }
                                            })]
                                        }), (0, o.jsx)("div", {
                                            id: "ele-138",
                                            className: "text-footer text-sm ",
                                            children: (0, o.jsx)(x, {
                                                htmlContent: e.content
                                            })
                                        }), e.attachments && e.attachments.length && (0, o.jsx)("div", {
                                            id: "ele-139",
                                            className: "flex flex-col justify-start my-2",
                                            children: e.attachments.map((e => (0, o.jsxs)("div", {
                                                className: "ele-ticket-attachment-container w-full flex justify-start align-middle items-center mt-2",
                                                children: [(0, o.jsx)("img", {
                                                    src: e.url,
                                                    alt: "img",
                                                    width: 100,
                                                    height: 100,
                                                    className: "object-cover border cursor-pointer ele-ticket-attachement-img",
                                                    onClick: () => (0, p.PE)(e.url, e.name)
                                                }), (0, o.jsxs)("div", {
                                                    className: "text-sm w-2/3  ml-2 truncate ele-ticket-attachment-name",
                                                    children: [e.name, ".png"]
                                                })]
                                            }, e.id)))
                                        })]
                                    }, "nid" + e.id)))
                                })]
                            })]
                        })
                    });
                    var b
                },
                I = (0, i.memo)(B);
            var _ = s(42245);
            const R = e => {
                    var t;
                    const [s, n] = (0, i.useState)(!1), [a, r] = (0, i.useState)(!0), [d, c] = (0, i.useState)([]), [u, m] = (0, i.useState)(!1), p = (0, l.d4)((e => null === e || void 0 === e ? void 0 : e.environment)), [x, v] = (0, i.useState)(!1), [f, b] = (0, i.useState)(void 0), [y, w] = (0, i.useState)({
                        name: "",
                        email: ""
                    });
                    (0, i.useEffect)((() => {
                        window.notesRef = (0, i.createRef)()
                    }), []), (0, i.useEffect)((() => {
                        w((e => ({ ...e,
                            email: p.ticketsEmail
                        })))
                    }), [p.ticketsEmail]);
                    const N = () => {
                            r(!0), S(), m(!1), b(void 0)
                        },
                        S = (0, i.useCallback)((() => {
                            y.email ? (r(!0), (0, g.IO)(y).then((e => {
                                if (!e || e.name && "AxiosError" === e.name) throw new Error("Failed");
                                c(e)
                            })).catch((e => {
                                console.log(e), n(!0)
                            })).finally((() => r(!1)))) : r(!1)
                        }), [y]);
                    (0, i.useEffect)((() => {
                        S()
                    }), [S]);
                    const A = (0, i.useCallback)((() => {
                        m(!0)
                    }), []);
                    return (0, i.useEffect)((() => {
                        const e = e => {
                            "BotPenguin" === e.data.origin && ("getRequestedUserMeta" !== e.data.action || y.email || (w(e.data.payload), v(!0)))
                        };
                        return window.addEventListener("message", e), y.email || x || window.parent.postMessage({
                            origin: "BotPenguin",
                            action: "requestingUserMeta"
                        }, "*"), () => {
                            window.removeEventListener("message", e)
                        }
                    }), [y.email, x]), (0, o.jsx)(o.Fragment, {
                        children: (0, o.jsxs)("div", {
                            className: "flex flex-col justify-start rounded-t-2xl font-mRegular min-w-96 px-4 pt-4 h-full overflow-hidden",
                            style: {
                                backgroundColor: null === e || void 0 === e || null === (t = e.design) || void 0 === t ? void 0 : t.backgroundColor
                            },
                            id: "chatWindow",
                            children: [(0, o.jsx)("div", {
                                id: "ele-65",
                                className: "h-16 max-h-20 rounded-xl",
                                children: (0, o.jsx)(C.A, {
                                    type: "Tickets",
                                    backMethod: N,
                                    showBack: u || !!f
                                })
                            }), a ? (0, o.jsx)("div", {
                                id: "ele-66",
                                className: "flex items-center justify-center h-full",
                                children: (0, o.jsx)(h.A, {})
                            }) : s ? (0, o.jsx)(o.Fragment, {
                                children: (0, o.jsx)(_.A, {
                                    type: "Tickets"
                                })
                            }) : (0, o.jsxs)(o.Fragment, {
                                children: [!d.length && !u && (0, o.jsx)("div", {
                                    id: "ele-67",
                                    className: "h-full",
                                    children: (0, o.jsx)(k, {
                                        createNewTicket: A
                                    })
                                }), !!d.length && !u && !f && (0, o.jsx)("div", {
                                    id: "ele-75",
                                    className: "flex-grow overflow-auto relative hide-scrollbar",
                                    children: (0, o.jsx)(T, {
                                        setTicketDetails: b,
                                        createNewTicket: A,
                                        openTickets: d.filter((e => "CLOSED" !== e.status)),
                                        closedTickets: d.filter((e => "CLOSED" === e.status))
                                    })
                                }), !!d.length && !u && f && (0, o.jsx)("div", {
                                    id: "ele-99",
                                    className: "flex-grow overflow-auto hide-scrollbar",
                                    ref: window.notesRef,
                                    children: (0, o.jsx)(I, {
                                        ticket: f
                                    })
                                }), !!u && (0, o.jsx)("div", {
                                    id: "ele-307",
                                    className: "flex-grow overflow-auto relative",
                                    children: (0, o.jsx)(j, {
                                        backMethod: N
                                    })
                                }), (0, o.jsxs)("div", {
                                    className: "position-fixed",
                                    children: [" ", (0, o.jsx)(E.A, {}), " "]
                                })]
                            })]
                        })
                    })
                },
                F = (0, i.memo)(R)
        },
        49672: (e, t, s) => {
            "use strict";
            s.d(t, {
                Hl: () => y,
                sE: () => j,
                UF: () => T
            });
            var i = s(38751),
                l = s(26618),
                n = s(87946),
                a = s.n(n),
                o = s(25817),
                r = s(69772),
                d = s(1092),
                c = s(72796),
                u = s(47582),
                m = s(26668);
            var h = s(86224),
                p = s(71173),
                g = s.n(p);
            var x = s(31160),
                v = s(34928),
                f = s(23507),
                b = s(67956);
            const j = () => {
                    const e = window.parent.BotPenguinData;
                    if (e && e.configuration && e.configuration.generalSettings && e.configuration.generalSettings.notificationSound) {
                        const t = e.configuration.generalSettings.notificationSound;
                        (0, h.TZ)(t)
                    }
                    let t = localStorage.getItem("Ctx_Custom_Attributes"),
                        s = localStorage.getItem("Ctx_Default_Attributes");
                    w(e, t ? JSON.parse(t) : [], s ? JSON.parse(s) : {}), window.parent.postMessage({
                        origin: "BotPenguin",
                        action: "rendered"
                    }, "*")
                },
                y = async function(e, t) {
                    let s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : [];
                    try {
                        const l = localStorage.getItem("BotPenguin_User_uuid") || "",
                            n = await (0, i.AF)(e, t, l);
                        w({ ...n,
                            isLanding: !0
                        }, s), localStorage.setItem("BotPenguin_User_uuid", n.uuid), localStorage.setItem("BotPenguin_Landing_Page", JSON.stringify(n)), (e => {
                            if (e.configuration && e.configuration.generalSettings && e.configuration.generalSettings.googleTagManager && e.configuration.generalSettings.googleTagManager.headTag.length) {
                                let t = e.configuration.generalSettings.googleTagManager.headTag.match(/GTM-\w+/g);
                                if (t) {
                                    const e = {
                                        gtmId: t[0]
                                    };
                                    g().initialize(e)
                                }
                            }
                        })(n)
                    } catch (l) {
                        console.log(l)
                    }
                },
                w = async function(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                        s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                    try {
                        var l;
                        if (N(e), t && t.length) {
                            const e = t.map((e => ({
                                key: `{{${e.key}}}`,
                                value: e.value
                            })));
                            o.e.dispatch((0, d.zH)(e))
                        }
                        e && e.shouldFetchRephrasedFlow && ((0, i.ft)(e._id, e.flows[0]._id, "main"), o.e.dispatch((0, r.h8)({
                            shouldFetchRephrasedFlow: e.shouldFetchRephrasedFlow
                        }))), e && e.shouldFetchRephrasedRevisitFlow && e.flows[0]._id !== (null === (l = e.revisitFlow) || void 0 === l ? void 0 : l._id) && ((0, i.ft)(e._id, e.revisitFlow._id, "revisit"), o.e.dispatch((0, r.h8)({
                            shouldFetchRephrasedRevisitFlow: e.shouldFetchRephrasedRevisitFlow
                        }))), (0, c.Mz)(), S().then((i => {
                            (0, u.KC)({ ...i,
                                ...k(),
                                location: null === i || void 0 === i ? void 0 : i.city,
                                user: e._user,
                                uuid: e.uuid
                            }), (0, c.Rl)({ ...i,
                                ...k(),
                                location: null === i || void 0 === i ? void 0 : i.city,
                                url: window.location.href,
                                ...t && t.length > 0 && {
                                    customAttributes: t
                                },
                                ...s
                            }).catch((() => console.log("Error creating uuid")))
                        })).catch((e => {
                            console.log("Error", e)
                        })), setTimeout((() => {
                            if (e && e.design && e.design.customCSS) {
                                const t = document.createElement("style");
                                t.textContent = e.design.customCSS, document.head.appendChild(t)
                            }
                        }), 100)
                    } catch (n) {
                        console.log(n, "Error fetching bot details")
                    }
                },
                N = e => {
                    var t, s, i, l, n, a, c, u, h, p, g;
                    const x = e,
                        v = parseInt(localStorage.getItem("tabCount") || "0");
                    let f = "forever" === (null === (t = x.configuration) || void 0 === t || null === (s = t.generalSettings) || void 0 === s ? void 0 : s.userChatRetention) || v ? localStorage.getItem(`BotPenguin-${x._id}`) : sessionStorage.getItem(`BotPenguin-${x._id}`);
                    if (f) try {
                        f = JSON.parse(f).messages || []
                    } catch (w) {
                        f = []
                    }
                    const b = (null === (i = x.configuration) || void 0 === i || null === (l = i.chatMenu) || void 0 === l ? void 0 : l.clearChatOnReload) || !1,
                        j = sessionStorage.getItem("clearChatOnBrowserReload") && b ? [] : f;
                    var y;
                    sessionStorage.setItem("clearChatOnBrowserReload", "true"), o.e.dispatch((0, d.db)(null !== j && void 0 !== j ? j : [])), o.e.dispatch((0, r.h8)({
                        _id: x._id,
                        _user: x._user,
                        _agency: x._agency,
                        activeQuestion: null,
                        activeFlow: x.flows[0].id,
                        preview: x.preview || !1,
                        embedded: x.embedded || !1,
                        refresh: !0,
                        typing: !1,
                        pause: !1,
                        activeQuestionType: (null === j || void 0 === j || null === (n = j[j.length - 1]) || void 0 === n ? void 0 : n.type) || "statement",
                        skip: !1,
                        back: !1,
                        dateTime: !1,
                        uuid: x.uuid,
                        lastQuestion: "",
                        profile: x.profile || "",
                        plan: x.plan || "",
                        liveChat: !1,
                        isLanding: x.isLanding,
                        whitelabel: x.whitelabel || {},
                        chatRequestAccepted: !1,
                        chatRequestRejected: !1,
                        _chatWindowUser: x._chatWindowUser,
                        agentId: void 0,
                        socketDisconnected: !1,
                        installations: x.installations || [],
                        agencyData: x.agency || {},
                        chatMenu: x.configuration.chatMenu,
                        activeInput: null !== (a = x.configuration.chatMenu) && void 0 !== a && null !== (c = a.voiceSupport) && void 0 !== c && c.isEnabled && null !== (u = x.configuration.chatMenu) && void 0 !== u && null !== (h = u.voiceSupport) && void 0 !== h && h.isDefault ? "voice" : "chat",
                        _flow: x.flows[0]._id,
                        isResponseStreamingEnabled: null !== (p = x.isResponseStreamingEnabled) && void 0 !== p && p,
                        ai: {
                            streaming: !1,
                            sequenceBuffer: {},
                            nextExpectedSequence: 0,
                            lastExpectedSequence: -1
                        },
                        isVoiceOutputEnabled: !1,
                        audioInput: {
                            isMicOn: !1,
                            isListening: !1
                        }
                    })), o.e.dispatch((0, d.Ah)([...e.flows])), o.e.dispatch((0, d.Fl)(e.revisitFlow ? e.revisitFlow : e.flows[0])), o.e.dispatch((y = { ...e.configuration
                    }, {
                        type: m.H5,
                        payload: y
                    })), o.e.dispatch((e => ({
                        type: m.V7,
                        payload: e
                    }))({ ...e.design,
                        name: e.name,
                        icebreakers: (null === e || void 0 === e ? void 0 : e.iceBreaker) || []
                    })), o.e.dispatch((0, d.PX)({
                        messages: e.ai.messages || {},
                        ...!!e.threadId && {
                            threadId: e.threadId || ""
                        },
                        ...!(null === e || void 0 === e || null === (g = e.ai) || void 0 === g || !g._persona) && {
                            persona: {
                                _id: e.ai._persona
                            }
                        }
                    }))
                };

            function k() {
                const e = (new(a())).getResult();
                return {
                    operatingSystem: e.os.name + " " + e.os.version,
                    device: (e.device.type || "Desktop") + `(${(e.device.vendor||"")+" "+(e.device.model||"")})`,
                    browser: e.browser.name + " " + e.browser.version
                }
            }
            const C = async function() {
                    let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 5,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3;
                    for (let i = 0; i < e; i++) try {
                        const e = await (0, l.a)("GET", `https://api.botpenguin.com/meta/ip?via=messengerV2&uuid=${localStorage.getItem("BotPenguin_User_uuid")}`, void 0);
                        if (!e || !(e.city || e.country || e.ip)) throw new Error((null === e || void 0 === e ? void 0 : e.message) || "Failed to fetch IP details");
                        return e
                    } catch (s) {
                        if (i === e - 1) return;
                        console.log(`Retrying request... attempt ${i+1}`), console.log(s), await new Promise((e => setTimeout(e, t)))
                    }
                },
                S = async () => {
                    try {
                        let t = localStorage.getItem("BotPenguin-location");
                        if (t) try {
                            t = JSON.parse(t)
                        } catch (e) {
                            t = await C(), localStorage.setItem("BotPenguin-location", JSON.stringify(t))
                        } else t = await C(), localStorage.setItem("BotPenguin-location", JSON.stringify(t));
                        return o.e.dispatch((0, d.hs)({ ...t
                        })), t
                    } catch (t) {
                        console.log(t)
                    }
                },
                T = async (e, t) => {
                    try {
                        const s = await (0, x.SJ)(e.uuid),
                            i = e.liveChat || !!localStorage.getItem("agentId");
                        if (s.isLiveChatActive === i) return;
                        const l = localStorage.getItem("agentData"),
                            n = localStorage.getItem("agentId"),
                            a = l ? (0, c.GO)(l, "server-bp-678#1") : null;
                        if (!s.isLiveChatActive) return localStorage.removeItem("agentId"), localStorage.removeItem("agentData"), localStorage.removeItem("bp-wsn"), o.e.dispatch((0, v.t)("BOT")), o.e.dispatch((0, r.h8)({
                            liveChat: !1,
                            agentId: void 0,
                            chatRequestAccepted: !1,
                            disableStartButton: !1,
                            typing: !0
                        })), void(0, f.sZ)();
                        if (!a && s._agentAssigned && localStorage.setItem("agentId", s._agentAssigned), o.e.dispatch((0, r.h8)({
                                typing: !1,
                                refresh: !0,
                                liveChat: !0,
                                iframeActive: {},
                                activeQuestion: { ...null === e || void 0 === e ? void 0 : e.activeQuestion,
                                    aiConfig: {},
                                    suggestions: []
                                },
                                batchedMessages: "",
                                currentTimerRef: null
                            })), !n || !a || t.length) return;
                        const m = (0, b.A)();
                        (0, u.Ic)("message", {
                            agentName: a.name,
                            type: "system",
                            method: "chat-request-accepted",
                            mid: m
                        }), o.e.dispatch((0, d.iW)({
                            agentName: a.name,
                            type: "system",
                            method: "chat-request-accepted",
                            mid: m
                        }))
                    } catch (s) {
                        console.error("updateUserState error:", s)
                    }
                }
        },
        6391: (e, t, s) => {
            var i = {
                "./af": [95931, 5931],
                "./af.js": [95931, 5931],
                "./ar": [84079, 4079],
                "./ar-dz": [63898, 3898],
                "./ar-dz.js": [63898, 3898],
                "./ar-kw": [70858, 858],
                "./ar-kw.js": [70858, 858],
                "./ar-ly": [25695, 5695],
                "./ar-ly.js": [25695, 5695],
                "./ar-ma": [88822, 8822],
                "./ar-ma.js": [88822, 8822],
                "./ar-ps": [60549, 549],
                "./ar-ps.js": [60549, 549],
                "./ar-sa": [63620, 3620],
                "./ar-sa.js": [63620, 3620],
                "./ar-tn": [68102, 8102],
                "./ar-tn.js": [68102, 8102],
                "./ar.js": [84079, 4079],
                "./az": [54567, 4567],
                "./az.js": [54567, 4567],
                "./be": [4977, 4977],
                "./be.js": [4977, 4977],
                "./bg": [93455, 3455],
                "./bg.js": [93455, 3455],
                "./bm": [72745, 2745],
                "./bm.js": [72745, 2745],
                "./bn": [88208, 8208],
                "./bn-bd": [1579, 1579],
                "./bn-bd.js": [1579, 1579],
                "./bn.js": [88208, 8208],
                "./bo": [29255, 9255],
                "./bo.js": [29255, 9255],
                "./br": [71092, 1092],
                "./br.js": [71092, 1092],
                "./bs": [28091, 8091],
                "./bs.js": [28091, 8091],
                "./ca": [1492, 1492],
                "./ca.js": [1492, 1492],
                "./cs": [43470, 3470],
                "./cs.js": [43470, 3470],
                "./cv": [51729, 1729],
                "./cv.js": [51729, 1729],
                "./cy": [54684, 4684],
                "./cy.js": [54684, 4684],
                "./da": [64479, 4479],
                "./da.js": [64479, 4479],
                "./de": [62011, 2011],
                "./de-at": [39889, 9889],
                "./de-at.js": [39889, 9889],
                "./de-ch": [38607, 8607],
                "./de-ch.js": [38607, 8607],
                "./de.js": [62011, 2011],
                "./dv": [30638, 638],
                "./dv.js": [30638, 638],
                "./el": [44169, 4169],
                "./el.js": [44169, 4169],
                "./en-au": [37446, 7446],
                "./en-au.js": [37446, 7446],
                "./en-ca": [58316, 8316],
                "./en-ca.js": [58316, 8316],
                "./en-gb": [30257, 257],
                "./en-gb.js": [30257, 257],
                "./en-ie": [85934, 5934],
                "./en-ie.js": [85934, 5934],
                "./en-il": [77925, 7925],
                "./en-il.js": [77925, 7925],
                "./en-in": [18435, 8435],
                "./en-in.js": [18435, 8435],
                "./en-nz": [45112, 5112],
                "./en-nz.js": [45112, 5112],
                "./en-sg": [19258, 9258],
                "./en-sg.js": [19258, 9258],
                "./eo": [94864, 4864],
                "./eo.js": [94864, 4864],
                "./es": [93204, 3204],
                "./es-do": [92408, 2408],
                "./es-do.js": [92408, 2408],
                "./es-mx": [73792, 3792],
                "./es-mx.js": [73792, 3792],
                "./es-us": [93113, 3113],
                "./es-us.js": [93113, 3113],
                "./es.js": [93204, 3204],
                "./et": [20801, 801],
                "./et.js": [20801, 801],
                "./eu": [29874, 9874],
                "./eu.js": [29874, 9874],
                "./fa": [91241, 1241],
                "./fa.js": [91241, 1241],
                "./fi": [23473, 3473],
                "./fi.js": [23473, 3473],
                "./fil": [97177, 7177],
                "./fil.js": [97177, 7177],
                "./fo": [99019, 9019],
                "./fo.js": [99019, 9019],
                "./fr": [94048, 4048],
                "./fr-ca": [96465, 6465],
                "./fr-ca.js": [96465, 6465],
                "./fr-ch": [666, 666],
                "./fr-ch.js": [666, 666],
                "./fr.js": [94048, 4048],
                "./fy": [44577, 4577],
                "./fy.js": [44577, 4577],
                "./ga": [40800, 800],
                "./ga.js": [40800, 800],
                "./gd": [66003, 6003],
                "./gd.js": [66003, 6003],
                "./gl": [76987, 6987],
                "./gl.js": [76987, 6987],
                "./gom-deva": [4702, 4702],
                "./gom-deva.js": [4702, 4702],
                "./gom-latn": [10777, 777],
                "./gom-latn.js": [10777, 777],
                "./gu": [30652, 652],
                "./gu.js": [30652, 652],
                "./he": [86991, 6991],
                "./he.js": [86991, 6991],
                "./hi": [15811, 5811],
                "./hi.js": [15811, 5811],
                "./hr": [52830, 2830],
                "./hr.js": [52830, 2830],
                "./hu": [59679, 9679],
                "./hu.js": [59679, 9679],
                "./hy-am": [5234, 5234],
                "./hy-am.js": [5234, 5234],
                "./id": [36101, 6101],
                "./id.js": [36101, 6101],
                "./is": [17056, 7056],
                "./is.js": [17056, 7056],
                "./it": [57205, 7205],
                "./it-ch": [20433, 433],
                "./it-ch.js": [20433, 433],
                "./it.js": [57205, 7205],
                "./ja": [87605, 7605],
                "./ja.js": [87605, 7605],
                "./jv": [17584, 7584],
                "./jv.js": [17584, 7584],
                "./ka": [11452, 1452],
                "./ka.js": [11452, 1452],
                "./kk": [238, 238],
                "./kk.js": [238, 238],
                "./km": [17464, 7464],
                "./km.js": [17464, 7464],
                "./kn": [8497, 8497],
                "./kn.js": [8497, 8497],
                "./ko": [90082, 82],
                "./ko.js": [90082, 82],
                "./ku": [28544, 8544],
                "./ku-kmr": [8351, 8351],
                "./ku-kmr.js": [8351, 8351],
                "./ku.js": [28544, 8544],
                "./ky": [58260, 8260],
                "./ky.js": [58260, 8260],
                "./lb": [99866, 9866],
                "./lb.js": [99866, 9866],
                "./lo": [97069, 7069],
                "./lo.js": [97069, 7069],
                "./lt": [25868, 5868],
                "./lt.js": [25868, 5868],
                "./lv": [14326, 4326],
                "./lv.js": [14326, 4326],
                "./me": [60682, 682],
                "./me.js": [60682, 682],
                "./mi": [64030, 4030],
                "./mi.js": [64030, 4030],
                "./mk": [75828, 5828],
                "./mk.js": [75828, 5828],
                "./ml": [47169, 7169],
                "./ml.js": [47169, 7169],
                "./mn": [51647, 1647],
                "./mn.js": [51647, 1647],
                "./mr": [50307, 307],
                "./mr.js": [50307, 307],
                "./ms": [45372, 5372],
                "./ms-my": [11455, 1455],
                "./ms-my.js": [11455, 1455],
                "./ms.js": [45372, 5372],
                "./mt": [77481, 7481],
                "./mt.js": [77481, 7481],
                "./my": [17806, 7806],
                "./my.js": [17806, 7806],
                "./nb": [75160, 5160],
                "./nb.js": [75160, 5160],
                "./ne": [16013, 6013],
                "./ne.js": [16013, 6013],
                "./nl": [2854, 2854],
                "./nl-be": [57058, 7058],
                "./nl-be.js": [57058, 7058],
                "./nl.js": [2854, 2854],
                "./nn": [40860, 860],
                "./nn.js": [40860, 860],
                "./oc-lnc": [74104, 4104],
                "./oc-lnc.js": [74104, 4104],
                "./pa-in": [76967, 6967],
                "./pa-in.js": [76967, 6967],
                "./pl": [23144, 3144],
                "./pl.js": [23144, 3144],
                "./pt": [15952, 5952],
                "./pt-br": [93217, 3217],
                "./pt-br.js": [93217, 3217],
                "./pt.js": [15952, 5952],
                "./ro": [3191, 3191],
                "./ro.js": [3191, 3191],
                "./ru": [74961, 4961],
                "./ru.js": [74961, 4961],
                "./sd": [58415, 8415],
                "./sd.js": [58415, 8415],
                "./se": [24056, 4056],
                "./se.js": [24056, 4056],
                "./si": [23932, 3932],
                "./si.js": [23932, 3932],
                "./sk": [51750, 1750],
                "./sk.js": [51750, 1750],
                "./sl": [28903, 8903],
                "./sl.js": [28903, 8903],
                "./sq": [22324, 2324],
                "./sq.js": [22324, 2324],
                "./sr": [34173, 4173],
                "./sr-cyrl": [57764, 7764],
                "./sr-cyrl.js": [57764, 7764],
                "./sr.js": [34173, 4173],
                "./ss": [24254, 4254],
                "./ss.js": [24254, 4254],
                "./sv": [7393, 7393],
                "./sv.js": [7393, 7393],
                "./sw": [23410, 3410],
                "./sw.js": [23410, 3410],
                "./ta": [45583, 5583],
                "./ta.js": [45583, 5583],
                "./te": [43115, 3115],
                "./te.js": [43115, 3115],
                "./tet": [71231, 1231],
                "./tet.js": [71231, 1231],
                "./tg": [52077, 2077],
                "./tg.js": [52077, 2077],
                "./th": [91920, 1920],
                "./th.js": [91920, 1920],
                "./tk": [67401, 7401],
                "./tk.js": [67401, 7401],
                "./tl-ph": [50505, 505],
                "./tl-ph.js": [50505, 505],
                "./tlh": [21966, 1966],
                "./tlh.js": [21966, 1966],
                "./tr": [10578, 578],
                "./tr.js": [10578, 578],
                "./tzl": [27908, 7908],
                "./tzl.js": [27908, 7908],
                "./tzm": [49931, 9931],
                "./tzm-latn": [21757, 1757],
                "./tzm-latn.js": [21757, 1757],
                "./tzm.js": [49931, 9931],
                "./ug-cn": [5652, 5652],
                "./ug-cn.js": [5652, 5652],
                "./uk": [27116, 7116],
                "./uk.js": [27116, 7116],
                "./ur": [73515, 3515],
                "./ur.js": [73515, 3515],
                "./uz": [39491, 9491],
                "./uz-latn": [36629, 6629],
                "./uz-latn.js": [36629, 6629],
                "./uz.js": [39491, 9491],
                "./vi": [34337, 4337],
                "./vi.js": [34337, 4337],
                "./x-pseudo": [91121, 1121],
                "./x-pseudo.js": [91121, 1121],
                "./yo": [1460, 1460],
                "./yo.js": [1460, 1460],
                "./zh-cn": [27502, 7502],
                "./zh-cn.js": [27502, 7502],
                "./zh-hk": [11698, 1698],
                "./zh-hk.js": [11698, 1698],
                "./zh-mo": [69351, 9351],
                "./zh-mo.js": [69351, 9351],
                "./zh-tw": [99482, 9482],
                "./zh-tw.js": [99482, 9482]
            };

            function l(e) {
                if (!s.o(i, e)) return Promise.resolve().then((() => {
                    var t = new Error("Cannot find module '" + e + "'");
                    throw t.code = "MODULE_NOT_FOUND", t
                }));
                var t = i[e],
                    l = t[0];
                return s.e(t[1]).then((() => s.t(l, 23)))
            }
            l.keys = () => Object.keys(i), l.id = 6391, e.exports = l
        }
    }
]);